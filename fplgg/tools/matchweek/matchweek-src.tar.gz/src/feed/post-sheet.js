/* feed/post-sheet.js — a post opened large, with the facts it was built from and where to go next. data-open="post:<id>" */
import * as UI from '../ui.js';
import { postById, renderPost, restoreCarousels, stopSpeaking } from './index.js';
import { VOICES } from './voices.js';
import { shows, mmss } from './facts.js';
import * as SHOW from './player.js';
import { esc, short } from './util.js';

function showPlayer(gw) {
  const s = shows().find(x => x.gw === gw); if (!s) return '';
  const prev = (typeof PREVIEWS !== 'undefined' ? PREVIEWS : []).find(p => p.gw === gw);
  return '<div class="show-player" data-gw="' + gw + '">'
    + '<div class="spl-top"><button class="vn-play big" data-fx="show:' + gw + '" aria-label="Play the show"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M7 4 L20 12 L7 20 Z" fill="currentColor"/></svg></button><div class="spl-meta"><b>The Gameweek ' + gw + ' show</b><span>Malcolm Tyre in the booth · ' + mmss(s.dur) + '</span></div>'
    + '<button class="spl-skip" data-fx="skip:' + gw + '" disabled>Next chapter</button></div>'
    + '<div class="spl-bar"><i></i></div><div class="spl-t n">0:00 / ' + mmss(s.dur) + '</div>'
    + '<p class="spl-cap" aria-live="polite"></p>'
    + '<div class="spl-ch">' + s.j.chapters.map((c, i) => '<div class="spl-c" data-ch="' + i + '">' + UI.crest(c.home, 22) + '<b>' + esc(c.home) + '</b><i>v</i><b>' + esc(c.away) + '</b>' + UI.crest(c.away, 22) + '</div>').join('') + '</div>'
    + (prev ? '<a class="cta" href="' + esc(prev.href) + '">Read the GW' + gw + ' preview <span class="ch">›</span></a>' : '')
    + '</div>';
}

export default {
  cls: 'post-sheet',
  render(id) {
    const p = postById(id);
    if (!p) return '<div class="ps"><div class="ps-gone">' + UI.empty('This post has moved on', 'The feed rebuilds from the latest data, and this one is no longer in it.') + '</div></div>';
    const V = VOICES[p.voice];
    const players = (p.players || []).map(c => UI.player(c)).filter(Boolean);
    const teams = (p.teams || []).filter(t => TEAMS[t]).slice(0, 8);
    let extra = '';
    if (p.kind === 'show') extra = showPlayer(p.media.gw);
    const nb = t => String(t).replace(/(\d+(?:\.\d+)?%?)–(\d+(?:\.\d+)?%?)/g, '<span class="nw">$1–$2</span>');
    const rows = (p.detail || []).map(d => '<div class="ps-r"><span>' + d.k + '</span><b>' + nb(d.v) + '</b></div>').join('');
    const links = (p.links || []).map(l => l.open ? '<button class="row tap ps-l" data-open="' + esc(l.open) + '"><b>' + esc(l.label) + '</b>' + UI.icon('chev', 16, 'var(--tx3)') + '</button>' : '<a class="row tap ps-l" href="' + esc(l.href) + '"><b>' + esc(l.label) + '</b>' + UI.icon('chev', 16, 'var(--tx3)') + '</a>').join('');
    return '<div class="ps">'
      + renderPost(p, { big: true, noMedia: p.kind === 'show' })
      + extra
      + (rows ? UI.sh('The numbers behind it') + '<div class="card ps-facts">' + rows + (p.facts ? '<div class="foot">Source: ' + esc(p.facts) + '</div>' : '') + '</div>' : '')
      + (players.length ? UI.sh(players.length === 1 ? 'The player' : 'The players') + '<div class="card">' + players.slice(0, 8).map(q => '<button class="row tap ps-p" data-open="player:' + esc(q.Code) + '">' + UI.face(q, 36) + '<span class="ps-pt"><b>' + esc(q.Player) + '</b><span>' + esc(q.Club) + ' · ' + esc(q.Pos) + (q.Team ? ' · ' + esc(q.Team) : q.Owner && q.Owner !== 'FREE' ? ' · ' + esc(q.Owner) : ' · free agent') + '</span></span>' + UI.statusChip(q) + UI.icon('chev', 16, 'var(--tx4)') + '</button>').join('') + '</div>' : '')
      + (teams.length && teams.length <= 4 ? UI.sh(teams.length === 1 ? 'The club' : 'The clubs') + '<div class="card">' + teams.map(t => '<button class="row tap ps-p" data-open="manager:' + esc(t) + '">' + UI.crest(t, 32) + '<span class="ps-pt"><b>' + esc(t) + '</b><span>' + esc(TEAMS[t].mgr) + '</span></span>' + UI.icon('chev', 16, 'var(--tx4)') + '</button>').join('') + '</div>' : '')
      + (links ? UI.sh('Go to') + '<div class="card">' + links + '</div>' : '')
      + '<p class="ps-note">' + esc(V.name) + ' is a fictional voice. Every number in this post comes from the league data shown above.</p>'
      + '</div>';
  },
  mount(el, id) { restoreCarousels(el); SHOW.repaint(); },
  unmount(el) { if (el.querySelector('.show-player')) SHOW.stop(); stopSpeaking(); },
};
