/* feed/build.js — data in, posts out. Each builder states facts from D and the engine, and carries them on the post. */
import * as UI from '../ui.js';
import {
  esc, words, Words, WORDS, list, poss, possT, plural, ROUND_WORD, f1, oddsTxt, lsGet, dayMonth, relTime, logTime, gwDoneTime, buildUpTime,
  short, firstOf, mgrOf, byName, ptsOver, finishedGws, fxOf, fxFor, oppOf, newsLabel, newsWhen, chanceOf, statusWord, kickoffs, dt, hash,
} from './util.js';
import {
  results, benchStory, record, tableOrder, posOf, recordsTo, motmTotals, periodDone, perfLuck, resultsLuck, luckiestPlayer, freeAgents, roundOne,
  worstPick, pickText, flagged, selectionCall, dangerMan, preKick, dealGroups, contested, deniedWhy, sim, oddsBefore, shows, mmss, starMan, wp, tp, ms, ex,
} from './facts.js';

const T = (d, min) => new Date((d ? d.getTime() : 0) + (min || 0) * 60e3);
const strong = s => '<strong>' + s + '</strong>';
const pt = n => n + (Math.abs(n) === 1 ? ' pt' : ' pts');
const name = t => esc(t);
const mins = () => { const live = (D.cf || []).filter(x => num(x.GW) === D.gw && fin(x.Started) && !fin(x.Finished)); return live.length ? Math.max(...live.map(x => num(x.Mins))) : 0; };
const liveLabel = () => { const m = mins(); return m ? 'Live · ' + m + '’' : 'Live'; };
const liveTime = () => { const k = (D.cf || []).filter(x => num(x.GW) === D.gw && fin(x.Started)).map(x => dt(x['Kickoff (UTC)'])).filter(Boolean).sort((a, b) => b - a)[0]; return k ? T(k, mins()) : (gwDeadline(D.gw) || new Date()); };
const derbyOr = (r, team) => r.nm ? r.nm : (team === r.home ? r.away : r.home);
const marginWords = m => m === 1 ? 'a single point' : words(m) + ' points';
const pctPair = w => w.h + '–' + w.a + '%';
/* the H2H series line from the engine ("PJ leads 4–3"), as a sentence part */
const sr = (a, b) => series(a, b);
const srLine = (a, b) => { const s = sr(a, b); if (!s) return ''; if (s === 'First ever meeting') return 'their first ever meeting'; return s.replace(' leads ', ' leads the series ').replace(/^Series level /, 'the series is level at '); };
const cap = s => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
const pname = per => String(per[0]).replace(' & ', '–');
/* "the Devils", "the Gulls"; names that aren't plurals stay whole */
export const theShort = t => { const s = short(t); return s !== t && /s$/.test(s) ? 'the ' + s : t; };
/* ============================== ARCHIZIO ============================== */
function archizio(out, you) {
  /* DEAL DONE: every waiver run and free-agent move */
  dealGroups().forEach(g => {
    if (!g.ok.length) return;
    const ins = g.ok.map(r => r.In), outs = g.ok.map(r => r.Out), n = g.ok.length;
    const via = g.type === 'W' ? 'waivers' : 'free agency';
    let text;
    if (n === 1) text = strong('DEAL DONE.') + ' ' + name(g.team) + ' sign ' + esc(ins[0]) + (g.type === 'W' ? ' on waivers' : ' as a free agent') + '. ' + esc(outs[0]) + ' leaves.';
    else text = strong('DEAL DONE.') + ' ' + name(g.team) + (g.type === 'W' ? ' complete ' + words(n) + ' signings in one waiver run. ' : ' make ' + words(n) + ' free-agent signings. ') + esc(list(ins)) + ' arrive; ' + esc(list(outs)) + ' leave.';
    const slides = g.ok.map(r => ({ code: r.pin ? String(r.pin.Code) : '', name: r.In, out: r.Out, team: g.team, via: g.type === 'W' ? 'Waivers' : 'Free agent' }));
    out.push({
      id: 'deal:' + g.key, voice: 'archizio', kind: 'deal', ts: g.at, time: relTime(g.at), gw: g.gw, teams: [g.team], players: slides.map(s => s.code).filter(Boolean),
      text, media: { type: 'deal', slides },
      facts: 'Transactions · ' + dayMonth(g.at) + ' ' + (g.type === 'W' ? 'waivers' : 'free agency') + ' · ' + n + ' accepted' + (g.no.length ? ', ' + g.no.length + ' denied' : ''),
      detail: g.rows.map(r => ({ k: esc(r.In) + ' in, ' + esc(r.Out) + ' out', v: esc(r.Result) })),
      links: [{ label: g.team === you ? 'Transfers' : short(g.team), ...(g.team === you ? { href: '#/team/transfers' } : { open: 'manager:' + g.team }) }],
      share: 'Deal done: ' + g.team + ' sign ' + list(ins) + ' via ' + via + '.',
    });
  });

  /* contested claims: two or more clubs after one player in a gameweek's waivers */
  const C = contested();
  Object.keys(C).forEach(gw => {
    const rows = C[gw].sort((a, b) => b.teams.length - a.teams.length); const at = rows.map(r => r.at).sort((a, b) => b - a)[0];
    let text;
    if (rows.length === 1) {
      const r = rows[0];
      text = r.winner ? strong('UNDERSTAND.') + ' The move for ' + esc(r.name) + ' collapsed for ' + esc(list(r.losers)) + ': ' + name(r.winner) + ' got there first.'
        : strong('UNDERSTAND.') + ' ' + Words(r.teams.length) + ' clubs claimed ' + esc(r.name) + ' in the GW' + gw + ' waivers. Nobody got him.';
    } else {
      const top = rows.slice(0, 2).map((r, i) => (i ? words(r.teams.length) : Words(r.teams.length)) + ' clubs claimed ' + esc(r.name)).join(' and ');
      const won = rows.filter(r => r.winner).slice(0, 2).map(r => name(r.winner) + ' got ' + esc(r.name));
      text = strong('UNDERSTAND.') + ' The GW' + gw + ' waivers had ' + words(rows.length) + ' contested players. ' + top + '. ' + (won.length ? cap(list(won)) + '.' : '');
    }
    out.push({
      id: 'race:' + gw + ':' + rows.map(r => r.name).join(','), voice: 'archizio', kind: 'race', ts: at, time: relTime(at), gw: +gw, teams: [...new Set(rows.flatMap(r => r.teams))], players: rows.map(r => r.p && String(r.p.Code)).filter(Boolean),
      text, media: { type: 'race', gw: +gw, rows },
      facts: 'Transactions · GW' + gw + ' waivers · ' + rows.length + ' contested ' + plural(rows.length, 'player'),
      detail: rows.map(r => ({ k: esc(r.name), v: r.winner ? 'Won by ' + esc(r.winner) + '; denied: ' + esc(list(r.losers)) : 'Denied for ' + esc(list(r.teams)) })),
      links: [], share: 'GW' + gw + ' waivers: ' + rows.map(r => r.name + (r.winner ? ' to ' + r.winner : '')).join(', ') + '.',
    });
  });

  const done = D.gwsDone, after = done ? gwDoneTime(done) : null;
  const pre = !D.dlPassed, bu = buildUpTime(D.gw);

  /* injuries and doubts on owned starters (before the deadline) */
  if (pre) {
    const teams = Object.keys(TEAMS).map(t => ({ t, f: flagged(t) })).filter(x => x.f.xi.length);
    const total = teams.reduce((s, x) => s + x.f.xi.length, 0);
    if (total) {
      const most = teams.slice().sort((a, b) => b.f.xi.length - a.f.xi.length);
      const topN = most.filter(x => x.f.xi.length === most[0].f.xi.length).map(x => x.t);
      const ids = teams.flatMap(x => x.f.xi.map(p => p.Code + statusWord(p))).join(',');
      out.push({
        id: 'treat:' + D.gw + ':' + hash(ids), voice: 'archizio', kind: 'treat', ts: T(bu, 70), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: teams.map(x => x.t), players: teams.flatMap(x => x.f.xi.map(p => String(p.Code))),
        text: strong('INJURY WATCH.') + ' ' + Words(total) + ' ' + plural(total, 'starter') + ' carry a flag into GW' + D.gw + '. ' + (topN.length === 1 ? name(topN[0]) + ' have the most: ' + words(most[0].f.xi.length) + '.' : esc(list(topN)) + ' have ' + words(most[0].f.xi.length) + ' each.'),
        media: { type: 'treat', groups: teams.sort((a, b) => posOf(a.t) - posOf(b.t)).map(x => ({ team: x.t, codes: x.f.xi.map(p => String(p.Code)) })) },
        facts: 'FPL injury news · projected XIs for GW' + D.gw,
        detail: teams.flatMap(x => x.f.xi.map(p => ({ k: esc(p.Player) + ' · ' + esc(short(x.t)), v: esc(p.News || statusWord(p)) }))),
        links: [], share: total + ' starters carry a flag into GW' + D.gw + '.',
      });
      /* the club with the most points at stake */
      const stake = teams.map(x => ({ ...x, last: x.f.xi.map(p => ({ p, pts: done ? ptsOver(p.Code, [done]) : 0 })) })).map(x => ({ ...x, sum: x.last.reduce((s, y) => s + y.pts, 0) })).sort((a, b) => b.sum - a.sum || b.f.xi.length - a.f.xi.length)[0];
      if (stake && stake.f.xi.length >= 2 && stake.t !== you) {
        const ps = stake.f.xi.slice(0, 4), nm = ps.map(p => p.Player);
        const same = ps.every(p => statusWord(p) === statusWord(ps[0]));
        const pts = stake.last.slice(0, 4).map(x => x.pts), samePts = pts.every(v => v === pts[0]) && pts[0] > 0;
        let tx = strong('UNDERSTAND.') + ' ' + name(stake.t) + ' are sweating on ' + esc(list(nm)) + '.';
        if (done && samePts) tx += ' ' + (ps.length === 2 ? 'Both' : 'All ' + words(ps.length)) + ' scored ' + pts[0] + ' in GW' + done + '.';
        else if (done && stake.sum > 0) tx += ' Between them: ' + stake.sum + ' points in GW' + done + '.';
        if (same && ps[0].Status === 'd') tx += ' ' + (ps.length === 2 ? 'Both are ' : 'All ' + words(ps.length) + ' are ') + statusWord(ps[0]) + ' for GW' + D.gw + '.';
        out.push({
          id: 'sweat:' + D.gw + ':' + stake.t + ':' + hash(ps.map(p => p.Code + statusWord(p)).join()), voice: 'archizio', kind: 'sweat', ts: T(bu, 84), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [stake.t], players: ps.map(p => String(p.Code)),
          text: tx, media: { type: 'injcards', codes: ps.map(p => String(p.Code)) },
          facts: 'FPL injury news' + (done ? ' · GW' + done + ' points' : ''),
          detail: ps.map(p => ({ k: esc(p.Player), v: esc(p.News) + (done ? ' · GW' + done + ': ' + pt(ptsOver(p.Code, [done])) + '' : '') })),
          links: [{ label: short(stake.t), open: 'manager:' + stake.t }], share: stake.t + ' are sweating on ' + list(nm) + '.',
        });
      }
    }
    /* EXCLUSIVE: an owned player out with no return date */
    const longOut = (D.ro || []).filter(p => p.Status === 'i' && /unknown return/i.test(String(p.News))).map(p => ({ p, pick: String(p.Drafted).match(/^R(\d+)/) })).sort((a, b) => (a.pick ? +a.pick[1] : 99) - (b.pick ? +b.pick[1] : 99))[0];
    if (longOut) {
      const p = longOut.p, rd = longOut.pick ? +longOut.pick[1] : 0, sp = num(p['Season pts']);
      out.push({
        id: 'excl:' + p.Code + ':' + hash(p.News), voice: 'archizio', kind: 'excl', ts: T(bu, 80), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [p.Team], players: [String(p.Code)],
        text: strong('EXCLUSIVE.') + ' ' + esc(p.Player) + ': ' + esc(String(p.News).split(/\s+-\s+/)[0].toLowerCase()) + ', no return date. ' + esc(possT(p.Team)) + (rd ? ' ' + ROUND_WORD[rd] + '-round pick' : ' pick') + (sp ? ' has ' + sp + ' ' + plural(sp, 'point') + ' this season.' : ' is yet to score a point this season.'),
        media: { type: 'injcards', codes: [String(p.Code)], wide: true },
        facts: 'FPL injury news · draft ' + esc(p.Drafted) + ' · season points',
        detail: [{ k: 'News', v: esc(p.News) }, { k: 'Drafted', v: esc(p.Drafted) }, { k: 'Season points', v: String(sp) }],
        links: [{ label: p.Player, open: 'player:' + p.Code }], share: p.Player + ': no return date.',
      });
    }
    /* derby build-up */
    const derbies = fxOf(D.gw).filter(f => derbyName(f.Home, f.Away));
    if (derbies.length) {
      const bits = derbies.map(f => { const s = sr(f.Home, f.Away); return esc(derbyName(f.Home, f.Away)) + (s && s !== 'First ever meeting' ? ' (' + esc(s.replace(' leads ', ' leads ')) + ')' : ''); });
      out.push({
        id: 'derbies:' + D.gw, voice: 'archizio', kind: 'derbies', ts: T(bu, 87), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: derbies.flatMap(f => [f.Home, f.Away]), players: [],
        text: strong('DERBY WEEK.') + ' ' + (derbies.length === 1 ? 'One derby in GW' + D.gw + ': ' : Words(derbies.length) + ' derbies in GW' + D.gw + ': ') + list(bits) + '.',
        media: { type: 'derbies', fx: derbies.map(f => ({ h: f.Home, a: f.Away })) },
        facts: 'League derbies · H2H series incl. last season',
        detail: derbies.map(f => ({ k: esc(derbyName(f.Home, f.Away)), v: esc(f.Home) + ' v ' + esc(f.Away) + ' · ' + esc(sr(f.Home, f.Away) || '') })),
        links: [{ label: 'Derbies', href: '#/league/derbies' }], share: 'Derby week: ' + derbies.map(f => derbyName(f.Home, f.Away)).join(', ') + '.',
      });
    }
  }

  if (!done) return;

  /* FREE AGENT WATCH */
  const fa = freeAgents(3);
  if (fa.length) {
    const a = fa[0], two = a.l2 >= a.l3 * .6 && a.n >= 2;
    let tx = esc(a.p.Player) + ': ' + (two ? a.l2 + ' points in his last two gameweeks.' : a.l3 + ' points in the last ' + words(a.n) + ' gameweeks.');
    if (a.droppedBy) tx += ' Unowned since ' + name(a.droppedBy) + ' let him go' + (a.droppedOn ? ' on ' + dayMonth(a.droppedOn) : '') + '.';
    tx += ' Eight managers, no takers.';
    out.push({
      id: 'fa:' + done + ':' + fa.map(x => x.p.Code).join(','), voice: 'archizio', kind: 'fa', ts: T(after, 40), time: 'After GW' + done, gw: done, teams: a.droppedBy ? [a.droppedBy] : [], players: fa.map(x => String(x.p.Code)),
      text: tx, media: { type: 'fa', rows: fa.map(x => ({ code: String(x.p.Code), name: x.p['Full name'] && String(x.p['Full name']).length < 22 ? x.p['Full name'] : x.p.Player, club: x.p.Club, pos: x.p.Pos, l3: x.l3, l2: x.l2, season: x.season, n: x.n })), before: D.gw },
      facts: 'Players · owner FREE · GW Stats GW' + finishedGws(3)[0] + '–' + done + (a.droppedBy ? ' · Transactions ' + dayMonth(a.droppedOn) : ''),
      detail: fa.map(x => ({ k: esc(x.p.Player) + ' · ' + esc(x.p.Club) + ' ' + esc(x.p.Pos), v: pt(x.l3) + ' last ' + x.n + ' · ' + x.season + ' season' })),
      links: [{ label: 'Free agents', href: '#/team/transfers' }], share: a.p.Player + ' is a free agent: ' + a.l3 + ' points in the last ' + a.n + ' gameweeks.',
    });
  }

  /* ROUND ONE, n weeks in */
  const r1 = roundOne();
  if (r1.length && done >= 2) {
    out.push({
      id: 'r1:' + done, wide: true, voice: 'archizio', kind: 'r1', ts: T(after, 24), time: 'After GW' + done, gw: done, teams: r1.map(x => x.p.Team), players: r1.map(x => String(x.p.Code)),
      text: strong('UNDERSTAND.') + ' Round one, ' + words(done) + ' weeks in: ' + r1.map(x => esc(x.p.Player) + ' ' + x.pts).join(', ') + '.',
      media: { type: 'r1', rows: r1.map(x => ({ code: String(x.p.Code), name: x.p.Player, team: x.p.Team, pick: pickText(x.pick), pts: x.pts })), done },
      facts: 'Rosters · Drafted R1 · season points after GW' + done,
      detail: r1.map(x => ({ k: pickText(x.pick) + ' ' + esc(x.p.Player), v: esc(x.p.Team) + ' · ' + pt(x.pts) + '' })),
      links: [], share: 'Round one, ' + done + ' weeks in: ' + r1.map(x => x.p.Player + ' ' + x.pts).join(', ') + '.',
    });
  }

  /* RECORDS: the season high or low set or matched in a gameweek */
  for (let g = 1; g <= done; g++) {
    const R = recordsTo(g), prev = g > 1 ? recordsTo(g - 1) : { hi: null, lo: null };
    [['hi', 'highest'], ['lo', 'lowest']].forEach(([k, word]) => {
      const r = R[k]; if (!r || g === 1) return;
      const now = r.who.filter(w => w[1] === g); if (!now.length) return;
      const before = r.who.filter(w => w[1] < g);
      const who = now.map(w => w[0]);
      let tx;
      if (!before.length) tx = strong('EXCLUSIVE.') + ' ' + esc(list(who)) + ' set the ' + word + ' score of the season in GW' + g + ': ' + r.p + '.' + (prev[k] ? ' The old mark was ' + prev[k].p + '.' : '');
      else tx = strong(r.p + ' AGAIN.') + ' ' + esc(list(who)) + ' match the ' + word + ' score of the season, first posted by ' + esc(before[0][0]) + ' in GW' + before[0][1] + '.';
      const at = gwDoneTime(g);
      out.push({
        id: 'rec:' + k + ':' + g, voice: 'archizio', kind: 'record', ts: T(at, 19), time: 'GW' + g + ' · full time', gw: g, teams: who, players: [],
        text: tx, media: { type: 'stat', big: String(r.p), label: (k === 'hi' ? 'Season high' : 'Season low'), sub: r.who.map(w => short(w[0]) + ' GW' + w[1]).join(' · '), team: who[0] },
        facts: 'H2H Fixtures · finished GW1–' + g,
        detail: r.who.map(w => ({ k: esc(w[0]), v: 'GW' + w[1] + ' · ' + r.p })), links: [{ label: 'Results', href: '#/league/results' }], share: tx.replace(/<[^>]+>/g, ''),
      });
    });
  }

  /* MANAGER OF THE MONTH: winners of finished periods, and the race in the current one */
  PERIODS.forEach(per => {
    if (per[1] > D.gw) return;
    const T2 = motmTotals(per); if (!T2.any) return;
    const [lead, pts] = T2.rows[0], tie = T2.rows.filter(r => r[1] === pts).map(r => r[0]);
    if (periodDone(per)) {
      const at = gwDoneTime(per[2]);
      out.push({
        id: 'motm:' + per[0], voice: 'archizio', kind: 'motm', ts: T(at, 15), time: 'GW' + per[2] + ' · full time', gw: per[2], teams: tie, players: [],
        text: strong('EXCLUSIVE.') + ' ' + esc(list(tie)) + (tie.length > 1 ? ' share' : ' are') + ' Manager of the Month for ' + esc(pname(per)) + ': ' + pts + ' points over GW' + per[1] + '–' + per[2] + '. $30' + (tie.length === 1 ? ' to ' + esc(firstOf(lead)) : '') + '.',
        media: { type: 'stat', big: String(pts), label: 'Manager of the Month · ' + pname(per), sub: 'GW' + per[1] + '–' + per[2] + ' · $30', team: lead, rows: T2.rows.slice(0, 3) },
        facts: 'H2H Fixtures · points for, GW' + per[1] + '–' + per[2],
        detail: T2.rows.map(r => ({ k: esc(r[0]), v: pt(r[1]) + '' })), links: [{ label: 'Money', href: '#/league/money' }], share: lead + ' are Manager of the Month for ' + pname(per) + ' with ' + pts + ' points.',
      });
    } else {
      const live = UI.week().mode === 'live' || D.provOver, upTo = live ? D.gw : D.gwsDone;
      const at = D.provOver ? T(kickoffs(D.gw).slice(-1)[0], 110) : live ? liveTime() : gwDoneTime(D.gwsDone);
      out.push({
        id: 'motmrace:' + per[0] + ':' + upTo + (live ? ':' + lead : ''), voice: 'archizio', kind: 'motm', ts: T(at, live ? 0 : 14), time: D.provOver ? 'GW' + D.gw + ' · provisional' : live ? liveLabel() : 'After GW' + D.gwsDone, gw: upTo, teams: tie, players: [],
        text: strong('UNDERSTAND.') + ' ' + esc(pname(per)) + ' so far: ' + esc(list(tie)) + ' lead the Manager of the Month race on ' + pts + '.' + (T2.rows[1] && T2.rows[1][1] < pts ? ' ' + esc(T2.rows[1][0]) + ' ' + (pts - T2.rows[1][1]) + ' back.' : '') + (live ? ' Includes GW' + D.gw + (D.provOver ? ' provisional scores.' : ' live scores.') : ''),
        media: { type: 'stat', big: String(pts), label: 'Manager of the Month · ' + pname(per), sub: (per[1] === Math.min(per[2], upTo) ? 'GW' + per[1] : 'GW' + per[1] + '–' + Math.min(per[2], upTo)) + ' so far · $30', team: lead, rows: T2.rows.slice(0, 3) },
        facts: 'H2H Fixtures · points for, ' + (per[1] === upTo ? 'GW' + per[1] : 'GW' + per[1] + '–' + upTo) + (D.provOver ? ' (provisional)' : live ? ' (live)' : ''),
        detail: T2.rows.map(r => ({ k: esc(r[0]), v: pt(r[1]) + '' })), links: [{ label: 'Money', href: '#/league/money' }], share: lead + ' lead the ' + pname(per) + ' Manager of the Month race on ' + pts + '.',
      });
    }
  });

  /* TITLE ODDS and the BAHA MARKET (after the simulation has run for this data) */
  let S = sim(), saved = false;
  if (S) {
    const ord = Object.keys(S.title).sort((a, b) => S.title[b] - S.title[a]);
    const prev = saved ? null : oddsBefore();
    let mover = null;
    if (prev) mover = ord.map(t => ({ t, d: S.title[t] - (prev.title[t] || 0) })).sort((a, b) => Math.abs(b.d) - Math.abs(a.d))[0];
    const top = ord[0];
    const asOf = D.provOver ? 'GW' + D.gw + ' (provisional)' : 'GW' + D.gwsDone;
    let tx = strong('UNDERSTAND.') + ' The model has ' + name(top) + ' as title favourites after ' + asOf + ': ' + oddsTxt(S.title[top]) + ' from 5,000 simulated seasons. ' + ord.slice(1, 3).map(t => esc(t) + ' ' + oddsTxt(S.title[t])).join(', ') + '.';
    if (mover && Math.abs(mover.d) >= 2) tx += ' Biggest mover since GW' + prev.gw + ': ' + esc(mover.t) + ', ' + (mover.d > 0 ? 'up ' : 'down ') + Math.round(Math.abs(mover.d)) + ' points.';
    out.push({
      id: 'odds:' + D.gwsDone + (D.provOver ? 'p' : ''), wide: true, voice: 'archizio', kind: 'odds', ts: D.provOver ? T(kickoffs(D.gw).slice(-1)[0], 140) : T(after, 34), time: D.provOver ? 'GW' + D.gw + ' · provisional' : 'After GW' + D.gwsDone, gw: D.gwsDone, teams: ord.slice(0, 3), players: [],
      text: tx, media: { type: 'odds', rows: ord.map(t => ({ team: t, v: S.title[t], d: prev ? S.title[t] - (prev.title[t] || 0) : null })), prev: prev ? prev.gw : null },
      facts: 'Title odds · 5,000 simulated seasons · results to ' + asOf + (saved ? ' · saved on this phone at full time' : '') + (prev ? ' · GW' + prev.gw + ' odds saved on this phone' : ''),
      detail: ord.map(t => ({ k: esc(t), v: oddsTxt(S.title[t]) + (prev ? ' (GW' + prev.gw + ': ' + oddsTxt(prev.title[t] || 0) + ')' : '') })), links: [{ label: 'Table', href: '#/league/overview' }],
      share: top + ' are title favourites at ' + oddsTxt(S.title[top]) + '.',
    });
    const B = 'Kobbie Mainoo Fan';
    if (S.last[B] !== undefined) {
      const p = posOf(B), v = S.last[B];
      const bp = prev && prev.last ? prev.last[B] : null;
      out.push({
        id: 'baha:' + D.gwsDone + (D.provOver ? 'p' : ''), voice: 'archizio', kind: 'market', ts: D.provOver ? T(kickoffs(D.gw).slice(-1)[0], 139) : T(after, 29), time: D.provOver ? 'GW' + D.gw + ' · provisional' : 'After GW' + D.gwsDone, gw: D.gwsDone, teams: [B], players: [],
        text: strong('THE BAHA MARKET.') + ' ' + name(B) + ' to finish last: ' + oddsTxt(v) + '. ' + (p === 1 ? 'They are top of the table' : 'They are ' + UI.esc(['', 'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth'][p] || p) + ' in the table') + (D.provOver ? ' on provisional scores.' : ' after ' + words(D.gwsDone) + '.') + (bp !== null && bp !== undefined ? ' It was ' + oddsTxt(bp) + ' after GW' + prev.gw + '.' : ''),
        media: { type: 'market', v, pos: p, team: B, prev: bp, prevGw: prev ? prev.gw : null },
        facts: 'Chance of finishing 8th · 5,000 simulated seasons · resolves GW38', detail: [{ k: 'Chance of last', v: oddsTxt(v) }, { k: 'Table now', v: 'Position ' + p }], links: [{ label: 'Table', href: '#/league/overview' }],
        share: 'The Baha market: Kobbie Mainoo Fan to finish last, ' + oddsTxt(v) + '.',
      });
    }
  }

  /* DEADLINE XIs: once team sheets are in, the biggest benchings */
  if (D.dlPassed && typeof lineupsLocked === 'function' && lineupsLocked()) {
    const benched = Object.keys(TEAMS).flatMap(t => benchOf(t).filter(p => p.Status === 'a').map(p => ({ p, t, sp: num(p['Season pts']) }))).sort((a, b) => b.sp - a.sp).slice(0, 3);
    if (benched.length) {
      const k = kickoffs(D.gw)[0], at = gwDeadline(D.gw);
      out.push({
        id: 'sheets:' + D.gw, voice: 'archizio', kind: 'sheets', ts: T(at, 1), time: 'GW' + D.gw + ' deadline', gw: D.gw, teams: benched.map(x => x.t), players: benched.map(x => String(x.p.Code)),
        text: strong('EXCLUSIVE.') + ' Team sheets are in for GW' + D.gw + '. Biggest call: ' + name(benched[0].t) + ' bench ' + esc(benched[0].p.Player) + ', ' + benched[0].sp + ' points this season.' + (benched[1] ? ' Also on a bench: ' + list(benched.slice(1).map(x => esc(x.p.Player) + ' (' + esc(short(x.t)) + ')')) + '.' : ''),
        media: { type: 'injcards', codes: benched.map(x => String(x.p.Code)), chip: 'BENCH' },
        facts: 'Rosters · GW XI at the deadline · season points', detail: benched.map(x => ({ k: esc(x.p.Player), v: esc(x.t) + ' · bench · ' + pt(x.sp) + '' })), links: [], share: 'Team sheets are in for GW' + D.gw + '.',
      });
    }
  }
}

/* ============================== CLARK ============================== */
function clark(out, you) {
  const done = D.gwsDone;
  /* bench disasters in a defeat, every finished gameweek */
  for (let g = 1; g <= done; g++) {
    benchStory(g).forEach((b, i) => {
      if (i > 0) return;
      const at = gwDoneTime(g), sl = (D.gwsByGw[g] || {})[b.top.code] || {};
      const extra = sl.G && sl.A ? ' Goal and an assist, sat on the bench.' : sl.G ? ' ' + Words(sl.G) + ' ' + plural(sl.G, 'goal') + ', sat on the bench.' : sl.A ? ' ' + Words(sl.A) + ' ' + plural(sl.A, 'assist') + ', sat on the bench.' : '';
      const vs = b.r.nm ? esc(b.r.nm) : 'to ' + esc(b.opp);
      out.push({
        id: 'bench:' + g + ':' + b.team, voice: 'clark', kind: 'thumb', ts: T(at, 38), time: relTime(at), gw: g, teams: [b.team, b.opp], players: [b.top.code],
        text: name(b.team) + ' left ' + esc(poss(b.top.name)) + ' ' + b.top.pts + ' points on the bench and lost ' + vs + ' by ' + strong(b.margin <= 20 ? WORDS(b.margin) : String(b.margin)) + '.' + extra,
        media: { type: 'thumb', code: b.top.code, t1: b.top.pts + ' ' + plural(b.top.pts, 'POINT'), t2: 'ON THE BENCH', lo: 'LOST BY ' + (b.margin <= 20 ? WORDS(b.margin) : b.margin), chip: 'GW' + g, style: 'split' },
        facts: 'GW' + g + ' · ' + b.top.name + ' ' + b.top.pts + ' on the bench · ' + b.team + ' ' + b.score + '–' + b.oppScore,
        detail: b.bench.map(x => ({ k: esc(x.name) + ' (bench)', v: pt(x.pts) + ' · ' + x.mins + '’' })).concat([{ k: 'Bench total', v: String(b.tot) }, { k: 'Result', v: esc(b.team) + ' ' + b.score + '–' + b.oppScore + ' ' + esc(b.opp) }]),
        links: [{ label: 'Results', href: '#/league/results' }], share: b.team + ' left ' + b.top.name + '’s ' + b.top.pts + ' points on the bench and lost by ' + b.margin + '.',
      });
    });
  }
  if (!done) { clarkPoll(out, you); return; }
  const after = gwDoneTime(done);

  /* hot take: the week's biggest margin */
  const big = results(done).filter(r => r.done && r.margin > 0).sort((a, b) => b.margin - a.margin)[0];
  if (big && big.margin >= 10) {
    const ws = big.win === big.home ? big.hs : big.as;
    out.push({
      id: 'margin:' + done, voice: 'clark', kind: 'take', ts: T(after, 23), time: 'After GW' + done, gw: done, teams: [big.win, big.lose], players: [],
      text: strong(WORDS(big.margin) + '.') + ' That’s the margin ' + name(big.win) + ' beat ' + name(big.lose) + ' by in GW' + done + '. ' + ws + ' on the board, the biggest win of the week.',
      media: { type: 'stamp', big: (big.win === big.home ? big.hs + '–' + big.as : big.as + '–' + big.hs), sub: 'Biggest win of GW' + done, a: big.win, b: big.lose }, facts: 'H2H Fixtures · GW' + done, detail: results(done).map(r => ({ k: esc(r.home) + ' v ' + esc(r.away), v: r.hs + '–' + r.as })), links: [{ label: 'Results', href: '#/league/results' }],
      share: big.win + ' beat ' + big.lose + ' by ' + big.margin + ' in GW' + done + '.',
    });
  }

  /* losing runs and winless starts */
  const runs = Object.keys(TEAMS).map(t => ({ t, r: record(t) })).filter(x => (x.r.kind === 'L' && x.r.run >= 3) || (x.r.w === 0 && x.r.played >= 3)).sort((a, b) => b.r.run - a.r.run);
  if (runs.length) {
    const x = runs[0], r = x.r, nf = fxFor(x.t, D.gw), opp = nf ? oppOf(nf, x.t) : null, dn = nf ? derbyName(nf.Home, nf.Away) : null;
    const all = r.l === r.played;
    const tx = name(x.t) + ': ' + (all ? 'played ' + words(r.played) + ', lost ' + words(r.l) + '.' : r.w === 0 ? 'no wins in ' + words(r.played) + '.' : words(r.run) + ' defeats in a row.') + (nf && !D.dlPassed ? ' ' + (dn ? esc(dn) + ' is next.' : 'Next up: ' + esc(opp) + '.') + ' Who’s stopping the rot?' : '');
    out.push({
      id: 'run:' + done + ':' + x.t, voice: 'clark', kind: 'thumb', ts: (nf && !D.dlPassed) ? T(buildUpTime(D.gw), 81) : T(after, 27), time: (nf && !D.dlPassed) ? 'GW' + D.gw + ' build-up' : 'After GW' + done, gw: done, teams: [x.t].concat(opp ? [opp] : []), players: [],
      text: tx,
      media: { type: 'thumb', team: x.t, t1: all ? r.w + ' FROM ' + r.played : r.w === 0 ? 'NO WINS' : r.run + ' IN A ROW', t2: nf && !D.dlPassed ? (dn ? dn.replace(/^The /, '').toUpperCase() + ' NEXT' : 'NEXT: ' + short(opp).toUpperCase()) : all ? WORDS(r.l) + ' DEFEATS' : r.w === 0 ? 'IN ' + WORDS(r.played) : 'DEFEATS', lo: short(x.t).toUpperCase(), chip: 'GW1–' + done, style: 'stripes' },
      facts: 'H2H Fixtures · ' + short(x.t) + ' ' + r.w + '–' + r.d + '–' + r.l + ' W–D–L', detail: [{ k: 'Record', v: r.w + '–' + r.d + '–' + r.l + ' W–D–L' }, { k: 'Results', v: r.res.join(' ') }],
      links: [{ label: short(x.t), open: 'manager:' + x.t }], share: tx.replace(/<[^>]+>/g, ''),
    });
  }

  /* luck: performance (actual excl. bonus v xP) — a separate post from results luck (all-play) */
  const L = perfLuck();
  if (L.length >= 2 && L[0].d >= 8) {
    const a = L[0], b = L[1], lp = luckiestPlayer(a.team);
    out.push({
      id: 'luck:' + done, voice: 'clark', kind: 'thumb', ts: T(after, 33), time: 'After GW' + done, gw: done, teams: [a.team], players: lp ? [String(lp.code)] : [],
      text: strong(WORDS(a.d) + '.') + ' That’s how many points ' + name(a.team) + ' are running above expected. Next best: ' + esc(b.team) + ', ' + (b.d >= 0 ? '+' : '−') + Math.abs(Math.round(b.d)) + '.' + (lp && lp.d >= 5 ? ' ' + esc(lp.name) + ' alone is +' + Math.round(lp.d) + '.' : ''),
      media: { type: 'thumb', code: lp ? String(lp.code) : '', team: a.team, t1: '+' + Math.round(a.d), t2: 'ABOVE EXPECTED', lo: 'RUNNING HOT', chip: 'GW1–' + done, style: 'yellow' },
      facts: 'Started points excl. bonus v xP · GW1–' + done,
      detail: L.map(x => ({ k: esc(x.team), v: (x.d >= 0 ? '+' : '−') + f1(Math.abs(x.d)) + ' (' + x.act + ' v ' + f1(x.x) + ' xP)' })), links: [{ label: 'Stats', href: '#/league/stats' }],
      share: a.team + ' are ' + Math.round(a.d) + ' points above expected.',
    });
  }
  const RL = resultsLuck();
  if (RL.length && RL[0].d <= -3) {
    const a = RL[0];
    out.push({
      id: 'robbed:' + done, voice: 'clark', kind: 'take', ts: T(after, 18), time: 'After GW' + done, gw: done, teams: [a.team], players: [],
      text: strong(WORDS(a.pts) + '.') + ' That’s ' + esc(possT(a.team)) + ' league points. Against all seven, every week, they’d have ' + f1(a.ap) + '. Robbed.',
      media: { type: 'robbed', team: a.team, pts: a.pts, ap: a.ap }, facts: 'All-play: every score v all seven rivals · GW1–' + done,
      detail: RL.map(x => ({ k: esc(x.team), v: pt(x.pts) + ' v ' + f1(x.ap) + ' all-play' })), links: [{ label: 'Stats', href: '#/league/stats' }],
      share: a.team + ' have ' + a.pts + ' league points; all-play says ' + f1(a.ap) + '.',
    });
  }

  /* the worst pick of the draft so far */
  const wp = worstPick();
  if (wp) {
    const rw = ROUND_WORD[wp.pick.r];
    out.push({
      id: 'worst:' + done + ':' + wp.p.Code, voice: 'clark', kind: 'thumb', ts: T(after, 28), time: 'After GW' + done, gw: done, teams: [wp.p.Team], players: [String(wp.p.Code)],
      text: esc(wp.p.Player) + ' went in round ' + words(wp.pick.r) + ' for ' + name(wp.p.Team) + '. ' + Words(done) + ' gameweeks: ' + strong(wp.pts + ' ' + plural(wp.pts, 'point')) + '.',
      media: { type: 'thumb', code: String(wp.p.Code), t1: wp.pts + ' ' + plural(wp.pts, 'POINT'), t2: rw.toUpperCase() + '-ROUND PICK', lo: 'WORST PICK SO FAR', chip: pickText(wp.pick), style: 'split' },
      facts: 'Rosters · drafted ' + pickText(wp.pick) + ' · season points after GW' + done, detail: [{ k: 'Drafted', v: pickText(wp.pick) }, { k: 'Season points', v: String(wp.pts) }],
      links: [{ label: wp.p.Player, open: 'player:' + wp.p.Code }], share: wp.p.Player + ': round ' + wp.pick.r + ' pick, ' + wp.pts + ' points.',
    });
  }

  clarkPoll(out, you);

  /* live: a starter still waiting while his club's match is well under way */
  if (D.liveNow) {
    const c = Object.keys(TEAMS).flatMap(t => xiOf(t).map(p => ({ p, t }))).map(x => { const cf = (D.cf || []).find(f => num(f.GW) === D.gw && (f.Home === x.p.Club || f.Away === x.p.Club) && fin(f.Started) && !fin(f.Finished)); return cf ? { ...x, cf, m: num(cf.Mins) } : null; })
      .filter(x => x && x.m >= 45 && num(x.p['GW mins']) === 0).sort((a, b) => (b.t === you) - (a.t === you) || (epOf(b.p.Code) || 0) - (epOf(a.p.Code) || 0))[0];
    if (c) {
      const ko = dt(c.cf['Kickoff (UTC)']);
      out.push({
        id: 'waiting:' + D.gw + ':' + c.p.Code, voice: 'clark', kind: 'thumb', ts: T(ko, c.m + 1), time: 'Live · ' + c.m + '’', gw: D.gw, teams: [c.t], players: [String(c.p.Code)],
        text: c.m + ' minutes gone at ' + esc(UI.club(c.cf.Home)) + ' and ' + esc(possT(c.t)) + ' ' + esc(c.p.Player) + ' hasn’t moved.' + (c.p.Status === 'd' ? ' He went in at ' + chanceOf(c.p) + '%.' : ''),
        media: { type: 'thumb', code: String(c.p.Code), t1: String(c.p.Player).toUpperCase(), t2: 'STILL ON THE BENCH', lo: c.m + ' MINUTES GONE', chip: c.m + '’', style: 'stripes', live: true },
        facts: 'Club Fixtures · ' + c.cf.Home + ' v ' + c.cf.Away + ' ' + c.m + '’ · Rosters GW mins 0', detail: [{ k: 'Match', v: esc(c.cf.Home) + ' ' + esc(c.cf['Home goals']) + '–' + esc(c.cf['Away goals']) + ' ' + esc(c.cf.Away) + ' · ' + c.m + '’' }, { k: c.p.Player, v: 'In ' + esc(c.t) + '’s XI · 0 minutes' }],
        links: [{ label: 'Matchup', href: '#/matchday/matchup' }], share: c.p.Player + ' still on the bench, ' + c.m + ' minutes gone.',
      });
    }
  }
}
function clarkPoll(out, you) {
  const fx = fxOf(D.gw); if (!fx.length) return;
  const mine = you ? fx.find(f => f.Home === you || f.Away === you) : null;
  const f = (mine && derbyName(mine.Home, mine.Away)) ? mine : fx.find(x => derbyName(x.Home, x.Away)) || null;
  if (!f) return;
  const nm = derbyName(f.Home, f.Away), w = wp(f), s = sr(f.Home, f.Away);
  const pick = (lsGet('emt-feed-poll', {}) || {})[D.gw + '|' + f.Home + '|' + f.Away];
  const fav = w.h >= w.a ? f.Home : f.Away;
  const bu = buildUpTime(D.gw);
  const sc = D.dlPassed ? ms(f) : null, R = sc && (sc.liveNow || sc.done || D.provOver) ? { hs: sc.hs, as: sc.as2, done: sc.done || D.provOver, live: sc.liveNow && !D.provOver } : null;
  out.push({
    id: 'poll:' + D.gw + ':' + f.Home + '|' + f.Away, voice: 'clark', kind: 'poll', ts: T(bu, 88), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [f.Home, f.Away], players: [],
    text: strong(esc(nm.replace(/^The /, '').toUpperCase()) + '.') + ' ' + (s && s !== 'First ever meeting' ? esc(s.replace(' leads ', ' leads the series ')) + '. ' : '') + 'Who’s having it?',
    media: { type: 'poll', h: f.Home, a: f.Away, w, pick, open: !D.dlPassed, fav, live: R && (R.live || R.done) ? R : null },
    facts: R && R.done ? 'Result ' + R.hs + '–' + R.as + (D.provOver ? ' (provisional)' : '') : 'Win chance ' + w.h + '–' + w.d + '–' + w.a + ' · the model' + (R ? ' now' : ''), detail: [{ k: esc(f.Home), v: w.h + '%' }, { k: 'Draw', v: w.d + '%' }, { k: esc(f.Away), v: w.a + '%' }],
    links: [{ label: 'Matchup', href: '#/matchday/matchup' }], share: nm + ': who’s having it? The model says ' + short(fav) + ' ' + Math.max(w.h, w.a) + '%.',
  });
}

/* ============================== MALCOLM ============================== */
function malcolm(out, you) {
  const done = D.gwsDone, fx = fxOf(D.gw);
  const anyKO = (D.cf || []).some(x => num(x.GW) === D.gw && fin(x.Started));
  const locked = D.dlPassed && !anyKO && !D.provOver;          /* deadline gone, no ball kicked */
  const bu = buildUpTime(D.gw), when = locked ? 'GW' + D.gw + ' deadline' : 'GW' + D.gw + ' build-up';
  const firstKO = kickoffs(D.gw)[0];

  /* previews of every matchup before the deadline */
  if ((!D.dlPassed || locked) && fx.length) {
    const rows = fx.map(f => ({ h: f.Home, a: f.Away, w: wp(f), ph: tp(f.Home), pa: tp(f.Away), nm: derbyName(f.Home, f.Away) }));
    const fav = rows.slice().sort((a, b) => Math.max(b.w.h, b.w.a) - Math.max(a.w.h, a.w.a))[0];
    const close = rows.slice().sort((a, b) => Math.abs(a.w.h - a.w.a) - Math.abs(b.w.h - b.w.a))[0];
    const fv = fav.w.h >= fav.w.a ? fav.h : fav.a;
    out.push({
      id: 'board:' + D.gw, wide: true, voice: 'malcolm', kind: 'board', ts: locked ? T(gwDeadline(D.gw), 3) : T(bu, 85), time: when, gw: D.gw, teams: rows.flatMap(r => [r.h, r.a]), players: [],
      text: (locked ? 'Team sheets are in for gameweek ' + D.gw + (firstKO ? '. First kick-off ' + esc(UI.dayHm(firstKO)) : '') + '. Biggest favourite: ' : 'Gameweek ' + D.gw + ', as the model sees it. Biggest favourite: ') + name(fv) + ' at ' + Math.max(fav.w.h, fav.w.a) + '%. Closest: ' + name(close.h) + ' v ' + name(close.a) + ', ' + pctPair(close.w) + '.',
      media: { type: 'board', rows, gw: D.gw }, facts: 'Projected XIs · projected scores · win chance',
      detail: rows.map(r => ({ k: esc(r.h) + ' v ' + esc(r.a), v: f1(r.ph) + '–' + f1(r.pa) + ' · ' + r.w.h + '–' + r.w.d + '–' + r.w.a + '%' })), links: [{ label: 'All matchups', href: '#/matchday/all' }],
      share: 'GW' + D.gw + ' predictions: ' + rows.map(r => short(r.h) + ' ' + f1(r.ph) + '–' + f1(r.pa) + ' ' + short(r.a)).join(', ') + '.',
    });
    rows.forEach(r => {
      const mineHere = you && (r.h === you || r.a === you);
      if (!r.nm && !mineHere) return;
      const f = fx.find(x => x.Home === r.h && x.Away === r.a), s = sr(r.h, r.a);
      const winless = [r.h, r.a].map(t => ({ t, rec: record(t) })).filter(x => x.rec.played >= 2 && x.rec.w === 0)[0];
      const line = srLine(r.h, r.a);
      const parts = [line ? cap(esc(line)) : '', winless ? (line ? 'and ' : '') + esc(theShort(winless.t)) + ' are still looking for a first win' : ''].filter(Boolean);
      const tx = 'Gameweek ' + D.gw + '. ' + (r.nm ? esc(r.nm) : esc(r.h) + ' v ' + esc(r.a)) + '.' + (parts.length ? ' ' + cap(parts.join(', ')) + '.' : '');
      const dm = mineHere ? dangerMan(you) : null;
      const script = [
        'Gameweek ' + D.gw + '. ' + (r.nm || (r.h + ' against ' + r.a)) + '.',
        r.h + ', projected ' + f1(r.ph) + '. ' + r.a + ', ' + f1(r.pa) + '.',
        s && s !== 'First ever meeting' ? s.replace(/(\d+)–(\d+)/, (m, a, b) => words(+a) + ' to ' + words(+b)).replace(' leads ', ' leads the series ') + '.' : '',
        'Win chance: ' + short(r.h) + ' ' + r.w.h + ', ' + short(r.a) + ' ' + r.w.a + '.',
        dm ? 'The danger man: ' + dm.p.Player + ', projected ' + f1(dm.ep) + ', the most in ' + possT(dm.opp) + ' eleven.' : '',
      ].filter(Boolean);
      out.push({
        id: 'prev:' + D.gw + ':' + r.h + '|' + r.a, voice: 'malcolm', kind: mineHere ? 'voicenote' : 'preview', ts: locked ? T(gwDeadline(D.gw), mineHere ? 2 : 1) : T(bu, mineHere ? 90 : 78), time: when, gw: D.gw, teams: [r.h, r.a], players: dm ? [String(dm.p.Code)] : [],
        text: tx, media: { type: mineHere ? 'voicenote' : 'scorebug', h: r.h, a: r.a, w: r.w, ph: r.ph, pa: r.pa, nm: r.nm, gw: D.gw, script, state: 'pred' },
        facts: 'Projected XIs · win chance · H2H series' + (dm ? ' · ' + dm.p.Player + ' ' + f1(dm.ep) : ''),
        detail: [{ k: 'Predicted', v: f1(r.ph) + '–' + f1(r.pa) }, { k: 'Win chance', v: r.w.h + '% · draw ' + r.w.d + '% · ' + r.w.a + '%' }, { k: 'Series', v: esc(s || '') }].concat(mineHere ? [{ k: 'Narration', v: script.map(esc).join('<br>') }] : []),
        links: [{ label: 'Matchup', href: mineHere ? '#/matchday/matchup' : '#/matchday/all' }], share: (r.nm ? r.nm + ': ' : '') + r.h + ' ' + f1(r.ph) + '–' + f1(r.pa) + ' ' + r.a + ' predicted.',
      });
    });
  }

  /* live: the board, and swings when a win chance crosses 50% */
  if (D.liveNow && anyKO && fx.length) {
    const rows = fx.map(f => { const s = ms(f), w = wp(f); return { h: f.Home, a: f.Away, hs: s.hs, as: s.as2, w, ph: tp(f.Home), pa: tp(f.Away), nm: derbyName(f.Home, f.Away), f }; });
    const at = liveTime();
    out.push({
      id: 'live:' + D.gw, wide: true, voice: 'malcolm', kind: 'board', ts: T(at, 3), time: liveLabel(), gw: D.gw, teams: rows.flatMap(r => [r.h, r.a]), players: [],
      text: 'Gameweek ' + D.gw + ', live. ' + rows.filter(r => r.hs !== r.as).map(r => esc(short(r.hs > r.as ? r.h : r.a)) + ' lead ' + Math.max(r.hs, r.as) + '–' + Math.min(r.hs, r.as)).slice(0, 2).join('; ') + '.',
      media: { type: 'board', rows, gw: D.gw, live: true }, facts: 'Live scores · projected finals · win chance',
      detail: rows.map(r => ({ k: esc(r.h) + ' v ' + esc(r.a), v: r.hs + '–' + r.as + ' · proj final ' + f1(r.ph) + '–' + f1(r.pa) + ' · ' + r.w.h + '–' + r.w.a + '%' })), links: [{ label: 'All matchups', href: '#/matchday/all' }],
      share: 'GW' + D.gw + ' live: ' + rows.map(r => short(r.h) + ' ' + r.hs + '–' + r.as + ' ' + short(r.a)).join(', ') + '.',
    });
    const swung = rows.map(r => { const pk = preKick(r.f), was = pk.h > pk.a ? 'h' : pk.a > pk.h ? 'a' : '', now = r.w.h > r.w.a ? 'h' : r.w.a > r.w.h ? 'a' : ''; return { r, pk, was, now }; }).filter(x => x.was && x.now && x.was !== x.now);
    const solo = x => (you && (x.r.h === you || x.r.a === you)) || x.r.nm || swung.length <= 2;
    const quiet = swung.filter(x => !solo(x));
    if (quiet.length) { const P = out[out.length - 1]; P.text += ' On projection, ' + list(quiet.map(x => esc(firstOf(x.now === 'h' ? x.r.h : x.r.a)))) + (quiet.length > 1 ? ' have' : ' has') + ' moved ahead.'; }
    swung.filter(solo).forEach(({ r, pk, was, now }) => {
      const t = now === 'h' ? r.h : r.a, o = now === 'h' ? r.a : r.h;
      const left = mpxLeft(t).n, onBoard = r.hs === r.as ? 'It’s level at ' + r.hs + ' on the board.' : esc(r.hs > r.as ? r.h : r.a) + ' lead ' + (r.nm ? esc(r.nm) + ' ' : '') + Math.max(r.hs, r.as) + '–' + Math.min(r.hs, r.as) + ' on the board.';
      out.push({
        id: 'swing:' + D.gw + ':' + r.h + '|' + r.a + ':' + now, voice: 'malcolm', kind: 'swing', ts: T(at, 2), time: liveLabel(), gw: D.gw, teams: [r.h, r.a], players: [],
        text: esc(firstOf(t)) + ' moves ahead on projection' + (left ? ' with ' + words(left) + ' still to play' : '') + '. ' + onBoard,
        media: { type: 'scorebug', h: r.h, a: r.a, hs: r.hs, as: r.as, w: r.w, was: pk, ph: r.ph, pa: r.pa, nm: r.nm, gw: D.gw, state: 'live' },
        facts: 'Win chance before kick-off v now · ' + short(t) + ' ' + (now === 'h' ? pk.h + '% → ' + r.w.h : pk.a + '% → ' + r.w.a) + '%',
        detail: [{ k: 'Before kick-off', v: pk.h + '–' + pk.d + '–' + pk.a + '% (' + f1(pk.muH) + '–' + f1(pk.muA) + ')' }, { k: 'Now', v: r.w.h + '–' + r.w.d + '–' + r.w.a + '% (proj final ' + f1(r.ph) + '–' + f1(r.pa) + ')' }, { k: 'Score', v: r.hs + '–' + r.as }, { k: esc(t) + ' still to play', v: String(left) }],
        links: [{ label: 'Matchup', href: (you && (r.h === you || r.a === you)) ? '#/matchday/matchup' : '#/matchday/all' }], share: firstOf(t) + ' moves ahead on projection against ' + o + '.',
      });
    });
  }

  /* full time: the latest finished gameweek (or the provisional current one) card by card, older weeks as one results board */
  const ftGws = [];
  for (let g = 1; g <= done; g++) ftGws.push(g);
  if (D.provOver) ftGws.push(D.gw);
  const latest = ftGws[ftGws.length - 1];
  ftGws.forEach(g => {
    const R = results(g).filter(r => r.done); if (!R.length) return;
    const prov = g === D.gw && D.provOver;
    const at = prov ? T(kickoffs(g).slice(-1)[0], 110) : gwDoneTime(g);
    const tl = prov ? 'GW' + g + ' · provisional' : relTime(at);
    if (g === latest) {
      const FTP = [36, 31, 26, 21, 13, 12, 11, 10];
      R.slice().sort((a, b) => ((b.home === you || b.away === you) - (a.home === you || a.away === you)) || ((b.nm ? 1 : 0) - (a.nm ? 1 : 0)) || b.margin - a.margin).forEach((r, i) => {
        const st = r.star, w = r.win, hauls = r.hauls.slice(0, 2);
        let tx; const lead = (prov ? 'Provisional full time' : 'Full time') + (r.nm ? ' in ' + esc(r.nm) : '') + '. ';
        const ws = Math.max(r.hs, r.as), ls = Math.min(r.hs, r.as);
        if (!w) tx = lead + name(r.home) + ' and ' + name(r.away) + ' share it at ' + r.hs + ' apiece.';
        else if (r.margin <= 3) tx = lead + name(w) + ' win it by ' + marginWords(r.margin) + '.';
        else if (r.margin >= 10 && !prov) tx = name(w) + ' put ' + ws + ' on ' + name(r.lose) + (r.nm ? ' in ' + esc(r.nm) : '') + '.';
        else tx = lead + name(w) + ' beat ' + name(r.lose) + ' ' + ws + '–' + ls + '.';
        if (hauls.length >= 2 && hauls[0].pts === hauls[1].pts) tx += ' ' + esc(hauls[0].name) + ' and ' + esc(hauls[1].name) + ', ' + hauls[0].pts + ' each.';
        else if (hauls.length) tx += ' ' + esc(hauls[0].name) + ' with ' + hauls[0].pts + '.';
        out.push({
          id: 'ft:' + g + ':' + r.home + '|' + r.away + (prov ? ':p' : ''), voice: 'malcolm', kind: 'ft', ts: T(at, FTP[i] || 10), time: tl, gw: g, teams: [r.home, r.away], players: st ? [st.code] : [],
          text: tx, media: { type: 'scorebug', h: r.home, a: r.away, hs: r.hs, as: r.as, nm: r.nm, gw: g, state: prov ? 'prov' : 'ft', star: st },
          facts: (prov ? 'Live scores, provisional bonus' : 'H2H Fixtures · GW Log') + ' · GW' + g + (st ? ' · star man ' + st.name + ' ' + st.pts : ''),
          detail: [{ k: 'Score', v: esc(r.home) + ' ' + r.hs + '–' + r.as + ' ' + esc(r.away) }].concat(st ? [{ k: 'Star man', v: esc(st.name) + ' · ' + esc(st.team) + ' · ' + pt(st.pts) + '' + (st.line ? ' · ' + st.line : '') }] : []).concat(r.hauls.map(h => ({ k: 'Double figures', v: esc(h.name) + ' ' + h.pts + ' (' + esc(short(h.team)) + ')' }))),
          links: [{ label: 'Results', href: '#/league/results' }], share: 'Full time, GW' + g + ': ' + r.home + ' ' + r.hs + '–' + r.as + ' ' + r.away + '.',
        });
      });
      /* the table at full time, with movement */
      if (!prov && g >= 2) {
        const now = posAfter(g), before = posAfter(g - 1), ord = Object.keys(now).sort((a, b) => now[a] - now[b]);
        const top = ord[0], st = D.st.find(s => s.Team === top), ups = ord.map(t => ({ t, d: before[t] - now[t] })).sort((a, b) => b.d - a.d), up = ups[0], upAll = ups.filter(x => up && x.d === up.d).map(x => x.t);
        out.push({
          id: 'table:' + g, wide: true, voice: 'malcolm', kind: 'table', ts: T(at, 16), time: tl, gw: g, teams: ord, players: [],
          text: 'The table after GW' + g + ': ' + name(top) + ' top' + (st ? ' on ' + num(st['League Pts']) : '') + '.' + (up && up.d > 0 ? (upAll.length > 1 ? ' Biggest climbs: ' + esc(list(upAll)) + ', up ' + words(up.d) + ' each.' : ' Biggest climb: ' + esc(up.t) + ', up ' + words(up.d) + '.') : ''),
          media: { type: 'table', ord, now, before, gw: g }, facts: 'Table after GW' + (g - 1) + ' v after GW' + g,
          detail: ord.map(t => ({ k: now[t] + '. ' + esc(t), v: before[t] === now[t] ? 'no change' : (before[t] > now[t] ? 'up ' : 'down ') + Math.abs(before[t] - now[t]) })), links: [{ label: 'Table', href: '#/league/overview' }],
          share: 'The table after GW' + g + ': ' + top + ' top.',
        });
      }
    } else {
      const stars = R.map(r => r.star).filter(Boolean).sort((a, b) => b.pts - a.pts);
      out.push({
        id: 'results:' + g, wide: true, voice: 'malcolm', kind: 'results', ts: T(at, 12), time: relTime(at), gw: g, teams: R.flatMap(r => [r.home, r.away]), players: stars[0] ? [stars[0].code] : [],
        text: 'Full time across gameweek ' + g + '.' + (stars[0] ? ' Star of the week: ' + esc(stars[0].name) + ', ' + stars[0].pts + ' for ' + esc(stars[0].team) + '.' : ''),
        media: { type: 'results', rows: R, gw: g, star: stars[0] || null }, facts: 'H2H Fixtures · GW Log · GW' + g,
        detail: R.map(r => ({ k: esc(r.home) + ' v ' + esc(r.away), v: r.hs + '–' + r.as + (r.star ? ' · star ' + esc(r.star.name) + ' ' + r.star.pts : '') })), links: [{ label: 'Results', href: '#/league/results' }],
        share: 'GW' + g + ' results: ' + R.map(r => short(r.home) + ' ' + r.hs + '–' + r.as + ' ' + short(r.away)).join(', ') + '.',
      });
    }
  });

  /* articles: recaps and previews, and the Gameweek Show */
  (typeof RECAPS !== 'undefined' ? RECAPS : []).forEach(a => {
    const at = gwDoneTime(a.gw);
    out.push({ id: 'recap:' + a.gw, voice: 'malcolm', kind: 'article', ts: T(at, 40), time: 'GW' + a.gw + ' recap', gw: a.gw, teams: [], players: [], text: 'The GW' + a.gw + ' recap is up.', media: { type: 'article', kind: 'Recap', gw: a.gw, href: a.href, title: a.title, sub: a.sub }, facts: '', detail: [], links: [{ label: 'Read the recap', href: a.href, ext: true }], share: 'GW' + a.gw + ' recap: ' + a.title });
  });
  (typeof PREVIEWS !== 'undefined' ? PREVIEWS : []).forEach(a => {
    const at = buildUpTime(a.gw);
    out.push({ id: 'preview:' + a.gw, voice: 'malcolm', kind: 'article', ts: T(at, 60), time: 'GW' + a.gw + ' preview', gw: a.gw, teams: [], players: [], text: 'The GW' + a.gw + ' preview is up.', media: { type: 'article', kind: 'Preview', gw: a.gw, href: a.href, title: a.title, sub: a.sub }, facts: '', detail: [], links: [{ label: 'Read the preview', href: a.href, ext: true }], share: 'GW' + a.gw + ' preview: ' + a.title });
  });
  shows().forEach(s => {
    const at = s.at || buildUpTime(s.gw);
    out.push({
      id: 'show:' + s.gw, wide: true, voice: 'malcolm', kind: 'show', ts: T(at, 12 * 60), time: s.at ? dayMonth(s.at) : 'GW' + s.gw, gw: s.gw, teams: s.j.chapters.flatMap(c => [c.home, c.away]), players: [],
      text: 'The Gameweek ' + s.gw + ' show. ' + Words(s.j.chapters.length) + ' matchups, ' + mmss(s.dur) + ' in the booth.',
      media: { type: 'show', gw: s.gw }, facts: 'The Gameweek Show · ' + s.clips.length + ' narrated clips · ' + mmss(s.dur),
      detail: s.j.chapters.map(c => ({ k: esc(c.home) + ' v ' + esc(c.away), v: c.beats.length + ' beats' })), links: [], share: 'The Gameweek ' + s.gw + ' show, with Malcolm Tyre in the booth.',
    });
  });
}

/* ============================== JIVE (only you) ============================== */
export function jivePosts(team) {
  const out = []; if (!team || !TEAMS[team]) return out;
  const bu = buildUpTime(D.gw), pre = !D.dlPassed;
  const F = flagged(team), call = selectionCall(team), dm = dangerMan(team);
  const dismissed = (lsGet('emt-feed-kept', {}) || {});
  if (pre && call && !dismissed[callKey(call)]) out.push(callPost(call, bu));
  if (pre && (F.xi.length || F.bench.length)) {
    const d = F.xi.filter(p => p.Status === 'd'), same = d.length && d.every(p => chanceOf(p) === chanceOf(d[0]));
    let tx = F.xi.length ? 'Gaffer, ' + (F.xi.length === 1 ? esc(F.xi[0].Player) + ' carries a flag' : words(F.xi.length) + ' of your starters carry a flag') + ' into GW' + D.gw + '.' : 'Gaffer, your XI is clear. The flags are on the bench.';
    if (same && d.length === F.xi.length && d.length > 1) tx = 'Gaffer, ' + words(d.length) + ' of your starters are ' + chanceOf(d[0]) + '% for GW' + D.gw + '.';
    out.push({
      id: 'fit:' + D.gw + ':' + hash(F.xi.concat(F.bench).map(p => p.Code + statusWord(p)).join()), voice: 'jive', kind: 'fitness', ts: T(bu, 92), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [team], players: F.xi.concat(F.bench).map(p => String(p.Code)), audience: 'you',
      text: tx, media: { type: 'fitness', xi: F.xi.map(p => String(p.Code)), bench: F.bench.map(p => String(p.Code)) },
      facts: 'FPL injury news · your projected XI', detail: F.xi.concat(F.bench).map(p => ({ k: esc(p.Player) + (F.xi.includes(p) ? ' (XI)' : ' (bench)'), v: esc(p.News) })),
      links: [{ label: 'Lineup', href: '#/team/lineup' }], share: '',
    });
  }
  if (pre && dm) {
    out.push({
      id: 'scout:' + D.gw + ':' + dm.opp + ':' + dm.p.Code, voice: 'jive', kind: 'scout', ts: T(bu, 91), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [team, dm.opp], players: [String(dm.p.Code)], audience: 'you',
      text: 'Scouting ' + esc(theShort(dm.opp)) + ': ' + esc(dm.p.Player) + ' projects ' + f1(dm.ep) + ', the most in their XI.',
      media: { type: 'scout', code: String(dm.p.Code), ep: dm.ep, opp: dm.opp, xi: ex(dm.opp).map(p => ({ code: String(p.Code), ep: epOf(p.Code) || 0 })).sort((a, b) => b.ep - a.ep).slice(0, 3) },
      facts: 'Projections · ' + dm.opp + ' projected XI', detail: ex(dm.opp).map(p => ({ k: esc(p.Player), v: f1(epOf(p.Code) || 0) })).sort((a, b) => parseFloat(b.v) - parseFloat(a.v)).slice(0, 5),
      links: [{ label: dm.p.Player, open: 'player:' + dm.p.Code }], share: '',
    });
  }
  /* live: what the auto-subs have done so far */
  if (D.liveNow) {
    const subs = autoSubs(team).subs.filter(s => s.kind === 'locked');
    if (subs.length) {
      const at = liveTime();
      const got = s => num(s.inn['GW pts']) + ((D.pbonus || {})[String(s.inn.Code)] || 0), tot = subs.reduce((a, s) => a + got(s), 0);
      const so = subs.length === 1 ? (tot ? ' ' + esc(subs[0].inn.Player) + ' has ' + pt(tot).replace('pt', 'point') + ' so far.' : ' Nothing from him yet.') : (tot ? ' ' + pt(tot).replace('pt', 'point') + ' between them so far.' : ' Nothing from them yet.');
      out.push({
        id: 'subs:' + D.gw + ':' + subs.map(s => s.out.Code + '>' + s.inn.Code).join(','), voice: 'jive', kind: 'subs', ts: T(at, 4), time: liveLabel(), gw: D.gw, teams: [team], players: subs.flatMap(s => [String(s.out.Code), String(s.inn.Code)]), audience: 'you',
        text: 'Gaffer, the bench is doing its job: ' + list(subs.map(s => esc(s.inn.Player) + ' on for ' + esc(s.out.Player))) + '.' + so,
        media: { type: 'subs', subs: subs.map(s => ({ out: String(s.out.Code), inn: String(s.inn.Code), pts: num(s.inn['GW pts']) + ((D.pbonus || {})[String(s.inn.Code)] || 0) })) },
        facts: 'Auto-subs · confirmed only', detail: subs.map(s => ({ k: esc(s.out.Player) + ' → ' + esc(s.inn.Player), v: pt(num(s.inn['GW pts'])) + ' so far' })),
        links: [{ label: 'Matchup', href: '#/matchday/matchup' }], share: '',
      });
    }
  }
  return out;
}
export const callKey = c => c.gw + ':' + c.out.p.Code + '>' + c.alt.p.Code;
export function callPost(c, bu) {
  const o = c.out, a = c.alt, nm = o.p.Player;
  const offBench = o.starts === 0 && o.mins > 0;
  const tx = 'Gaffer, a selection call before the deadline. ' + esc(nm) + ' has ' + o.mins + ' ' + plural(o.mins, 'minute') + ' in ' + words(o.n) + ' ' + plural(o.n, 'game') + (offBench ? ', all off the bench' : '') + '.';
  return {
    id: 'call:' + callKey(c), voice: 'jive', kind: 'call', ts: T(bu || buildUpTime(D.gw), 95), time: 'GW' + D.gw + ' build-up', gw: c.gw, teams: [c.team], players: [String(o.p.Code), String(a.p.Code)], audience: 'you', pin: true,
    text: tx, media: { type: 'call', out: pack(o), alt: pack(a), kind: a.kind, pos: o.p.Pos, gw: c.gw, key: callKey(c) },
    facts: 'Start chance and projection · minutes GW' + c.win[0] + '–' + c.win[c.win.length - 1],
    detail: [{ k: esc(nm), v: o.mins + ' min · ' + o.starts + ' starts · ' + Math.round(o.ps * 100) + '% start · ' + f1(o.pts) + ' proj' }, { k: esc(a.p.Player) + (a.kind === 'free' ? ' (free agent)' : ' (your bench)'), v: a.mins + ' min · ' + a.starts + ' starts · ' + Math.round(a.ps * 100) + '% start · ' + f1(a.pts) + ' proj' }],
    links: a.kind === 'free' ? [{ label: 'Transfers', href: '#/team/transfers' }] : [{ label: 'Lineup', href: '#/team/lineup' }], share: '',
  };
}
const pack = x => ({ code: String(x.p.Code), name: x.p.Player, club: x.p.Club, mins: x.mins, starts: x.starts, n: x.n, ps: x.ps, pts: x.pts });

/* ============================== the press conference (Archizio, before your derby) ============================== */
export function presser(team) {
  if (!team || !TEAMS[team] || D.dlPassed) return null;
  const f = fxFor(team, D.gw); if (!f) return null;
  const nm = derbyName(f.Home, f.Away); if (!nm) return null;
  const opp = oppOf(f, team), s = sr(f.Home, f.Away) || '', w = wp(f), mine = f.Home === team ? w.h : w.a, theirs = f.Home === team ? w.a : w.h;
  const orec = record(opp), oFirst = firstOf(opp), me = firstOf(team);
  const q = 'Any comment before ' + nm + '?' + (s && s !== 'First ever meeting' ? ' ' + s.replace(' leads ', ' leads the series ') + '.' : '');
  const spicy = [];
  if (orec.played >= 3 && orec.w === 0) spicy.push('Ask ' + oFirst + ' how the season’s going.');
  const m = s.match(/^(\S+) leads (\d+)–(\d+)/);
  if (m && m[1] === oFirst) spicy.push(m[2] + '–' + m[3] + ' doesn’t last forever.');
  if (m && m[1] === me) spicy.push('Ask ' + oFirst + ' about the series.');
  if (mine >= 55) spicy.push('We’re favourites for a reason.');
  if (theirs >= 55) spicy.push('Write us off. We like it that way.');
  const opts = [spicy[0] || 'Respect to ' + oFirst + '. Doesn’t change a thing.', 'Form goes out the window in a derby.', 'No comment.'];
  const saved = (lsGet('emt-feed-presser', {}) || {})[D.gw + '|' + f.Home + '|' + f.Away];
  return { f, nm, opp, q, opts, saved: saved && saved.line ? saved : null, team, key: D.gw + '|' + f.Home + '|' + f.Away };
}
export function presserPost(team) {
  const P = presser(team); if (!P || !P.saved || !P.saved.line) return null;
  const bu = buildUpTime(D.gw);
  return {
    id: 'presser:' + P.key + ':' + hash(P.saved.line), voice: 'archizio', kind: 'presser', ts: T(bu, 89), time: 'GW' + D.gw + ' build-up', gw: D.gw, teams: [team, P.opp], players: [], audience: 'you',
    text: strong('PRESS CONFERENCE.') + ' ' + esc(mgrOf(team)) + ' on ' + esc(P.nm) + '.',
    media: { type: 'quote', line: P.saved.line, team, who: mgrOf(team), nm: P.nm },
    facts: 'Your pick from Archizio’s three lines · saved on this phone', detail: [{ k: 'Picked', v: esc(P.saved.line) }, { k: 'Who sees it', v: 'Only you, on this phone. Share sends it on.' }],
    links: [{ label: 'Change your line', href: '#/feed/messages/archizio' }], share: '“' + P.saved.line + '” ' + mgrOf(team) + ', ' + team + ', before ' + P.nm + '. Via @archizio',
  };
}

/* ============================== all posts ============================== */
export function build(you) {
  const out = [];
  const add = f => { try { f(out, you); } catch (e) { console.error(e); } };
  add(archizio); add(clark); add(malcolm);
  try { out.push(...jivePosts(you)); } catch (e) { console.error(e); }
  try { const pp = presserPost(you); if (pp) out.push(pp); } catch (e) { console.error(e); }
  out.forEach(p => { p.audience = p.audience || 'league'; p.teams = [...new Set(p.teams || [])]; p.players = p.players || []; });
  out.sort((a, b) => b.ts - a.ts || (b.pin ? 1 : 0) - (a.pin ? 1 : 0));
  return out;
}
