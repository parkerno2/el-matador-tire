/* pages/feed.js — the Feed: For you · League · Articles · Messages (+ #/feed/messages/<jive|archizio>, #/feed/league/<voice>). */
import * as UI from '../ui.js';
import {
  unread, buildPosts, renderPost, unreadIds, markSeen, threads, markThread, unreadThreads, jiveTodo, jiveCall, warm, restoreCarousels, postById,
} from '../feed/index.js';
import { jivePosts, presser, presserPost, theShort } from '../feed/build.js';
import { VOICES, ORDER, avatar, tagChip } from '../feed/voices.js';
import { shows, mmss, selectionCall } from '../feed/facts.js';
import { callKey } from '../feed/build.js';
import { cut, mediaHTML } from '../feed/render.js';
import { esc, short, dayMonth, lsGet } from '../feed/util.js';

const hasSeen = () => { try { return !!localStorage.getItem('emt-feed-seen'); } catch (e) { return false; } };
const SUBS = [{ id: 'foryou', label: 'For you' }, { id: 'league', label: 'League' }, { id: 'articles', label: 'Articles' }, { id: 'messages', label: 'Messages' }];
let VISIT = null, LIMIT = 20;

/* ---------- chrome ---------- */
function head(sub, args) {
  const nt = unreadThreads();
  return UI.pageHead('Feed') + UI.pills(SUBS.map(s => ({ label: s.label, href: '#/feed/' + s.id, on: s.id === sub, ct: s.id === 'messages' && nt ? nt : 0 })));
}
function avatarInner(v) { return VOICES[v].glyph(56); }
function stories(sub, args) {
  const you = UI.you(), news = VISIT ? VISIT.ids : new Set();
  const posts = buildPosts();
  const fresh = v => posts.some(p => p.voice === v && news.has(p.id));
  const cur = sub === 'league' ? args[0] : sub === 'messages' && args[0] === 'jive' ? 'jive' : null;
  const item = (v, href, label, inner, cls, isNew) => '<a class="fst' + (cur === v ? ' cur' : '') + '" href="' + href + '"><span class="fring ' + cls + (isNew ? '' : ' seen') + '"><span>' + inner + '</span></span><b>' + label + '</b></a>';
  return '<nav class="fstories" aria-label="Voices">'
    + ORDER.filter(v => v !== 'jive' || you).map(v => item(v, v === 'jive' ? '#/feed/messages/jive' : '#/feed/league/' + v, VOICES[v].first, avatarInner(v), 'r-' + v, v === 'jive' ? threads().some(t => t.id === 'jive' && t.unread) : fresh(v))).join('')
    + item('all', '#/feed/league', 'League', UI.leagueCrest(26), 'r-lg', posts.some(p => news.has(p.id)) && cur !== null)
    + '</nav>';
}
const list = (posts, opt = {}) => posts.map(p => renderPost(p, { unread: VISIT && VISIT.ids.has(p.id) && !opt.noNew })).join('');

/* ---------- For you ---------- */
function forYou() {
  const you = UI.you(), posts = buildPosts();
  if (!you || !TEAMS[you]) {
    return '<div class="fy-pick"><b>Pick your team</b><span>Jive’s messages, press conferences and the posts about your club live here.</span><button class="btn" data-open="menu">Choose your team</button></div>'
      + UI.sh('Latest from the league', { more: 'League', href: '#/feed/league' }) + '<div class="fl">' + list(posts.filter(p => p.audience !== 'you').slice(0, 8)) + '</div>';
  }
  const th = threads();
  const inbox = th.length ? UI.sh('Messages', { more: 'All', href: '#/feed/messages' }) + '<div class="card inbox">' + th.map(threadRow).join('') + '</div>' : '';
  const call = jiveCall(you);
  const mine = posts.filter(p => !p.wide && (p.teams || []).includes(you) && (p.voice !== 'jive') && p.kind !== 'article');
  const stream = (call ? [call] : []).concat(mine);
  const art = latestArticle();
  const N = 12, shown = stream.slice(0, N);
  const body = shown.map((p, i) => renderPost(p, { unread: VISIT && VISIT.ids.has(p.id) }) + (i === 1 && art ? artBlock(art) : '')).join('') + (shown.length < 2 && art ? artBlock(art) : '');
  return inbox + UI.sh('For ' + you) + (stream.length ? '<div class="fl">' + body + '</div>' : UI.empty('Quiet week for ' + you, 'Nothing about your club yet. The League tab has every post.') + (art ? artBlock(art) : ''))
    + (stream.length > N ? '<a class="fl-more" href="#/feed/league">Every post is in League ›</a>' : '');
}
function latestArticle() {
  const s = shows()[0];
  const arts = [].concat((typeof PREVIEWS !== 'undefined' ? PREVIEWS : []).map(a => ({ ...a, kind: 'Preview', ord: a.gw * 2 })), (typeof RECAPS !== 'undefined' ? RECAPS : []).map(a => ({ ...a, kind: 'Recap', ord: a.gw * 2 + 1 })));
  arts.sort((a, b) => b.ord - a.ord);
  const a = arts[0];
  if (s && (!a || s.gw * 2 >= a.ord)) return { show: s };
  return a ? { art: a } : null;
}
function artBlock(x) {
  const lab = x.show ? 'The Gameweek Show' : x.art.gw >= D.gw - 1 ? 'This week’s article' : 'Latest article';
  return '<div class="fl-art">' + UI.sh(lab, { more: 'Articles', href: '#/feed/articles' }) + '<div class="fl-art-b">' + (x.show ? showCard(x.show) : artCard(x.art)) + '</div></div>';
}

/* ---------- League (every post, or one voice) ---------- */
function league(args) {
  const v = args[0] && VOICES[args[0]] ? args[0] : null;
  let posts = buildPosts().filter(p => p.voice !== 'jive');
  if (v) posts = posts.filter(p => p.voice === v);
  const shown = posts.slice(0, LIMIT);
  const newN = posts.filter(p => VISIT && VISIT.ids.has(p.id)).length;
  return (v ? voiceHero(v, posts.length) : '')
    + (posts.length ? (newN && !v ? '<div class="fl-newbar"><i></i>' + newN + (VISIT.first ? ' new this gameweek' : ' new since you last looked') + '</div>' : '') + '<div class="fl">' + list(shown) + '</div>'
      + (posts.length > shown.length ? '<button class="fl-more btn ghost" data-more>Show older posts</button>' : '<div class="fl-end">That’s everything' + (v ? ' from ' + esc(VOICES[v].first) : '') + ' this season.</div>')
      : UI.empty('Nothing yet', 'Posts appear as the league plays: signings, previews, full time.'));
}
function voiceHero(v, n) {
  const V = VOICES[v];
  return '<div class="fvh fvh-' + v + '"><i class="fvh-deco"></i>' + avatar(v, 56)
    + '<div class="fvh-t"><b class="fvh-n">' + esc(V.name) + '</b><span>' + esc(V.handle) + ' · ' + esc(V.role) + '</span></div>'
    + '<p>' + esc(V.beat) + '</p><div class="fvh-f"><span>' + n + ' ' + (n === 1 ? 'post' : 'posts') + '</span><a href="#/feed/league">All voices ›</a></div></div>';
}

/* ---------- Articles ---------- */
function showCard(s) {
  return '<div class="fshow-card">' + mediaHTML({ id: 'show:' + s.gw, media: { type: 'show', gw: s.gw } }, false) + '<button class="sc-open" data-open="post:show:' + s.gw + '">Chapters and captions ›</button></div>';
}
function artCard(a) {
  return '<a class="far" href="' + esc(a.href) + '"><span class="far-k"><b class="n">GW' + a.gw + '</b><em>' + esc(a.kind.toUpperCase()) + '</em></span><span class="far-t"><b>' + esc(a.title) + '</b><span>' + esc(a.sub) + '</span></span><span class="far-go">' + UI.icon('chev', 16, 'var(--p300)') + '</span></a>';
}
function articles() {
  const S = shows();
  const arts = [].concat((typeof PREVIEWS !== 'undefined' ? PREVIEWS : []).map(a => ({ ...a, kind: 'Preview', ord: a.gw * 2 })), (typeof RECAPS !== 'undefined' ? RECAPS : []).map(a => ({ ...a, kind: 'Recap', ord: a.gw * 2 + 1 }))).sort((a, b) => b.ord - a.ord);
  const missing = [];
  if (D.gwsDone && !(typeof RECAPS !== 'undefined' && RECAPS.some(r => r.gw === D.gwsDone))) missing.push('GW' + D.gwsDone + ' recap');
  if (!(typeof PREVIEWS !== 'undefined' && PREVIEWS.some(r => r.gw === D.gw))) missing.push('GW' + D.gw + ' preview');
  return (S.length ? UI.sh('The Gameweek Show') + S.map(s => '<div class="ar-show">' + showCard(s) + '</div>').join('') : '')
    + UI.sh('Previews and recaps', { aside: arts.length + ' articles' })
    + (arts.length ? '<div class="ar-list">' + arts.map(artCard).join('') + '</div>' : UI.empty('No articles yet', 'Previews land before each deadline, recaps after each gameweek.'))
    + (missing.length ? '<p class="ar-note">Not published yet: ' + esc(missing.join(' and ')) + '.</p>' : '');
}

/* ---------- Messages ---------- */
function threadRow(t) {
  const V = VOICES[t.voice];
  return '<a class="row tap fth-r" href="#/feed/messages/' + t.id + '">' + avatar(t.voice, 44) + '<span class="fth-t"><b>' + esc(V.name) + (t.id === 'archizio' ? ' <span class="ftag ftag-press">PRESS CONFERENCE</span>' : '') + '</b><span class="ell">' + esc(t.preview) + (t.time ? ' · ' + esc(t.time) : '') + '</span></span>' + (t.unread ? '<i class="fth-dot" aria-label="Unread"></i>' : UI.icon('chev', 16, 'var(--tx4)')) + '</a>';
}
function messages(args) {
  const you = UI.you();
  if (!you || !TEAMS[you]) return '<div class="fy-pick"><b>Pick your team</b><span>Jive Tidlsey is your assistant manager, and Archizio asks you for a quote before your derbies.</span><button class="btn" data-open="menu">Choose your team</button></div>';
  if (args[0] === 'jive') return jiveThread(you);
  if (args[0] === 'archizio') return pressThread(you);
  const th = threads();
  return (th.length ? '<div class="card inbox list">' + th.map(threadRow).join('') + '</div>' : UI.empty('No messages', 'Jive writes when there’s something to act on before a deadline. Archizio asks for a quote before your derbies.'))
    + '<p class="ar-note">Messages are written for you from the league data, and only you see them.</p>';
}
const bubble = (v, html, cls = '') => '<div class="fbb fbb-' + v + (cls ? ' ' + cls : '') + '">' + html + '</div>';
function threadHead(v, extra) { return '<div class="fth-h"><a class="fth-back" href="#/feed/messages" aria-label="Back to messages">' + UI.icon('back', 18, 'var(--b300)', 2.4) + '</a>' + avatar(v, 36) + '<span class="fth-who"><b>' + esc(VOICES[v].name) + '</b><span>' + (extra || esc(VOICES[v].handle)) + '</span></span></div>'; }
function jiveThread(you) {
  const J = jivePosts(you), call = jiveCall(you), todo = jiveTodo(you);
  const fit = J.find(p => p.kind === 'fitness'), sc = J.find(p => p.kind === 'scout'), subs = J.find(p => p.kind === 'subs');
  let body = '';
  const when = 'GW' + D.gw + (D.dlPassed ? (UI.week().mode === 'live' ? ' · live' : '') : ' build-up');
  if (fit) body += bubble('jive', fit.text) + '<div class="fbb-media">' + mediaHTML(fit, false) + '</div>';
  if (call) body += bubble('jive', call.text.replace(/^Gaffer, a selection call before the deadline\. /, (fit ? 'And a selection call. ' : 'Gaffer, a selection call. '))) + '<div class="fbb-media">' + mediaHTML(call, false) + '</div>';
  if (sc) body += bubble('jive', sc.text) + '<div class="fbb-media">' + mediaHTML(sc, false) + '</div>';
  if (subs) body += bubble('jive', subs.text) + '<div class="fbb-media">' + mediaHTML(subs, false) + '</div>';
  const c0 = !call && !D.dlPassed ? selectionCall(you) : null, kept = c0 && (lsGet('emt-feed-kept', {}) || {})[callKey(c0)];
  const td = todo.filter(t => t.kind !== 'call');
  if (td.length) body += bubble('jive', 'Before the deadline, gaffer:') + '<div class="fbb-media">' + todoBoard(td) + '</div>';
  if (!body) body = bubble('jive', D.dlPassed ? 'Lineups are locked, gaffer. Nothing to change until the next window opens.' : 'Nothing to act on right now, gaffer. Your XI is fit and starting.');
  const qr = [];
  if (call) qr.push(call.media.kind === 'free' ? '<a class="fqr" href="#/team/transfers">Show free-agent ' + ({ GKP: 'keepers', DEF: 'defenders', MID: 'midfielders', FWD: 'forwards' }[call.media.pos] || 'players') + '</a>' : '<a class="fqr" href="#/team/lineup">Open the lineup</a>');
  if (fit || (call && call.media.kind === 'free')) qr.push('<a class="fqr" href="#/team/lineup">Open the lineup</a>');
  if (sc) qr.push('<button class="fqr" data-open="player:' + esc(sc.media.code) + '">Open ' + esc((UI.player(sc.media.code) || {}).Player || '') + '</button>');
  if (subs) qr.push('<a class="fqr" href="#/matchday/matchup">Open the matchup</a>');
  if (call) qr.push('<button class="fqr" data-fx="keep:' + esc(call.media.key) + '">Keep ' + esc(call.media.out.name) + '</button>');
  if (kept) { body += bubble('jive', 'Noted, gaffer: you’re keeping ' + esc(c0.out.p.Player) + '.'); qr.push('<button class="fqr" data-fx="unkeep:' + esc(callKey(c0)) + '">Show the selection call again</button>'); }
  return threadHead('jive', tagChip('jive')) + '<div class="thread"><div class="fth-when">' + esc(when) + '</div>' + body + (qr.length ? '<div class="fqrs">' + [...new Set(qr)].join('') + '</div>' : '') + '</div>';
}
function todoBoard(items) {
  return '<div class="fjb todo"><div class="fjb-hd"><span class="f-mono fjb-t">TO DO</span><span class="f-mono fjb-m">GW' + D.gw + '</span></div>'
    + items.map((t, i) => '<div class="jt"><span class="f-mono jt-n">' + (i + 1) + '</span><span class="jt-f">' + t.faces.slice(0, 2).map(c => '<span class="jc-f dash xs">' + cut(c, '', '') + '</span>').join('') + '</span><span class="jt-t">' + t.html + '</span>'
      + (t.action.href ? '<a class="jbtn f-mono sm" href="' + esc(t.action.href) + '">' + esc(t.action.label) + '</a>' : '<button class="jbtn f-mono sm" data-open="' + esc(t.action.open) + '">Open</button>') + '</div>').join('')
    + '<div class="fjb-note"><span class="f-chalk">' + (gwDeadline(D.gw) ? 'Sort these before ' + esc(gwDeadline(D.gw).toLocaleDateString(undefined, { weekday: 'long' })) + '.' : 'Sort these before the deadline.') + '</span></div></div>';
}
function pressThread(you) {
  const P = presser(you);
  if (!P) {
    const nx = (typeof derbyRows === 'function' ? derbyRows() : []).filter(r => r.nm && (r.a === you || r.b === you) && r.next).sort((a, b) => num(a.next.GW) - num(b.next.GW))[0];
    return threadHead('archizio') + '<div class="thread">' + bubble('archizio', D.dlPassed ? 'The deadline has passed. Press conferences close when the team sheets go in.' : 'No derby for ' + esc(you) + ' this week, so no press conference.') + (nx ? '<div class="fth-when">Next derby: ' + esc(nx.nm) + ' · GW' + num(nx.next.GW) + '</div>' : '') + '</div>';
  }
  const pick = P.saved ? P.saved.line : null;
  const post = presserPost(you);
  return threadHead('archizio', '<span class="ftag ftag-press">PRESS CONFERENCE</span>') + '<div class="thread">'
    + '<div class="fth-when">GW' + D.gw + ' build-up</div>'
    + bubble('archizio', esc(P.q))
    + '<div class="fth-hint">Pick a line, or say nothing</div>'
    + '<div class="pq">' + P.opts.map((o, i) => '<button class="pq-o' + (pick === o ? ' on' : '') + '" data-fx="presser:' + i + '">“' + esc(o) + '”</button>').join('') + '</div>'
    + (post ? '<div class="fth-lab">Your line, as it looks in your feed</div><div class="fbb-media fwide">' + mediaHTML(post, false) + '</div>'
      + '<div class="pq-acts"><button class="btn" data-fx="presshare:1">' + UI.icon('share', 16, '#fff') + 'Share</button><button class="btn ghost" data-fx="presser:none">Say nothing</button></div>'
      + '<p class="ar-note">Only you see it here, on this phone. Share sends it wherever you like.</p>' : '')
    + '</div>';
}

/* ---------- the page ---------- */
export default {
  unread,
  title: 'Feed',
  subs: SUBS,
  render(sub, args) {
    if (!VISIT || document.body.dataset.page !== 'feed') { VISIT = { ids: new Set(unreadIds()), first: !hasSeen() }; LIMIT = 20; }
    let body = '';
    try {
      if (sub === 'foryou') body = forYou();
      else if (sub === 'league') body = league(args);
      else if (sub === 'articles') body = articles();
      else if (sub === 'messages') body = messages(args);
    } catch (e) { console.error(e); body = '<div class="err">Couldn’t build the feed. ' + esc(e.message) + '</div>'; }
    const showStories = sub === 'foryou' || sub === 'league';
    return head(sub, args) + (showStories ? stories(sub, args) : '') + '<div class="feed f-' + sub + '">' + body + '</div>';
  },
  mount(root, sub, args) {
    UI.showOn(root);
    warm();
    if (sub === 'foryou' || sub === 'league') markSeen();
    if (sub === 'messages' && args[0]) markThread(args[0]);
    restoreCarousels(root);
    if (!root.__feedMore) {
      root.__feedMore = 1;
      root.addEventListener('click', e => {
        const m = e.target.closest('[data-more]'); if (!m || document.body.dataset.page !== 'feed') return;
        e.preventDefault(); LIMIT += 20; window.MW.render({ keepScroll: true });
      });
    }
  },
};
