# Feature sweep brief (El Matador Tire app, phone size)

You are testing a live fantasy football (FPL Draft) league web app by actually using it in headless Chromium at phone size: tapping, scrolling, opening and closing every sheet, switching every toggle. The owner expects bugs to be found by using the app, not by reading code.

## Setup (already built, do not rebuild)
- Repo clone: /home/claude/emt (READ ONLY for you; never edit files there).
- Page under test: `v12.html` (the hidden preview = production plus today's fixes). Served at https://parkerno2.github.io/el-matador-tire/v12.html from local disk by the harness.
- Harness: /home/claude/harness/harness.py. Use it from Python:

```python
import sys; sys.path.insert(0, '/home/claude/harness')
from harness import App
with App(width=390, height=844) as app:      # phone; also try 320x640, 430x932, 768x1024, 1280x800
    p = app.open('v12.html')                  # Playwright Page, data already loaded
    p.get_by_role('button', name='Players').last.click()
    p.screenshot(path='/home/claude/harness/shots/<area>/x.png')
    print(app.errors)                          # page errors + console errors so far
```
  `App(now='2026-10-10T12:00:00Z')` freezes the app clock (Date) if you need it; `App(api=lambda req: {...})` changes the Apps Script stub reply (default `{'ok':True,'ran':False,'busy':False,'ageSec':120}`).
- Data: the real league sheet exported 3 Oct 2026. GW1 to GW5 are final; GW6 deadline is Sat 10 Oct 10:00 UTC (international break, nothing live). 8 teams, 38 gameweeks, H2H scoring 3/1/0.
- Expected harness artefacts (NOT bugs): Premier League player photos render as a grey silhouette, club badges as purple squares, flags as grey rectangles. Owned players use real face cutouts from faces/. One 404 console line from a missing face file is normal (the app falls back). Fonts are real.
- View screenshots with the Read tool to judge visuals. Look at them; layout bugs are bugs.

## What counts as a bug
Broken taps, sheets that will not close or reopen wrong, lost scroll position, content clipped or overflowing at 320 to 430 px, text truncated into nonsense, wrong or inconsistent numbers between two screens, dead links or empty states with no message, console errors, slow interactions (measure: anything over 150 ms after a tap), leftover off-system colours (gold/yellow, old blue #2E5BFF/#3556D9, neon greens) outside the Plate player cards, tap targets under 40 px, focus rings in odd colours, inconsistent wording ("PROJ" vs "Projected").
Design decisions already made (NOT bugs): the Plate player cards and their tier colours, Archivo + Barlow Condensed fonts, Mono team badges (team-colour fill at 32 px and under), ink header, purple accents, derby names (The Nolan Derby, The Sacred Heart Derby).

Already known, do not re-report as new (mark "known" if you confirm them): #23 refresh fallthrough, #24 odds shrink banked points in a live GW, #26 Players "per game" average vs player sheet "Average per GW" differ, #27 manifest colour behind sw cache, #17 player sheet "Next fixture" uses in-progress match, #14 #xis/UNKNOWN shows "0 players", #15 Lab race view shows 4 of 8 teams with no selection.

## Rules
- Reproduce every finding twice before logging it. Note exact steps and widths.
- Save screenshots under /home/claude/harness/shots/<area>/ and reference them.
- Where you can, point at the likely code: grep /home/claude/emt/v12.html (built page) and name the source file it comes from (index-PREVIEW.html base, or fplgg/tools/v10/*.js|css, fplgg/tools/v12/*.js|css).
- Write findings to /home/claude/harness/findings/<area>.md as a table: id, severity (P1 wrong number a manager sees / P2 broken interaction or missing data / P3 polish), width, steps, expected, actual, screenshot, likely source.
- Also list what you checked and found working, briefly, so coverage is visible.
- Your final reply: a short summary (counts by severity and the top 5 findings in one line each). Details stay in the file.
