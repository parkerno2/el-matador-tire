# Fix brief: bugfix build, 3 Oct 2026

Four agents fix the feature-sweep findings in parallel, each in its own git worktree, each owning a set of finding IDs. Findings with steps, evidence and likely source: /home/claude/harness/findings/{matchday,teams,table-players,lab-global}.md. Also read /home/claude/harness/BRIEF.md (harness usage, what is and isn't a bug).

## Where you work
- Your worktree: /home/claude/wt-<x> on branch fix-<x>. Edit ONLY there. Never touch /home/claude/emt or another worktree.
- Sources (edit these): `index-PREVIEW.html` (base app), `fplgg/tools/v10/*.js|css`, `fplgg/tools/v12/*.js|css`, `sw.js`. Never hand-edit `v12.html` or `index.html` (built outputs); never commit them (`git checkout -- v12.html index.html` before committing).
- Build the preview: `cd /home/claude/wt-<x> && python3 fplgg/tools/v12/build_v12.py index-PREVIEW.html` (writes wt-<x>/v12.html, runs node --check on the v12 modules). Also extract and `node --check` any inline script you changed in index-PREVIEW.html.
- Test with the harness against YOUR worktree: run python with env `EMT_ROOT=/home/claude/wt-<x>` and open 'v12.html'. Keep your scripts and screenshots under /home/claude/harness/fix-<x>/ so you don't collide with other agents.
- Other agents edit other parts of the same files. Keep edits surgical and local to the function or rule you're fixing; don't reformat, reorder or rename unrelated code (git must be able to merge four branches cleanly).

## Settled rules (do not relitigate)
- One OVR per player everywhere: the league rating with form (`dynOvr(p)`), never the FC27/EA number on its own.
- Bonus is excluded from xP and from both sides of every actual-vs-expected comparison (luck, Lab trend, profile chart).
- PROJ (forecast, before his match) vs xP (deserved, after). User-facing wording: "Projected" (not "Predicted"), W-D-L records.
- D2 look: ink #17121D chrome, ground #F5F3F8, white cards, purple #5B2D8E for kickers, links and focus only, light purple #CDBDF0 on dark surfaces, green/red only for results (win/loss) and status. Gold is retired outside the Plate player cards (money amounts go ink). Fixture difficulty uses the v12 `FDRCOL` palette everywhere, legends included. Percentile bars: one purple scale, not traffic lights.
- Focus: `:focus-visible` outline 2px #5B2D8E, offset 2px; never the browser default.
- Tap targets at least 40 px (44 where it fits) through padding/min-height, without making things look bigger.
- Locked: Plate cards and their tier art, Archivo + Barlow Condensed, Mono badges (team-colour fill at 32 px and under), derby names, the five-tab nav. This is a bugfix build, not a redesign: fix behaviour and polish, don't restructure screens.

## Done means
1. For each owned ID: the harness reproduces the bug before your change and shows it fixed after (assertion or before/after screenshots), at the widths in the finding.
2. A smoke pass of all five tabs plus a player sheet, a team sheet and a matchup at 390 and 320 shows zero new console errors and nothing visibly broken.
3. One commit on your branch: `git -c user.name=Claude -c user.email=noreply@anthropic.com commit -m "<summary>; fixes <IDs>"` (commit signing may fail in a worktree; if so add `-c commit.gpgsign=false`).
4. Final reply: fixed IDs; skipped IDs with the reason (needs Parker's decision, needs an asset, needs another agent's file); files touched; anything another file must change for your fix to fully land.
