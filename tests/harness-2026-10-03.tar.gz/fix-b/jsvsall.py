import sys,json,os,statistics
sys.path.insert(0,'/home/claude/harness')
from harness import App
T="""async(sel)=>{const el=document.querySelector(sel);const t0=performance.now();el.click();const t1=performance.now();
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return [Math.round(t1-t0),Math.round(performance.now()-t0)]}"""
res={}
with App(width=390,height=844) as app:
    p=app.open('v12.html');cdp=p.context.new_cdp_session(p);cdp.send('Emulation.setCPUThrottlingRate',{'rate':4});p.wait_for_timeout(300)
    for k,sel,pre in [('open','#gwbody .mcard[data-mi="1"]',"location.hash='gw'"),('benches','#btog',"location.hash='gw/1'"),('fixture','.axtog.om button[data-om="1"]',"location.hash='gw/1';OPPMODE=false;BENCHOPEN=false")]:
        js=[];tot=[]
        for i in range(6):
            p.evaluate("(h)=>{eval(h);window.scrollTo(0,0)}",pre);p.wait_for_timeout(400)
            a,b=p.evaluate(T,sel);js.append(a);tot.append(b)
        res[k]={'js_med':statistics.median(js),'tap2paint_med':statistics.median(tot),'js':js,'tot':tot}
print(os.environ.get('EMT_ROOT'),json.dumps(res))
