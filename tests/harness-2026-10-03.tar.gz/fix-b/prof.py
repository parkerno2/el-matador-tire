"""MD-09: tap-to-paint timings at 4x CPU throttle + a CPU profile of the matchup render. Usage: EMT_ROOT=... python3 prof.py [tag]"""
import sys, json, os, collections
sys.path.insert(0, '/home/claude/harness')
from harness import App
TAG = sys.argv[1] if len(sys.argv) > 1 else 'x'
def wait(p, ms=250): p.wait_for_timeout(ms)
TIMER = """async(sel)=>{const el=document.querySelector(sel);const t0=performance.now();el.click();
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return Math.round(performance.now()-t0)}"""
HASH = """async(h)=>{const t0=performance.now();location.hash=h;await new Promise(r=>setTimeout(r,0));
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return Math.round(performance.now()-t0)}"""

def run(throttle):
    out = collections.defaultdict(list)
    with App(width=390, height=844) as app:
        p = app.open('v12.html')
        cdp = p.context.new_cdp_session(p)
        cdp.send('Emulation.setCPUThrottlingRate', {'rate': throttle})
        wait(p, 300)
        for rep in range(3):
            p.evaluate("()=>{location.hash='gw';window.scrollTo(0,0)}"); wait(p, 500)
            out['open'].append(p.evaluate(TIMER, '#gwbody .mcard[data-mi="1"]')); wait(p, 300)
            out['fixture'].append(p.evaluate(TIMER, '.axtog.om button[data-om="1"]')); wait(p, 300)
            out['points'].append(p.evaluate(TIMER, '.axtog.om button[data-om="0"]')); wait(p, 300)
            out['benches'].append(p.evaluate(TIMER, '#btog')); wait(p, 300)
            out['hide_benches'].append(p.evaluate(TIMER, '#btog')); wait(p, 300)
            out['back'].append(p.evaluate(TIMER, '#gwback')); wait(p, 400)
            out['derbies'].append(p.evaluate(TIMER, '[data-gwtab="derbies"]')); wait(p, 300)
            out['week'].append(p.evaluate(TIMER, '[data-gwtab="week"]')); wait(p, 300)
            out['plall'].append(p.evaluate(TIMER, '#plall')); wait(p, 300)
            p.evaluate(TIMER, '#plall'); wait(p, 300)
        # a CPU profile of one matchup open + one bench toggle (unthrottled numbers are easier to read)
        cdp.send('Emulation.setCPUThrottlingRate', {'rate': 1})
        p.evaluate("()=>{location.hash='gw';window.scrollTo(0,0)}"); wait(p, 500)
        cdp.send('Profiler.enable'); cdp.send('Profiler.setSamplingInterval', {'interval': 100})
        cdp.send('Profiler.start')
        p.evaluate(TIMER, '#gwbody .mcard[data-mi="1"]'); wait(p, 100)
        p.evaluate(TIMER, '#btog'); wait(p, 100)
        p.evaluate(TIMER, '.axtog.om button[data-om="1"]'); wait(p, 100)
        prof = cdp.send('Profiler.stop')['profile']
        cdp.send('Profiler.disable')
    return out, prof

def summarize(prof, top=28):
    nodes = {n['id']: n for n in prof['nodes']}
    parent = {}
    for n in prof['nodes']:
        for c in n.get('children', []): parent[c] = n['id']
    dt = prof.get('timeDeltas', []); samples = prof['samples']
    self_t = collections.Counter(); total_t = collections.Counter()
    for sid, d in zip(samples, dt):
        n = nodes[sid]; cf = n['callFrame']; key = (cf['functionName'] or '(anon)') + ':' + str(cf.get('lineNumber', 0))
        self_t[key] += d
        seen = set(); cur = sid
        while cur is not None:
            k2 = (nodes[cur]['callFrame']['functionName'] or '(anon)') + ':' + str(nodes[cur]['callFrame'].get('lineNumber', 0))
            if k2 not in seen: total_t[k2] += d; seen.add(k2)
            cur = parent.get(cur)
    tot = sum(dt)
    print(f'profile total {tot/1000:.0f} ms')
    print('-- self time (ms) --')
    for k, v in self_t.most_common(top): print(f'{v/1000:7.1f}  {k}')
    print('-- total time (ms), named functions --')
    for k, v in [(k, v) for k, v in total_t.most_common(80) if not k.startswith('(')][:top]: print(f'{v/1000:7.1f}  {k}')

if __name__ == '__main__':
    out, prof = run(4)
    print(TAG, '4x CPU (ms, 3 reps):', json.dumps(out))
    json.dump(out, open(f'/home/claude/harness/fix-b/timing-{TAG}.json', 'w'))
    summarize(prof)
