import sys,json;sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    p.evaluate("()=>{location.hash='ana'}");p.wait_for_timeout(600)
    r=p.evaluate("()=>Object.fromEntries(['.labseg button','.labmet','.labview','.labmono','.lucks .fatog button'].map(s=>{const e=document.querySelector(s);if(!e)return [s,null];const b=e.getBoundingClientRect();return [s,[Math.round(b.width),Math.round(b.height)]]}))")
    p.screenshot(path='shots/after/lab-controls-390.png',clip={'x':0,'y':0,'width':390,'height':520})
    p.evaluate("()=>{location.hash='xis'}");p.wait_for_timeout(500)
    r['.fatog button (players)']=p.evaluate("()=>{const e=document.querySelector('#xisbody .fatog button, #v-xis .fatog button');if(!e)return null;const b=e.getBoundingClientRect();return [Math.round(b.width),Math.round(b.height)]}")
    p.screenshot(path='shots/after/players-head-390.png',clip={'x':0,'y':0,'width':390,'height':300})
    print(json.dumps(r), [e for e in app.errors if '404' not in e])
