import sys, json, os
sys.path.insert(0, '/home/claude/harness')
from harness import App
OUT = '/home/claude/harness/fix-b/shots/smoke'; os.makedirs(OUT, exist_ok=True)
def wait(p, ms=400): p.wait_for_timeout(ms)
for W, H in [(390, 844), (320, 640)]:
    with App(width=W, height=H) as app:
        p = app.open('v12.html')
        over = {}
        def shot(name):
            p.screenshot(path=f'{OUT}/{W}-{name}.png')
            sw = p.evaluate("()=>document.documentElement.scrollWidth")
            if sw > W: over[name] = sw
        for tab in ['gw', 'team', 'table', 'xis', 'ana']:
            p.evaluate("(h)=>{location.hash=h;window.scrollTo(0,0)}", tab); wait(p, 600); shot(tab)
        p.evaluate("()=>{location.hash='gw/2';window.scrollTo(0,0)}"); wait(p, 600); shot('matchup')
        p.click('.axtog.om button[data-om="1"]'); wait(p); shot('matchup-fixture')
        p.click('#btog'); wait(p); p.evaluate("()=>document.getElementById('btog').scrollIntoView()"); wait(p, 200); shot('matchup-benches')
        p.evaluate("()=>window.scrollTo(0,0)"); p.click('.fc'); wait(p, 600); shot('player-sheet')
        p.evaluate("()=>{sheet.scrollTop=700}"); wait(p, 300); shot('player-sheet-mid')
        p.evaluate("()=>closeSheet()"); wait(p)
        p.evaluate("()=>{location.hash='table';window.scrollTo(0,0)}"); wait(p, 500)
        p.click('.trow[data-prof] >> nth=0'); wait(p, 700); shot('team-sheet')
        p.evaluate("()=>{sheet.scrollTop=1200}"); wait(p, 300); shot('team-sheet-mid')
        p.evaluate("()=>{const s=document.querySelector('#sheet .lkSched');s&&s.scrollIntoView()}"); wait(p, 300); shot('team-sheet-sched')
        p.click('#sheet .lkSched .lkr >> nth=0'); wait(p, 600); shot('past-sheet')
        p.evaluate("()=>closeSheet()"); wait(p); p.evaluate("()=>closeSheet()"); wait(p)
        p.evaluate("()=>{localStorage.setItem('emt-myteam','Trophy Hunters');location.hash='team'}"); wait(p, 300); p.evaluate("()=>renderTeam()"); wait(p, 600); shot('myteam')
        p.evaluate("()=>{location.hash='gw';window.scrollTo(0,0)}"); wait(p, 500)
        p.click('[data-gwtab="derbies"]'); wait(p); shot('derbies')
        p.click('[data-gwtab="week"]'); wait(p); p.click('[data-fbxstep="-1"]'); wait(p); shot('gw5')
        p.click('[data-fbxstep="1"]'); p.click('[data-fbxstep="1"]'); wait(p); shot('gw7')
        errs = [e for e in app.errors if '404' not in e]
        print(W, 'errors:', errs, 'overflow:', over)
