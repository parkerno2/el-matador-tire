"""Second pass: MD-16 touch + lock consistency, MD-17 visible rows, LG-29 small scroll, focus on dark surfaces, smoke."""
import sys, json, os
sys.path.insert(0, '/home/claude/harness')
from harness import App
TAG = sys.argv[1] if len(sys.argv) > 1 else 'x'
OUT = f'/home/claude/harness/fix-b/shots/{TAG}'
os.makedirs(OUT, exist_ok=True)
R = {}
def rec(k, v): R[k] = v; print(k, '=>', json.dumps(v, ensure_ascii=False)[:700])
def wait(p, ms=250): p.wait_for_timeout(ms)
LOCK = "()=>({lock:document.documentElement.classList.contains('lk-lock'),on:sheet.classList.contains('on'),y:window.scrollY,ovl:getComputedStyle(document.documentElement).overflow})"

def swipe(p, x, y0, y1, steps=8):
    # a touch drag via CDP (Playwright's touchscreen only taps)
    cdp = p.context.new_cdp_session(p)
    cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y0}]})
    for i in range(1, steps + 1):
        y = y0 + (y1 - y0) * i / steps
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x, 'y': y}]})
    cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
    cdp.detach()

with App(width=390, height=844) as app:
    p = app.open('v12.html')
    # MD-16: touch swipe on the overlay, wheel at the sheet end, lock released on every close path
    p.evaluate("()=>{location.hash='gw/0'}"); wait(p, 400)
    p.evaluate("()=>window.scrollTo(0,520)"); wait(p, 200)
    p.click('.fc'); wait(p, 500)
    st0 = p.evaluate(LOCK)
    swipe(p, 195, 120, 20); wait(p, 400)
    st1 = p.evaluate(LOCK)
    # scroll the sheet to its end, then wheel more over the sheet
    p.evaluate("()=>{sheet.scrollTop=sheet.scrollHeight}"); wait(p, 200)
    p.mouse.move(195, 700); p.mouse.wheel(0, 600); wait(p, 400)
    st2 = p.evaluate(LOCK)
    # swipe up inside the sheet at its end
    swipe(p, 195, 760, 500); wait(p, 400)
    st3 = p.evaluate(LOCK)
    # close with Esc
    p.keyboard.press('Escape'); wait(p, 500)
    st4 = p.evaluate(LOCK)
    # reopen, close with browser back
    p.click('.fc'); wait(p, 500); p.go_back(); wait(p, 500)
    st5 = p.evaluate(LOCK)
    # reopen, close with overlay tap
    p.click('.fc'); wait(p, 500); p.mouse.click(195, 30); wait(p, 500)
    st6 = p.evaluate(LOCK)
    # the page scrolls again after close
    p.mouse.move(195, 400); p.mouse.wheel(0, 200); wait(p, 300)
    st7 = p.evaluate(LOCK)
    rec('MD-16b', {'open': st0, 'after_touch_overlay': st1, 'after_wheel_sheet_end': st2, 'after_swipe_sheet_end': st3, 'esc': st4, 'back': st5, 'overlay_tap': st6, 'wheel_after': st7})
    # stacked sheets: manager sheet -> player -> back -> back; then team sheet -> next card (lkGoMatch via fbxCloseAll)
    p.evaluate("()=>{location.hash='table';window.scrollTo(0,0)}"); wait(p, 400)
    p.evaluate("()=>openProfile('Cold Palmers')"); wait(p, 500)
    a = p.evaluate(LOCK)
    p.evaluate("()=>{const c=sheet.querySelector('.fc');c&&c.click()}"); wait(p, 500)
    b = p.evaluate(LOCK)
    p.go_back(); wait(p, 500); c = p.evaluate(LOCK)
    p.go_back(); wait(p, 500); d = p.evaluate(LOCK)
    p.evaluate("()=>openProfile('Cold Palmers')"); wait(p, 500)
    p.click('#sheet .lkNext'); wait(p, 800)
    e = p.evaluate(LOCK); e['hash'] = p.evaluate("()=>location.hash")
    rec('MD-16c', {'mgr': a, 'player_on_mgr': b, 'back1': c, 'back2': d, 'next_card_nav': e})

    # MD-17 visible rows
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 500)
    vis = "()=>[...document.querySelectorAll('.mpxrisk .mpxl')].map(l=>[...l.querySelectorAll('span')].filter(s=>s.offsetParent!==null).length)"
    v0 = p.evaluate(vis); btns0 = p.evaluate("()=>[...document.querySelectorAll('.mpxmore')].map(b=>{const r=b.getBoundingClientRect();return [b.textContent,Math.round(r.width),Math.round(r.height)]})")
    p.click('.mpxmore >> nth=0'); wait(p, 300); v1 = p.evaluate(vis)
    p.click('.mpxmore >> nth=0'); wait(p, 300); v2 = p.evaluate(vis)
    rec('MD-17b', {'visible0': v0, 'buttons': btns0, 'after1': v1, 'after2': v2, 'hash': p.evaluate("()=>location.hash")})
    p.screenshot(path=f'{OUT}/17-risk-open.png')

    # focus ring on dark surfaces + sheet x + card + input
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 400)
    def focus_of(sel):
        return p.evaluate("(s)=>{const e=document.querySelector(s);if(!e)return null;e.focus({focusVisible:true});const c=getComputedStyle(e);return {fv:e.matches(':focus-visible'),outline:c.outlineColor+' '+c.outlineStyle+' '+c.outlineWidth+' / '+c.outlineOffset}}", sel)
    f = {}
    for sel in ['#hrefresh', '#hav', '#gwback', '.axtog.om button', '#btog', '.fbx-wr .watch', '.fc', '[data-fbxstep]']:
        p.keyboard.press('Tab')  # keyboard modality so :focus-visible applies
        f[sel] = focus_of(sel)
    p.click('.fc'); wait(p, 400); p.keyboard.press('Tab'); f['.sh-x'] = focus_of('.sh-x')
    p.screenshot(path=f'{OUT}/15-shx-focus.png', clip={'x': 0, 'y': 0, 'width': 390, 'height': 844})
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    p.evaluate("()=>{location.hash='xis'}"); wait(p, 400); p.keyboard.press('Tab'); f['.pfind'] = focus_of('.pfind')
    rec('MD-15b', f)

    # header busy look
    p.evaluate("()=>{location.hash='gw';window.scrollTo(0,0)}"); wait(p, 300)
    p.evaluate("()=>document.getElementById('hrefresh').classList.add('busy')"); wait(p, 100)
    p.screenshot(path=f'{OUT}/08-header-busy.png', clip={'x': 0, 'y': 0, 'width': 390, 'height': 60})
    p.evaluate("()=>document.getElementById('hrefresh').classList.remove('busy')")
    rec('errors_390', [e for e in app.errors if '404' not in e])

with App(width=844, height=390) as app:
    p = app.open('v12.html')
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 500)
    p.click('.fc'); wait(p, 600)
    p.evaluate("()=>{sheet.scrollTop=120}"); wait(p, 300)
    r = p.evaluate("()=>{const sh=sheet.getBoundingClientRect();const g=document.querySelector('#sheet .statgrid.lg').getBoundingClientRect();return {visible:g.bottom<=sh.bottom+1&&g.top>=sh.top-1,labels:[...document.querySelectorAll('#sheet .statgrid.lg .sg')].map(s=>Math.round(s.getBoundingClientRect().height))}}")
    p.screenshot(path=f'{OUT}/29-landscape-scrolled.png')
    rec('LG-29b', r)

with App(width=1280, height=800) as app:
    p = app.open('v12.html')
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 500)
    p.click('.fc'); wait(p, 600)
    p.screenshot(path=f'{OUT}/26-desktop-sheet.png')
    rec('desktop_labels', p.evaluate("()=>[...document.querySelectorAll('#sheet .statgrid.lg .sg')].map(s=>[s.firstChild.textContent,Math.round(s.getBoundingClientRect().height)])"))
    rec('errors_1280', [e for e in app.errors if '404' not in e])

json.dump(R, open(f'{OUT}/results2.json', 'w'), indent=1, ensure_ascii=False)
