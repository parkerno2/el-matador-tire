"""Before/after checks for agent B's findings. Usage: EMT_ROOT=/home/claude/wt-b python3 check.py <tag>"""
import sys, json, os, time
sys.path.insert(0, '/home/claude/harness')
from harness import App
TAG = sys.argv[1] if len(sys.argv) > 1 else 'x'
OUT = f'/home/claude/harness/fix-b/shots/{TAG}'
os.makedirs(OUT, exist_ok=True)
R = {}
def rec(k, v):
    R[k] = v; print(k, '=>', json.dumps(v, ensure_ascii=False)[:600])

RECT = "(e)=>{const r=e.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)]}"
def rect(p, sel, nth=0):
    return p.evaluate("([s,n])=>{const e=document.querySelectorAll(s)[n];if(!e)return null;const r=e.getBoundingClientRect();return [Math.round(r.width*10)/10,Math.round(r.height*10)/10]}", [sel, nth])
def clipped(p, sel):
    return p.evaluate("(s)=>[...document.querySelectorAll(s)].filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent.trim())", sel)

def wait(p, ms=250): p.wait_for_timeout(ms)

def pick_team(p, team):
    p.evaluate("(t)=>{localStorage.setItem('emt-myteam',t)}", team)

# ---------------- 390 ----------------
with App(width=390, height=844) as app:
    p = app.open('v12.html')
    # MD-01: win chance on list / matchup / team page
    lst = p.evaluate("()=>[...document.querySelectorAll('#gwbody .mcard[data-mi]')].map(c=>({mi:c.dataset.mi,pc:[...c.querySelectorAll('.lkwp .lkn')].map(x=>x.textContent)}))")
    md01 = {'list': lst, 'match': {}, 'team': {}}
    for mi in range(4):
        p.evaluate("(i)=>{location.hash='gw/'+i}", mi); wait(p, 400)
        md01['match'][mi] = p.evaluate("()=>[...document.querySelectorAll('.mpxwin>b')].map(x=>x.textContent)")
        teams = p.evaluate("()=>[...document.querySelectorAll('.lkMH .lkt')].map(x=>x.dataset.lkprof)")
        for t in teams:
            p.evaluate("(t)=>openProfile(t)", t); wait(p, 400)
            md01['team'][t] = p.evaluate("()=>{const e=document.querySelector('#sheet .lkNext .lkp .lkn');return e?e.textContent:null}")
            p.evaluate("()=>closeSheet()"); wait(p, 300)
    rec('MD-01', md01)
    p.evaluate("()=>{location.hash='gw'}"); wait(p, 400)

    # MD-08 / LG-32: tap targets
    tt = {}
    tt['hrefresh'] = rect(p, '#hrefresh'); tt['hav'] = rect(p, '#hav')
    tt['hav_tag'] = p.evaluate("()=>document.getElementById('hav').tagName")
    tt['fbxstep'] = rect(p, '[data-fbxstep]'); tt['gwtab'] = rect(p, '[data-gwtab]')
    tt['allart'] = rect(p, '#allart'); tt['allart_tag'] = p.evaluate("()=>{const e=document.getElementById('allart');return e?e.tagName:null}")
    tt['plall'] = rect(p, '#plall'); tt['helpfoot'] = rect(p, '.helpfoot button')
    tt['header_h'] = rect(p, '.top')
    p.click('[data-fbxstep="-1"]'); wait(p, 300)
    tt['fbx-now'] = rect(p, '.fbx-now')
    p.click('.fbx-now'); wait(p, 300)
    p.evaluate("()=>{location.hash='gw/0'}"); wait(p, 400)
    tt['gwback'] = rect(p, '#gwback'); tt['axtog'] = rect(p, '.axtog.om button'); tt['btog'] = rect(p, '#btog'); tt['watch_mx'] = rect(p, '.fbx-wr .watch')
    p.click('.fc'); wait(p, 400)
    tt['sh-x'] = rect(p, '.sh-x')
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    p.evaluate("()=>{location.hash='gw'}"); wait(p, 300)
    p.evaluate("()=>fbxOpenPast(1,0)"); wait(p, 400)
    tt['fbx-pl'] = rect(p, '.fbx-pl')
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    pick_team(p, 'Cold Palmers'); p.evaluate("()=>{location.hash='team'}"); wait(p, 500)
    tt['lkact_btn'] = rect(p, '.lkTH .lkact button'); tt['watch_team'] = rect(p, '.watchrow .watch')
    tt['axtog_team'] = rect(p, '#teampage .axtog.om button')
    rec('MD-08', tt)
    p.screenshot(path=f'{OUT}/08-team-390.png')
    p.evaluate("()=>{location.hash='gw'}"); wait(p, 300)
    p.screenshot(path=f'{OUT}/08-header-390.png', clip={'x':0,'y':0,'width':390,'height':120})

    # T5: claimed team header button vs sheet title (Cold Palmers has a profile)
    p.evaluate("()=>{location.hash='team'}"); wait(p, 400)
    btn = p.evaluate("()=>{const b=document.querySelector('.lkTH .lkact button');return b?b.textContent.trim():null}")
    p.click('.lkTH .lkact button'); wait(p, 500)
    title = p.evaluate("()=>{const t=document.getElementById('au-title');return t?t.textContent:null}")
    go = p.evaluate("()=>{const t=document.getElementById('au-go');return t?t.textContent:null}")
    rec('T5', {'button': btn, 'sheet_title': title, 'sheet_go': go, 'PROFILE': p.evaluate("()=>!!PROFILE['Cold Palmers']")})
    p.evaluate("()=>closeSheet()"); wait(p, 300)

    # MD-16: page behind an open sheet scrolls
    p.evaluate("()=>{location.hash='gw/0'}"); wait(p, 400)
    p.evaluate("()=>window.scrollTo(0,520)"); wait(p, 200)
    p.click('.fc'); wait(p, 500)
    y0 = p.evaluate("()=>window.scrollY")
    p.mouse.move(195, 60); p.mouse.wheel(0, 400); wait(p, 400)
    y1 = p.evaluate("()=>window.scrollY")
    # touch swipe on the overlay
    p.touchscreen.tap(195, 40) if False else None
    sheet_scroll_ok = p.evaluate("()=>{const s=document.getElementById('sheet');s.scrollTop=300;return s.scrollTop>0}")
    p.evaluate("()=>closeSheet()"); wait(p, 400)
    y2 = p.evaluate("()=>window.scrollY")
    rec('MD-16', {'before_wheel': y0, 'after_wheel': y1, 'after_close': y2, 'sheet_scrolls': sheet_scroll_ok})

    # MD-17: minutes risk +N more
    found = None
    for mi in range(4):
        p.evaluate("(i)=>{location.hash='gw/'+i;window.scrollTo(0,0)}", mi); wait(p, 400)
        n = p.evaluate("()=>document.querySelectorAll('.mpxrisk .no').length")
        more = p.evaluate("()=>[...document.querySelectorAll('.mpxrisk .no')].filter(x=>/more/.test(x.textContent)).length")
        if more:
            before = p.evaluate("()=>[...document.querySelectorAll('.mpxrisk .mpxl')].map(l=>l.querySelectorAll('span').length)")
            p.click('.mpxrisk .no:has-text("more")' if False else 'text=/\\+\\d+ more/'); wait(p, 300)
            after = p.evaluate("()=>[...document.querySelectorAll('.mpxrisk .mpxl')].map(l=>l.querySelectorAll('span').length)")
            still = p.evaluate("()=>[...document.querySelectorAll('.mpxrisk .no')].filter(x=>/more/.test(x.textContent)).map(x=>x.textContent)")
            found = {'mi': mi, 'spans_before': before, 'spans_after': after, 'more_left': still}
            p.screenshot(path=f'{OUT}/17-risk-{mi}.png')
            break
    rec('MD-17', found)

    # MD-15 / LG-26: focus-visible
    p.evaluate("()=>{location.hash='gw';window.scrollTo(0,0)}"); wait(p, 400)
    p.evaluate("()=>document.getElementById('hrefresh').focus()")
    p.keyboard.press('Tab'); wait(p, 100)
    foc = p.evaluate("()=>{const e=document.activeElement;const s=getComputedStyle(e);return {tag:e.tagName,id:e.id,cls:e.className,outline:s.outlineColor+' '+s.outlineStyle+' '+s.outlineWidth+' off '+s.outlineOffset,fv:e.matches(':focus-visible')}}")
    cards = p.evaluate("()=>[...document.querySelectorAll('#gwbody .mcard[data-mi]')].map(c=>({tab:c.getAttribute('tabindex'),role:c.getAttribute('role')}))")
    # Tab until a matchup card is focused (max 40 tabs)
    reached = False
    for i in range(40):
        p.keyboard.press('Tab')
        a = p.evaluate("()=>{const e=document.activeElement;return e.classList.contains('mcard')?e.dataset.mi:null}")
        if a is not None:
            reached = True; break
    card_focus = p.evaluate("()=>{const e=document.activeElement;const s=getComputedStyle(e);return {cls:e.className,outline:s.outlineColor+' '+s.outlineStyle+' '+s.outlineWidth}}") if reached else None
    if reached:
        p.screenshot(path=f'{OUT}/15-card-focus.png')
        p.keyboard.press('Enter'); wait(p, 400)
        enter_opens = p.evaluate("()=>location.hash")
    else: enter_opens = None
    rec('MD-15', {'first_focus': foc, 'cards': cards, 'card_reachable': reached, 'card_focus': card_focus, 'enter_hash': enter_opens})

    # LG-14: Lab scope tab labels after a tap
    p.evaluate("()=>{location.hash='ana';window.scrollTo(0,0)}"); wait(p, 500)
    l0 = p.evaluate("()=>[...document.querySelectorAll('#v-ana .labseg button')].map(b=>b.textContent.trim())")
    p.click('#v-ana .labmet >> nth=1'); wait(p, 300)
    l1 = p.evaluate("()=>[...document.querySelectorAll('#v-ana .labseg button')].map(b=>b.textContent.trim())")
    rec('LG-14', {'initial': l0, 'after_tap': l1})

    # T11: Trophy Hunters close games
    p.evaluate("()=>openProfile('Trophy Hunters')"); wait(p, 500)
    cg = p.evaluate("()=>{const r=[...document.querySelectorAll('#sheet .tsx-row')].find(x=>/^Close games/.test(x.textContent));return r?r.querySelector('.tsx-n').textContent:null}")
    rec('T11', cg)
    p.evaluate("()=>closeSheet()"); wait(p, 300)

    # TP-17 / #26: player sheet average vs list per game
    info = p.evaluate("""()=>{const own=D.ro.filter(r=>Math.abs(plrAvg(r)-num(r['Season pts'])/Math.max(1,D.gwsDone))>0.05).sort((a,b)=>num(b['Season pts'])-num(a['Season pts']))[0];
      const fa=(D.plr||[]).filter(r=>r.Owner==='FREE'&&num(r['Season pts'])>0&&Math.abs(plrAvg(r)-num(r['Season pts'])/Math.max(1,D.gwsDone))>0.05).sort((a,b)=>num(b['Season pts'])-num(a['Season pts']))[0];
      return {own:own?{name:own.Player,code:own.Code,list:plrAvg(own).toFixed(1)}:null,fa:fa?{name:fa.Player,code:fa.Code,list:plrAvg(fa).toFixed(1)}:null,gwsDone:D.gwsDone}}""")
    res = {'picked': info}
    if info['own']:
        p.evaluate("(c)=>openSheet(D.ro.find(r=>String(r.Code)===String(c)))", str(info['own']['code'])); wait(p, 500)
        res['own_sheet'] = p.evaluate("()=>[...document.querySelectorAll('#sheet .statgrid.lg .sg')].map(s=>s.textContent.trim().replace(/\\s+/g,' '))")
        p.screenshot(path=f'{OUT}/26-own-sheet.png')
        p.evaluate("()=>closeSheet()"); wait(p, 300)
    if info['fa']:
        p.evaluate("(c)=>fbxOpenPlayer(c)", str(info['fa']['code'])); wait(p, 500)
        res['fa_sheet'] = p.evaluate("()=>[...document.querySelectorAll('#sheet .srow')].map(s=>s.textContent.trim())")
        p.screenshot(path=f'{OUT}/26-fa-sheet.png')
        p.evaluate("()=>closeSheet()"); wait(p, 300)
    # the Players list label for that player
    p.evaluate("()=>{location.hash='xis'}"); wait(p, 400)
    if info['own']:
        p.fill('.pfind', info['own']['name'].split(' ')[-1]); wait(p, 400)
        res['own_list'] = p.evaluate("()=>{const r=document.querySelector('#xisbody .prw');return r?r.textContent.trim().replace(/\\s+/g,' '):null}")
    rec('TP-17', res)

    # LG-31: --mid token + contrast
    def lum(h):
        h = h.lstrip('#'); c = [int(h[i:i+2], 16)/255 for i in (0,2,4)]
        c = [x/12.92 if x <= .03928 else ((x+.055)/1.055)**2.4 for x in c]
        return .2126*c[0]+.7152*c[1]+.0722*c[2]
    def cr(a, b):
        la, lb = lum(a), lum(b); la, lb = max(la, lb), min(la, lb); return round((la+.05)/(lb+.05), 2)
    mid = p.evaluate("()=>getComputedStyle(document.body).getPropertyValue('--mid').trim()")
    rec('LG-31', {'--mid': mid, 'on_white': cr(mid, '#ffffff'), 'on_ground': cr(mid, '#F5F3F8')})
    rec('errors_390', app.errors)

# ---------------- 320 ----------------
with App(width=320, height=640) as app:
    p = app.open('v12.html')
    md10 = {}
    for mi in range(4):
        p.evaluate("(i)=>{location.hash='gw/'+i;window.scrollTo(0,0)}", mi); wait(p, 500)
        md10[mi] = p.evaluate("""()=>{const sw=document.documentElement.scrollWidth;const cr=document.querySelector('.lkMH .lkt svg');const r=cr?cr.getBoundingClientRect():null;
          const names=[...document.querySelectorAll('.mpxg3 span')].map(s=>{const i=s.querySelector('i');const sr=s.getBoundingClientRect();return {t:s.textContent.trim(),clip:s.scrollWidth>s.clientWidth+1,plusHidden:i?(i.getBoundingClientRect().right>sr.right+1||i.getBoundingClientRect().left<sr.left-1||i.offsetWidth===0):false}});
          const recs=[...document.querySelectorAll('.lkMH .lkrec')].map(e=>Math.round(e.getBoundingClientRect().height));
          const lkt=[...document.querySelectorAll('.lkMH .lkt')].map(e=>Math.round(e.getBoundingClientRect().width));
          return {scrollWidth:sw,crestLeft:r?Math.round(r.left):null,crestW:r?Math.round(r.width):null,lktW:lkt,recH:recs,names}}""")
        p.screenshot(path=f'{OUT}/10-mx{mi}-320.png')
    rec('MD-10', md10)
    # LG-27: sheet width at 320
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 400)
    p.click('.fc'); wait(p, 500)
    rec('LG-27', {'docW': p.evaluate("()=>document.documentElement.scrollWidth"), 'sheetW': rect(p, '#sheet')})
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    # T7: schedule names at 320
    p.evaluate("()=>openProfile('Kobbie Mainoo Fan')"); wait(p, 600)
    t7 = clipped(p, '#sheet .lkSched .lko b') + clipped(p, '#sheet .lkSched .lko span')
    p.evaluate("()=>{const s=document.querySelector('#sheet .lkSched');if(s)s.scrollIntoView()}"); wait(p, 200)
    p.screenshot(path=f'{OUT}/T7-sched-320.png')
    rec('T7', {'clipped': t7, 'rows': p.evaluate("()=>[...document.querySelectorAll('#sheet .lkSched .lko b')].map(b=>b.textContent)")})
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    # TP-7 / TP-8: Trophy Hunters sheet at 320
    p.evaluate("()=>openProfile('Trophy Hunters')"); wait(p, 600)
    tp7 = p.evaluate("""()=>{const m=document.querySelector('#sheet .lkTH .lkm');if(!m)return null;const txt=m.textContent;const i=txt.search(/\\d+-\\d+-\\d+/);
      let node=null,off=0;const w=document.createTreeWalker(m,NodeFilter.SHOW_TEXT);let acc=0;while(w.nextNode()){const n=w.currentNode;if(acc+n.textContent.length>i){node=n;off=i-acc;break}acc+=n.textContent.length}
      if(!node)return {txt,recH:null};const rg=document.createRange();rg.setStart(node,off);rg.setEnd(node,Math.min(node.textContent.length,off+5));return {txt,recLines:rg.getClientRects().length,lkmH:Math.round(m.getBoundingClientRect().height)}}""")
    p.screenshot(path=f'{OUT}/TP7-head-320.png', clip={'x':0,'y':0,'width':320,'height':640})
    tp8 = p.evaluate("""()=>{const pcs=[...document.querySelectorAll('#sheet .tsx-pc')];if(!pcs.length)return null;const card=document.querySelector('#sheet .tsx').getBoundingClientRect();
      return pcs.map(c=>{const r=c.getBoundingClientRect();return {t:c.textContent.trim(),over:Math.round(r.right-card.right)}})}""")
    p.evaluate("()=>{const s=document.querySelector('#sheet .tsx-pcs');if(s)s.scrollIntoView({block:'center'})}"); wait(p, 200)
    p.screenshot(path=f'{OUT}/TP8-chips-320.png')
    rec('TP-7', tp7); rec('TP-8', tp8)
    p.evaluate("()=>closeSheet()"); wait(p, 300)
    # T13: past result sheet names at 320
    p.evaluate("()=>{location.hash='gw'}"); wait(p, 300)
    t13 = {}
    for g in range(1, 6):
        for i in range(4):
            p.evaluate("([g,i])=>fbxOpenPast(g,i)", [g, i]); wait(p, 350)
            c = clipped(p, '#sheet .fbx-pn')
            if c: t13[f'{g}/{i}'] = c
            if g == 1 and i == 0: p.screenshot(path=f'{OUT}/T13-past-320.png')
            p.evaluate("()=>closeSheet()"); wait(p, 200)
    rec('T13', t13)
    rec('errors_320', app.errors)

# ---------------- landscape 844x390 (LG-29) ----------------
with App(width=844, height=390) as app:
    p = app.open('v12.html')
    p.evaluate("()=>{location.hash='gw/0';window.scrollTo(0,0)}"); wait(p, 500)
    p.click('.fc'); wait(p, 600)
    lg29 = p.evaluate("""()=>{const sh=document.getElementById('sheet').getBoundingClientRect();const g=document.querySelector('#sheet .statgrid.lg');if(!g)return {nogrid:true};const r=g.getBoundingClientRect();
      const st=document.querySelector('#sheet .lkstick');return {sheetH:Math.round(sh.height),sheetBottom:Math.round(sh.bottom),gridTop:Math.round(r.top),gridBottom:Math.round(r.bottom),visible:r.bottom<=sh.bottom+1&&r.top>=sh.top-1,sticky:st?getComputedStyle(st).position:null,vw:innerWidth,vh:innerHeight}}""")
    p.screenshot(path=f'{OUT}/29-landscape-sheet.png')
    p.evaluate("()=>{document.getElementById('sheet').scrollTop=99999}"); wait(p, 300)
    lg29['after_scroll_end'] = p.evaluate("()=>{const sh=document.getElementById('sheet').getBoundingClientRect();const g=document.querySelector('#sheet .statgrid.lg');const r=g.getBoundingClientRect();return r.bottom<=sh.bottom+1}")
    p.screenshot(path=f'{OUT}/29-landscape-sheet-end.png')
    rec('LG-29', lg29)
    rec('errors_844', app.errors)

json.dump(R, open(f'{OUT}/results.json', 'w'), indent=1, ensure_ascii=False)
print('saved', OUT)
