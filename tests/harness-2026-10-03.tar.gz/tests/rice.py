import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
S='/home/claude/harness/shots/'
page=sys.argv[1] if len(sys.argv)>1 else 'index.html'
with App() as app:
    p=app.open(page)
    p.get_by_role('button',name='Players').last.click(); p.wait_for_timeout(500)
    inp=p.locator('input[type=search], input[placeholder*="earch"]').first
    inp.fill('Rice'); p.wait_for_timeout(600)
    p.screenshot(path=S+'rice0-search.png')
    row=p.locator('text=Rice').nth(1) if p.locator('text=Rice').count()>1 else p.locator('text=Rice').first
    print('matches',p.locator('text=Rice').count())
    p.get_by_text('Rice',exact=True).first.click(); p.wait_for_timeout(800)
    def state(tag):
        return p.evaluate("""()=>{const s=document.getElementById('sheet');const im=s&&s.querySelector('.fc img, .sh-left img');
          const sc=[s, s&&s.parentElement, document.scrollingElement].filter(Boolean).map(e=>e.id||e.className||e.tagName+':'+e.scrollTop);
          if(!im)return {img:null, noface:!!(s&&s.querySelector('.noface')), html:(s&&s.querySelector('.sh-left')||{}).innerHTML?.slice(0,300)};
          const r=im.getBoundingClientRect();
          return {src:im.currentSrc.split('/').slice(-2).join('/'),complete:im.complete,nw:im.naturalWidth,top:Math.round(r.top),h:Math.round(r.height),vis:getComputedStyle(im).visibility,disp:getComputedStyle(im).display,op:getComputedStyle(im).opacity}}""")
    print('open', state('open'))
    p.screenshot(path=S+'rice1-open.png')
    # find the scroll container of the sheet
    info=p.evaluate("""()=>{const out=[];let e=document.querySelector('#sheet .sh-right')||document.getElementById('sheet');
      while(e){const cs=getComputedStyle(e);if(e.scrollHeight>e.clientHeight+5&&/(auto|scroll)/.test(cs.overflowY))out.push((e.id||e.className||e.tagName)+' sh='+e.scrollHeight+' ch='+e.clientHeight);e=e.parentElement}return out}""")
    print('scrollers', info)
    for i,dy in enumerate([300,300,400,600,-600,-400,-300,-300]):
        p.mouse.move(195,600); p.mouse.wheel(0,dy); p.wait_for_timeout(400)
        print(i,dy,state(str(i)))
        p.screenshot(path=S+f'rice2-{i}.png')
    print('errors',app.errors)
