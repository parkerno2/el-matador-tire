import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
S='/home/claude/harness/shots/'
with App() as app:
    p=app.open('v12.html')
    p.on('response', lambda r: r.status>=400 and print('HTTP',r.status,r.url))
    p.get_by_role('button',name='Players').last.click(); p.wait_for_timeout(400)
    p.locator('input').first.fill('Rice'); p.wait_for_timeout(400)
    p.get_by_text('Rice',exact=True).first.click(); p.wait_for_timeout(90)
    p.screenshot(path=S+'anim-mid.png'); p.wait_for_timeout(600)
    p.screenshot(path=S+'anim-open.png')
    print(p.evaluate("()=>{const r=document.getElementById('sheet').getBoundingClientRect();return [r.left,r.width,r.top,r.bottom,getComputedStyle(document.getElementById('sheet')).transform]}"))
    p.keyboard.press('Escape'); p.wait_for_timeout(500)
    print(p.evaluate("()=>{const r=document.getElementById('sheet').getBoundingClientRect();return [r.left,r.width,r.top,r.bottom,innerHeight]}"))
    p.screenshot(path=S+'anim-closed.png')
    print([r for r in app.requests if 'faces' in r][:5])
