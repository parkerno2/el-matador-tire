import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=390,height=844,api=lambda req:{'ok':False,'error':'unknown action'}) as app:
    p=app.open('v12.html')
    p.evaluate("document.getElementById('hrefresh').click()")
    for t in range(12):
        p.wait_for_timeout(500); print(t*0.5+0.5, p.evaluate("document.getElementById('ptr').textContent"))
