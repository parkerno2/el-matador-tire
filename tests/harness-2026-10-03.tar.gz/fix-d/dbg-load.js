const path='/home/claude/wt-d/fplgg/tools/v12/test-engines.js';
const src=require('fs').readFileSync(path,'utf8').replace(/main\(\)\.catch[\s\S]*$/,'module.exports={openPage,league,makeEnv};');
const m=new module.constructor();m.paths=module.paths;m._compile(src,path);
(async()=>{const E=await m.exports.openPage(process.argv[2],{},'2026-10-03T21:00:00Z');
console.log('errors',E.errors.length, E.errors.slice(0,5).map(e=>e.slice(0,600)).join('\n---\n'));
for(const n of ['hpPlayer','psxPreHTML','lkFresh','fbxStackable','lkSheetFix','simulate','loadAll']) console.log(n, E.ev('typeof '+n));
try{console.log(E.ev('typeof lk_sim'))}catch(e){console.log('ERR',e.message)}
})();
