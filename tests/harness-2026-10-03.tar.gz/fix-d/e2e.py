"""Agent D end-to-end checks (Playwright harness).
   python3 e2e.py diff  <tabs> <now>   old build (fix-d/base-root) vs new (wt-d): visible text of every tab + sheets
   python3 e2e.py smoke <tabs> <now>   new build at 390 and 320: five tabs, player sheet, team sheet, matchup; screenshots
   python3 e2e.py live                 live-replay fixture: odds card, Matchday cards, proj final; old vs new screenshots"""
import sys, os, json, difflib, pathlib
sys.path.insert(0, '/home/claude/harness')
import harness
from harness import App
OLD = pathlib.Path('/home/claude/harness/fix-d/base-root'); NEW = pathlib.Path('/home/claude/wt-d')
SH = pathlib.Path('/home/claude/harness/fix-d/shots'); SH.mkdir(exist_ok=True)
REAL = '/home/claude/harness/tabs'; LIVE = '/home/claude/harness/fix-d/tabs-live'
VIEWS = [('gw', 'Matchday'), ('team', 'My team'), ('table', 'Table'), ('xis', 'Players'), ('ana', 'Lab')]
IGNORE_404 = lambda e: 'Failed to load resource' in e and '404' in e

def go(p, h):
    p.evaluate("h=>{location.hash=h}", h); p.wait_for_timeout(450)

def grab(root, tabs, now, width=390):
    harness.ROOT = root
    out = {}
    with App(width=width, height=844, now=now, tabs=tabs) as app:
        p = app.open('v12.html')
        for v, _ in VIEWS:
            go(p, v); out[v] = p.evaluate("v=>document.getElementById('v-'+v).innerText", v)
        go(p, 'gw/0'); out['matchup'] = p.evaluate("()=>document.getElementById('v-gw').innerText")
        go(p, 'table')
        p.evaluate("openSheet(D.ro.find(r=>r['Best XI']==='XI'&&r.Pos==='MID'))"); p.wait_for_timeout(500)
        out['player-sheet'] = p.evaluate("()=>document.getElementById('sheet').innerText")
        p.evaluate("typeof fbxCloseAll==='function'?fbxCloseAll():null"); p.wait_for_timeout(400)
        p.evaluate("openProfile(Object.keys(TEAMS)[0])"); p.wait_for_timeout(500)
        out['team-sheet'] = p.evaluate("()=>document.getElementById('sheet').innerText")
        out['_errors'] = [e for e in app.errors if not IGNORE_404(e)]
        out['_odds'] = p.evaluate("()=>{const s=simulate();return s}")
    return out

def diff(tabs, now):
    a, b = grab(OLD, tabs, now), grab(NEW, tabs, now)
    for k in a:
        if k.startswith('_'): continue
        if a[k] == b[k]: print('same   ', k, len(a[k]), 'chars'); continue
        d = [l for l in difflib.unified_diff(a[k].splitlines(), b[k].splitlines(), 'old', 'new', n=0, lineterm='') if not l.startswith(('---', '+++'))]
        print('DIFFERS', k, '(%d changed lines)' % len([l for l in d if l[:1] in '+-']))
        for l in d[:40]: print('        ', l)
    print('odds old', {t: round(v, 1) for t, v in a['_odds']['title'].items()})
    print('odds new', {t: round(v, 1) for t, v in b['_odds']['title'].items()})
    print('errors old', a['_errors']); print('errors new', b['_errors'])

def smoke(tabs, now, tag):
    harness.ROOT = NEW
    for w, h in ((390, 844), (320, 640)):
        with App(width=w, height=h, now=now, tabs=tabs) as app:
            p = app.open('v12.html')
            for v, name in VIEWS:
                p.get_by_role('button', name=name).last.click(); p.wait_for_timeout(500)
                p.screenshot(path=str(SH / f'{tag}-{w}-{v}.png'))
                sw = p.evaluate("()=>document.documentElement.scrollWidth")
                if sw > w: print('  overflow', w, v, sw)
            p.get_by_role('button', name='Matchday').last.click(); p.wait_for_timeout(400)
            go(p, 'gw/0'); p.screenshot(path=str(SH / f'{tag}-{w}-matchup.png'), full_page=True)
            go(p, 'xis'); p.evaluate("openSheet(D.ro.find(r=>r['Best XI']==='XI'&&r.Pos==='FWD'))"); p.wait_for_timeout(700)
            p.screenshot(path=str(SH / f'{tag}-{w}-player-sheet.png'))
            p.keyboard.press('Escape'); p.wait_for_timeout(400)
            p.evaluate("typeof fbxCloseAll==='function'?fbxCloseAll():null"); p.wait_for_timeout(400)
            go(p, 'table'); p.evaluate("openProfile(Object.keys(TEAMS)[1])"); p.wait_for_timeout(700)
            p.screenshot(path=str(SH / f'{tag}-{w}-team-sheet.png'))
            errs = [e for e in app.errors if not IGNORE_404(e)]
            print(tag, w, 'errors:', errs if errs else 'none', '| 404 lines:', len(app.errors) - len(errs))

def live():
    now = '2026-10-10T15:00:00Z'
    for tag, root in (('old', OLD), ('new', NEW)):
        harness.ROOT = root
        with App(width=390, height=844, now=now, tabs=LIVE) as app:
            p = app.open('v12.html')
            pill = p.evaluate("()=>document.getElementById('gwpill').textContent")
            p.screenshot(path=str(SH / f'live-{tag}-matchday.png'), full_page=True)
            cards = p.evaluate("()=>[...document.querySelectorAll('#gwbody .lkrow, #gwbody .mcard, #gwbody .lkm')].slice(0,8).map(c=>c.innerText.replace(/\\s+/g,' ').trim())")
            proj = p.evaluate("()=>D.fx.filter(f=>num(f.GW)===D.gw).map(f=>[f.Home,mscore(f).hs,+teamProj(f.Home).toFixed(1),f.Away,mscore(f).as2,+teamProj(f.Away).toFixed(1),hpWin(f)].map(x=>typeof x==='object'?{h:+x.h.toFixed(3),d:+x.d.toFixed(3),a:+x.a.toFixed(3)}:x))")
            go(p, 'table'); p.wait_for_timeout(300)
            p.screenshot(path=str(SH / f'live-{tag}-table.png'), full_page=True)
            odds = p.evaluate("()=>document.getElementById('v-table').innerText")
            m = p.evaluate("()=>typeof hpSimModel==='function'?Object.fromEntries(Object.entries(hpSimModel().M).filter(([k])=>k.endsWith('|'+D.gw)).map(([k,v])=>[k.split('|')[0],{mean:+v.mean.toFixed(1),banked:+v.banked.toFixed(1),rem:+v.rem.toFixed(1),sd:+v.sd.toFixed(1)}])):null")
            go(p, 'gw/0'); p.screenshot(path=str(SH / f'live-{tag}-matchup.png'), full_page=True)
            errs = [e for e in app.errors if not IGNORE_404(e)]
            print('==', tag, '| pill:', pill, '| errors:', errs if errs else 'none')
            print('   matchups [home, live, proj, away, live, proj, win]:'); [print('    ', x) for x in proj]
            print('   cards:', cards[:4])
            print('   table text:', odds[:700].replace('\n', ' | '))
            if m: print('   live GW model:', json.dumps(m))

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'diff': diff(sys.argv[2], sys.argv[3])
    elif mode == 'smoke': smoke(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else 'smoke')
    elif mode == 'live': live()
