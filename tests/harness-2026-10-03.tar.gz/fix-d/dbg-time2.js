const path='/home/claude/wt-d/fplgg/tools/v12/test-engines.js';
const fs=require('fs');
const src=fs.readFileSync(path,'utf8').replace(/main\(\)\.catch[\s\S]*$/,'module.exports={openPage,league,makeEnv};');
const m=new module.constructor();m.paths=module.paths;m._compile(src,path);
(async()=>{const tabs={};fs.readdirSync('/home/claude/harness/tabs').forEach(f=>tabs[f.slice(0,-5)]=fs.readFileSync('/home/claude/harness/tabs/'+f,'utf8'));
let t=Date.now();const E2=await m.exports.openPage(process.argv[2],tabs,'2026-10-03T21:00:00Z');console.log('open real',Date.now()-t, E2.ev('D.ro.length'), E2.errors.length);
t=Date.now();E2.ev('(()=>{D.pbonus=Object.assign({},D.pbonus);return simulate()})()');console.log('sim',Date.now()-t);
t=Date.now();E2.ev('(()=>{D.pbonus=Object.assign({},D.pbonus);return simulate()})()');console.log('sim2',Date.now()-t);
})();
