#!/usr/bin/env python3
"""Build the live-replay tab set: the real 3 Oct sheet export (harness/tabs) edited to look like
Saturday 10 Oct 2026, 15:00 UTC, GW6 in play.  Deterministic: same input, same output.

    python3 make_tabs_live.py [SRC=/home/claude/harness/tabs] [OUT=/home/claude/harness/fix-d/tabs-live]

State it produces (see README.md):
  - Matchweeks: unchanged (GW6 deadline Sat 10 Oct 10:00 UTC, Finished FALSE) -> open with App(now='2026-10-10T15:00:00Z')
  - Club Fixtures GW6: ARS-LEE (11:30) full time 2-0; the four 14:00 games live at 55'; MUN-TOT and the
    Sunday/Monday games not started
  - GW Stats: a GW6 block (Final FALSE) for every player: minutes/points/BPS for the started games, zeros elsewhere;
    official bonus not in yet (Bonus 0) so provisional bonus is exercised on ARS-LEE
  - Rosters: lineups published at the deadline (GW XI / Slot from each team's Best XI), GW pts / GW mins filled
  - H2H Fixtures GW6: FPL's live totals (sum of XI points, no provisional bonus)
  - Predictions: GW7 block added (Code.gs captures the next GW's block once GW6's deadline passes)
  - Players: Season pts include the GW6 points so far
"""
import json, sys, shutil, pathlib, hashlib

SRC = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/home/claude/harness/tabs')
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else '/home/claude/harness/fix-d/tabs-live')
GW = 6
FT = {('ARS', 'LEE'): (2, 0)}                                   # full time
LIVE = {('AVL', 'BRE'): (1, 1), ('CHE', 'BOU'): (1, 0), ('IPS', 'FUL'): (0, 0), ('SUN', 'BHA'): (0, 2)}   # 55'
LIVE_MIN = 55

def h01(*k):
    return int(hashlib.md5('|'.join(map(str, k)).encode()).hexdigest()[:8], 16) / 0xFFFFFFFF

def load(name):
    d = json.loads((SRC / (name + '.json')).read_text())
    cols = [c['label'] for c in d['table']['cols']]
    rows = []
    for r in d['table']['rows']:
        o = {}
        for i, c in enumerate(r['c']):
            if i >= len(cols): continue
            o[cols[i]] = None if c is None else (c.get('f') if c.get('f') is not None else c.get('v'))
        rows.append(o)
    return d, cols, rows

def cell(v):
    if v is None or v == '': return None
    if isinstance(v, bool): return {'v': v, 'f': 'TRUE' if v else 'FALSE'}
    if isinstance(v, (int, float)): return {'v': float(v), 'f': ('%g' % v)}
    if v in ('TRUE', 'FALSE'): return {'v': v == 'TRUE', 'f': v}
    return {'v': v}

def save(name, d, cols, rows):
    d = dict(d); t = dict(d['table'])
    t['rows'] = [{'c': [cell(r.get(c)) for c in cols]} for r in rows]
    d['table'] = t
    (OUT / (name + '.json')).write_text(json.dumps(d, ensure_ascii=False))

def num(v):
    try: return float(str(v).replace(',', ''))
    except Exception: return 0.0

if OUT.exists(): shutil.rmtree(OUT)
shutil.copytree(SRC, OUT)

# ---- Club Fixtures
d, cols, cf = load('Club Fixtures')
state = {}
for f in cf:
    if num(f['GW']) != GW: continue
    k = (f['Home'], f['Away'])
    if k in FT:
        f.update({'Started': 'TRUE', 'Finished': 'TRUE', 'Mins': '90', 'Home goals': str(FT[k][0]), 'Away goals': str(FT[k][1])}); state[k] = ('ft', FT[k])
    elif k in LIVE:
        f.update({'Started': 'TRUE', 'Finished': 'FALSE', 'Mins': str(LIVE_MIN), 'Home goals': str(LIVE[k][0]), 'Away goals': str(LIVE[k][1])}); state[k] = ('live', LIVE[k])
save('Club Fixtures', d, cols, cf)
club_fx = {}
for (h, a), (st, g) in state.items():
    club_fx[h] = (st, g[0], g[1], a)
    club_fx[a] = (st, g[1], g[0], h)

# ---- GW Stats GW6 block: from each player's GW5 role
d, gcols, gws = load('GW Stats')
gw5 = {r['Code']: r for r in gws if num(r['GW']) == 5}
_, _, plr = load('Players')
CS = {'GKP': 4, 'DEF': 4, 'MID': 1, 'FWD': 0}
GOAL = {'GKP': 10, 'DEF': 6, 'MID': 5, 'FWD': 4}
block = []
by_club = {}
for p in plr:
    by_club.setdefault(p['Club'], []).append(p)
for club, ps in by_club.items():
    fx = club_fx.get(club)
    for p in ps:
        code = p['Code']; r5 = gw5.get(code, {})
        row = {c: 0 for c in gcols}
        row.update({'GW': GW, 'Code': code, 'Player': p['Player'], 'Pos': p['Pos'], 'Club': club,
                    'Owner': '' if p.get('Owner') in (None, 'FREE') else p['Owner'], 'Final': 'FALSE'})
        if fx and p.get('Status', 'a') == 'a':
            st, gf, ga, opp = fx
            started5, mins5 = num(r5.get('Starts')), num(r5.get('Mins'))
            full = 90 if st == 'ft' else LIVE_MIN
            mins = full if started5 else (min(20, full - 35) if mins5 > 0 and full > 35 else 0)
            if mins > 0:
                pos = p['Pos']
                pts = 2 if mins >= 60 else 1
                cs = 1 if (ga == 0 and mins >= 60 and pos != 'FWD') else 0
                pts += CS[pos] * cs
                if pos in ('GKP', 'DEF') and ga >= 2: pts -= ga // 2
                xg = round((0.45 if pos == 'FWD' else 0.18 if pos == 'MID' else 0.04) * mins / 90 * (0.5 + h01('xg', code)), 2)
                xa = round(0.1 * mins / 90 * (0.5 + h01('xa', code)), 2)
                row.update({'Mins': mins, 'Starts': 1 if started5 else 0, 'CS': cs, 'GC': ga if mins >= 1 else 0,
                            'xG': xg, 'xA': xa, 'xGC': round(0.9 * mins / 90 + 0.3 * ga, 2)})
                row['_pts'] = pts
                block.append(row)
                continue
        row['_pts'] = 0
        block.append(row)
# goals and assists: the club's goals go to its highest-xG players on the pitch (deterministic)
for club, fx in club_fx.items():
    gf = fx[1]
    on = sorted([r for r in block if r['Club'] == club and num(r['Mins']) > 0], key=lambda r: (-num(r['xG']), r['Code']))
    for i in range(int(gf)):
        if not on: break
        s = on[i % len(on)]; s['G'] = num(s['G']) + 1; s['_pts'] += GOAL[s['Pos']]
        a = on[(i + 1) % len(on)]
        if a is not s: a['A'] = num(a['A']) + 1; a['_pts'] += 3
for r in block:
    r['Pts'] = r.pop('_pts')
    r['BPS'] = int(3 * r['Pts'] + num(r['Mins']) / 10 + round(6 * h01('bps', r['Code']))) if num(r['Mins']) > 0 else 0
    r['DefCon'] = int(round(12 * h01('dc', r['Code']) * num(r['Mins']) / 90)) if r['Pos'] in ('DEF', 'MID') else 0
    r['Bonus'] = 0
save('GW Stats', d, gcols, gws + block)
gw6 = {r['Code']: r for r in block}

# ---- Rosters: lineups published at the deadline, live points
d, rcols, ro = load('Rosters')
order = {'GKP': 0, 'DEF': 1, 'MID': 2, 'FWD': 3}
for team in sorted(set(r['Team'] for r in ro)):
    sq = [r for r in ro if r['Team'] == team]
    xi = sorted([r for r in sq if r['Best XI'] == 'XI'], key=lambda r: (order[r['Pos']], -num(r['Proj pts'])))
    bench = sorted([r for r in sq if r['Best XI'] != 'XI'], key=lambda r: (r['Pos'] != 'GKP', -num(r['Proj pts'])))
    for i, r in enumerate(xi): r['GW XI'] = 'XI'; r['Slot'] = str(i + 1)
    for i, r in enumerate(bench): r['GW XI'] = 'BEN'; r['Slot'] = str(12 + i)
for r in ro:
    g = gw6.get(r['Code'])
    r['GW pts'] = str(int(g['Pts'])) if g else '0'
    r['GW mins'] = str(int(num(g['Mins']))) if g else '0'
    r['Season pts'] = str(int(num(r['Season pts']) + (g['Pts'] if g else 0)))
save('Rosters', d, rcols, ro)

# ---- H2H GW6: FPL live totals
d, hcols, h2h = load('H2H Fixtures')
xi_pts = {}
for r in ro:
    if r['GW XI'] == 'XI': xi_pts[r['Team']] = xi_pts.get(r['Team'], 0) + int(num(r['GW pts']))
for f in h2h:
    if num(f['GW']) == GW:
        f['Home pts'] = str(xi_pts.get(f['Home'], 0)); f['Away pts'] = str(xi_pts.get(f['Away'], 0))
save('H2H Fixtures', d, hcols, h2h)

# ---- Players: season totals include GW6 so far
d, pcols, plr2 = load('Players')
for p in plr2:
    g = gw6.get(p['Code'])
    if g: p['Season pts'] = str(int(num(p['Season pts']) + g['Pts'])); p['Mins'] = str(int(num(p['Mins']) + num(g['Mins'])))
save('Players', d, pcols, plr2)

# ---- Predictions: GW7 block captured after the GW6 deadline (EP next from the Players tab)
d, qcols, pred = load('Predictions')
ep_next = {p['Code']: p.get('EP next') for p in plr}
g7 = [dict(r, **{'GW': '7', 'EP': ep_next.get(r['Code'], r['EP']), 'Captured (UTC)': '2026-10-10T14:55:00.000Z'}) for r in pred if num(r['GW']) == 6]
save('Predictions', d, qcols, pred + g7)

print('wrote', OUT, '| GW6 rows', len(block), '| on the pitch', sum(1 for r in block if num(r['Mins']) > 0),
      '| H2H live', {f['Home'] + ' v ' + f['Away']: (f['Home pts'], f['Away pts']) for f in h2h if num(f['GW']) == GW})
