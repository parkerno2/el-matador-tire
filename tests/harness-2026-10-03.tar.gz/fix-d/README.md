# fix-d: engine correctness (agent D)

Owned: #24 (live-GW odds shrink banked points), TP-14 (unseeded odds jitter), #8 (autoSubs blank GW, provisional bonus per fixture in a DGW), #6 (Predictions fallback shown as this GW's).

## Live-replay fixture: `tabs-live/`

The real sheet export of 3 Oct (`/home/claude/harness/tabs`) edited to look like **Saturday 10 Oct 2026, 15:00 UTC, GW6 in play**. Rebuild it with:

```
python3 /home/claude/harness/fix-d/make_tabs_live.py            # SRC=harness/tabs  OUT=fix-d/tabs-live
```

It is deterministic (same input, same output). Open it with:

```python
import sys; sys.path.insert(0, '/home/claude/harness')
from harness import App
with App(now='2026-10-10T15:00:00Z', tabs='/home/claude/harness/fix-d/tabs-live') as app:
    p = app.open('v12.html')          # header pill reads "GW6 · LIVE"
```

What the script changes (everything else is the real export):

| Tab | Edit |
|---|---|
| Matchweeks | none. GW6 deadline is already Sat 10 Oct 10:00 UTC with Finished FALSE; `now=15:00` puts the deadline in the past |
| Club Fixtures | GW6 ARS 2-0 LEE (11:30) full time (Started TRUE, Finished TRUE, Mins 90). AVL 1-1 BRE, CHE 1-0 BOU, IPS 0-0 FUL, SUN 0-2 BHA (14:00) live at 55' (Started TRUE, Finished FALSE, Mins 55). MUN-TOT and the Sunday/Monday games untouched (not started) |
| GW Stats | a GW6 block (Final FALSE) for all 667 players. Players at started clubs who started GW5 (and are status `a`) start GW6: 90 or 55 minutes; GW5 cameo players get 20 minutes in the finished game. Points = appearance, clean sheet (60+ min, nothing conceded), goals-conceded penalty, and the fixture's goals/assists given to the club's highest-xG players on the pitch. BPS from points + minutes; **Bonus 0 everywhere**, so ARS-LEE exercises provisional bonus. 147 players on the pitch |
| Rosters | lineups published at the deadline: `GW XI`/`Slot` from each team's Best XI (XI slots 1-11 ordered GKP, DEF, MID, FWD; bench GK first then by Proj pts). `GW pts`/`GW mins` from the GW6 block; `Season pts` includes them |
| H2H Fixtures | GW6 Home/Away pts = FPL's live totals (sum of XI GW pts, no provisional bonus): Palmers 13-7 Devils, Baleba 2-14 Gulls, Mainoo 21-17 Trophy, McGinn 6-8 Jacob |
| Players | Season pts and Mins include GW6 so far |
| Predictions | a GW7 block (EP next), as Code.gs captures the next GW once GW6's deadline passes |

## Tests

- `fplgg/tools/v12/test-engines.js` (in the repo): node, no browser. Loads the built page's inline scripts into a vm context (stub DOM, fake clock), serves synthetic leagues through the page's own `readTab`. 34 checks. `test-before.txt` = the pre-fix build (11 fail), `test-after.txt` = this branch (34 pass).
  - `node fplgg/tools/v12/test-engines.js [page.html]`
  - real data: `node fplgg/tools/v12/test-engines.js --tabs /home/claude/harness/tabs --compare /home/claude/harness/fix-d/base-root/v12.html` (`test-realdata.txt`)
  - live replay: `node fplgg/tools/v12/test-engines.js --tabs /home/claude/harness/fix-d/tabs-live --now 2026-10-10T15:00:00Z` (`test-live-replay.txt`)
- `e2e.py` (Playwright harness): `diff <tabs> <now>` compares the visible text of all five tabs, a matchup, a player sheet and a team sheet between the pre-fix build (`base-root/`, built from 9ca3b21 sources) and wt-d (`e2e-diff-real.txt`); `live` runs the live replay on both builds (`e2e-live.txt`, `shots/live-*`); `smoke <tabs> <now> <tag>` takes 390/320 screenshots (`shots/real-*`, `shots/live-*-390|320-*`).
