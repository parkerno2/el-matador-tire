process.argv.push('/home/claude/harness/fix-d/base-root/v12.html');
