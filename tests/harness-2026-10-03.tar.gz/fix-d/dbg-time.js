const path='/home/claude/wt-d/fplgg/tools/v12/test-engines.js';
const src=require('fs').readFileSync(path,'utf8').replace(/main\(\)\.catch[\s\S]*$/,'module.exports={openPage,league,makeEnv};');
const m=new module.constructor();m.paths=module.paths;m._compile(src,path);
(async()=>{let t=Date.now();const E=await m.exports.openPage(process.argv[2],{},'2026-10-03T21:00:00Z');console.log('empty open',Date.now()-t);
const TEAMS=E.ev('Object.keys(TEAMS)');t=Date.now();const L=m.exports.league(TEAMS,{});console.log('league gen',Date.now()-t);
t=Date.now();const E2=await m.exports.openPage(process.argv[2],L.tabs,'2026-10-03T21:00:00Z');console.log('open synthetic',Date.now()-t, E2.ev('D.ro.length'), E2.errors.length);
t=Date.now();E2.ev('(()=>{D.pbonus=Object.assign({},D.pbonus);return simulate()})()');console.log('sim',Date.now()-t);
})();
