import sys, os
sys.path.insert(0, '/home/claude/harness')
from harness import App
S = '/home/claude/harness/fix-a/shots/smoke'; os.makedirs(S, exist_ok=True)
for w, h in ((390, 844), (320, 640)):
    with App(width=w, height=h) as app:
        bad = []
        p = app.ctx.new_page()
        p.on('pageerror', lambda e: app.errors.append('pageerror: ' + str(e)))
        p.on('console', lambda m: m.type == 'error' and app.errors.append('console: ' + m.text))
        p.on('response', lambda r: r.status >= 400 and 'faces/' not in r.url and bad.append((r.status, r.url)))
        p.goto('https://parkerno2.github.io/el-matador-tire/v12.html', wait_until='load')
        p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0"); p.wait_for_timeout(700)
        def ov(tag):
            o = p.evaluate("()=>{const W=document.documentElement.clientWidth;return {sw:document.documentElement.scrollWidth,W, over:[...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.right>W+1&&getComputedStyle(e).position!=='fixed'}).slice(0,4).map(e=>e.tagName+'.'+String(e.className).slice(0,30))}}")
            if o['sw'] > o['W'] or o['over']: print(f'  [{w}] {tag}: scrollWidth {o["sw"]}/{o["W"]} overflow {o["over"]}')
        for tab in ('gw', 'team', 'table', 'xis', 'ana'):
            if tab == 'team': p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers')")
            p.evaluate(f"location.hash='{tab}'"); p.wait_for_timeout(600)
            on = p.evaluate("[...document.querySelectorAll('nav [data-v].on')].map(b=>b.dataset.v)")
            assert on == [tab], (tab, on)
            p.screenshot(path=f'{S}/{w}-{tab}.png', full_page=True); ov(tab)
        p.evaluate("location.hash='gw'"); p.wait_for_timeout(400)
        p.get_by_role('button', name='Derbies').click(); p.wait_for_timeout(400); p.screenshot(path=f'{S}/{w}-derbies.png', full_page=True); ov('derbies')
        p.evaluate("GWTAB='week';location.hash='gw/0'"); p.wait_for_timeout(600); p.screenshot(path=f'{S}/{w}-match0.png', full_page=True); ov('match0')
        p.evaluate("document.querySelector('#gwbody [data-om=\"1\"]').click()"); p.wait_for_timeout(300); ov('match0-fixture')
        p.evaluate("document.querySelector('#gwbody [data-om=\"0\"]').click()"); p.wait_for_timeout(300)
        p.evaluate("document.querySelector('#gwbody .fc[data-i]').click()"); p.wait_for_timeout(500); p.screenshot(path=f'{S}/{w}-player-sheet.png'); ov('player sheet')
        p.keyboard.press('Escape'); p.wait_for_timeout(400)
        assert not p.evaluate("document.getElementById('sheet').classList.contains('on')"), 'sheet still open after Esc'
        p.evaluate("location.hash='table'"); p.wait_for_timeout(400)
        p.evaluate("document.querySelector('#tablebody .trow[data-prof]').click()"); p.wait_for_timeout(600); p.screenshot(path=f'{S}/{w}-team-sheet.png'); ov('team sheet')
        p.evaluate("document.getElementById('sheet').scrollTop=600"); p.wait_for_timeout(200); p.screenshot(path=f'{S}/{w}-team-sheet-mid.png')
        p.evaluate("document.querySelector('#sheet [data-om=\"1\"]').click()"); p.wait_for_timeout(300)
        p.evaluate("document.querySelector('#sheet .fc[data-i]').click()"); p.wait_for_timeout(500)
        p.go_back(); p.wait_for_timeout(500)
        assert p.evaluate("document.getElementById('sheet').classList.contains('on')&&!!document.querySelector('#sheet .lkTH')"), 'back from nested player did not return to the team sheet'
        p.evaluate("closeSheet()"); p.wait_for_timeout(400)
        p.evaluate("location.hash='team'"); p.wait_for_timeout(500); p.screenshot(path=f'{S}/{w}-myteam.png', full_page=True); ov('my team')
        p.evaluate("document.getElementById('hfaq').click()"); p.wait_for_timeout(400); p.screenshot(path=f'{S}/{w}-faq.png'); ov('faq')
        nh = p.evaluate("document.getElementById('nav').getBoundingClientRect().height")
        p.evaluate("document.getElementById('faqback').click()"); p.wait_for_timeout(400)
        assert p.evaluate('location.hash') == '#team', p.evaluate('location.hash')
        p.evaluate("location.hash='gw'"); p.wait_for_timeout(400)
        if p.evaluate("!!document.querySelector('[data-mxall]')"):
            p.evaluate("document.querySelector('[data-mxall]').click()"); p.wait_for_timeout(800)
            assert p.evaluate("!!document.getElementById('lgfx')")
            p.go_back(); p.wait_for_timeout(500)
            assert p.evaluate("!document.getElementById('lgfx')") and p.evaluate('location.hash') == '#gw', ('mxall back', p.evaluate('location.hash'))
        else:
            # no preview this gameweek: play every matchup from the matchup page instead
            p.evaluate("location.hash='gw/1'"); p.wait_for_timeout(500)
            p.evaluate("document.querySelector('[data-mx]').click()"); p.wait_for_timeout(600)
            p.evaluate("document.getElementById('lgcl').click()"); p.wait_for_timeout(400)
            assert p.evaluate("!document.getElementById('lgfx')") and p.evaluate('location.hash') == '#gw/1', ('close keeps page', p.evaluate('location.hash'))
            p.go_back(); p.wait_for_timeout(500)
            assert p.evaluate('location.hash') == '#gw', ('one back after Close leaves the matchup', p.evaluate('location.hash'))
        print(f'[{w}] nav height on FAQ {nh}; errors:', app.errors, '4xx:', bad)
print('smoke done')
