import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
for w,h in ((1280,800),(768,1024)):
  with App(width=w,height=h) as app:
    p=app.open('v12.html')
    print(w, p.evaluate("[...document.querySelectorAll('nav [data-v].on')].map(b=>b.dataset.v)"), p.evaluate("document.getElementById('nav').getBoundingClientRect().height"))
    p.evaluate("document.getElementById('hfaq').click()"); p.wait_for_timeout(400)
    print(w,'faq nav h', p.evaluate("document.getElementById('nav').getBoundingClientRect().height"), p.evaluate("document.getElementById('faqback').textContent"))
    p.screenshot(path=f'shots/after-{w}-faq.png')
    p.evaluate("document.getElementById('faqback').click()"); p.wait_for_timeout(400)
    print(w, p.evaluate('location.hash'))
    p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers');location.hash='team'"); p.wait_for_timeout(600)
    p.screenshot(path=f'shots/after-{w}-team.png')
    print([e for e in app.errors if 'faces' not in e][:3])
