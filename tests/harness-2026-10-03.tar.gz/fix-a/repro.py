"""Agent A repro: one check per owned finding. Run before and after the fix.
   EMT_ROOT=/home/claude/wt-a python3 /home/claude/harness/fix-a/repro.py [before|after]"""
import sys, os, time, json
sys.path.insert(0, '/home/claude/harness')
from harness import App
TAG = sys.argv[1] if len(sys.argv) > 1 else 'run'
SHOTS = '/home/claude/harness/fix-a/shots'
os.makedirs(SHOTS, exist_ok=True)
R = {}
def res(k, ok, note=''):
    R[k] = (bool(ok), note); print(('PASS ' if ok else 'FAIL ') + k + (' · ' + str(note) if note != '' else ''))
def shot(p, name): p.screenshot(path=f'{SHOTS}/{TAG}-{name}.png')

def nav_state(p):
    return p.evaluate("""()=>{const on=[...document.querySelectorAll('nav [data-v].on')].map(b=>b.dataset.v);
      return {on, h:document.getElementById('nav').getBoundingClientRect().height}}""")

# ---------------- 390 main run ----------------
with App(width=390, height=844) as app:
    p = app.open('v12.html')
    # LG-01 / TP-5: cold load highlights a tab, and the bar height does not jump on the first tap
    s0 = nav_state(p)
    p.get_by_role('button', name='Table').last.click(); p.wait_for_timeout(300)
    s1 = nav_state(p)
    res('LG-01 cold load active tab', s0['on'] == ['gw'], s0)
    res('LG-01 nav height stable', abs(s0['h'] - s1['h']) < 0.5, (s0['h'], s1['h']))
    shot(p, 'LG01-table')
    # TP-3: MOTM card shows its note
    motm = p.evaluate("""()=>{const c=document.querySelector('#tablebody .card.race');if(!c)return null;const n=c.querySelector('.mnote');
      return {txt:c.textContent.trim().slice(0,80), note: n?getComputedStyle(n).display:'none', standnote:[...document.querySelectorAll('#tablebody .card:not(.race)>.mnote')].map(x=>getComputedStyle(x).display)}}""")
    res('TP-3 MOTM note visible', motm and motm['note'] != 'none', motm)
    res('TP-3 standings odds note still hidden', motm and all(d == 'none' for d in motm['standnote']), motm and motm['standnote'])
    shot(p, 'TP3-motm')
    # TP-16: How it works has a way back
    p.evaluate("document.getElementById('hfaq').click()"); p.wait_for_timeout(300)
    fb = p.evaluate("()=>{const b=document.getElementById('faqback');return b?{t:b.textContent.trim(),h:b.getBoundingClientRect().height}:null}")
    res('TP-16 FAQ has back control', fb is not None, fb)
    if fb:
        p.evaluate("document.getElementById('faqback').click()"); p.wait_for_timeout(400)
        res('TP-16 back returns to Table', p.evaluate('location.hash') == '#table' and p.evaluate("document.body.dataset.view") == 'table', p.evaluate('location.hash'))
        res('TP-16 back control tall enough', fb['h'] >= 36, fb['h'])
    shot(p, 'TP16-faq')
    # T10: manager sheet shows the manager photo when there is one (Cold Palmers has a photo in the Managers tab)
    p.evaluate("location.hash='table'"); p.wait_for_timeout(300)
    has_photo = p.evaluate("()=>!!(PROFILE['Cold Palmers']&&PROFILE['Cold Palmers'].photo)")
    p.evaluate("openProfile('Cold Palmers')"); p.wait_for_timeout(400)
    img = p.evaluate("()=>{const i=document.querySelector('#sheet .lkTH .lkcr img');return i?{w:i.getBoundingClientRect().width,src:i.getAttribute('src').slice(0,20)}:null}")
    res('T10 manager sheet shows photo', (not has_photo) or (img and img['w'] > 40), {'profile_photo': has_photo, 'img': img})
    # LG-25 / T3: legend swatches use FDRCOL
    leg = p.evaluate("""()=>[...document.querySelectorAll('#sheet .fleg span')].map(s=>s.style.background.toLowerCase())""")
    res('LG-25 legend swatches = FDRCOL', leg and 'rgb(1, 252, 122)' not in leg and 'rgb(255, 23, 81)' not in leg and len(leg) == 4, leg)
    # T2: heading is a plain heading (no onclick, no chevron, grid present, cursor default)
    t2 = p.evaluate("""()=>{const fh=document.querySelector('#sheet #fixh');if(!fh)return null;const fx=fh.closest('.fixt');
      return {onclick:!!fh.onclick, chev:!!fh.querySelector('svg'), rows:fx.querySelectorAll('.fr').length, cursor:getComputedStyle(fh).cursor, txt:fh.textContent.trim()}}""")
    res('T2 heading has no toggle', t2 and not t2['onclick'] and not t2['chev'] and t2['rows'] > 0 and t2['cursor'] != 'pointer', t2)
    if t2:
        p.evaluate("document.querySelector('#sheet #fixh').click()"); p.wait_for_timeout(300)
        rows_after = p.evaluate("()=>document.querySelectorAll('#sheet .fixt .fr').length")
        res('T2 tap does not collapse', rows_after == t2['rows'], (t2['rows'], rows_after))
    # T4: the grid covers the whole squad's clubs
    t4 = p.evaluate("""()=>{const sq=[...new Set(squadOf('Cold Palmers').map(p=>p.Club))];const rows=document.querySelectorAll('#sheet .fixt .fr').length;return {clubs:sq.length,rows}}""")
    res('T4 grid covers the squad clubs', t4['rows'] == t4['clubs'], t4)
    # T14: Points/Fixture toggle in the sheet keeps the scroll position
    p.evaluate("document.getElementById('sheet').scrollTop=700"); p.wait_for_timeout(100)
    y0 = p.evaluate("document.getElementById('sheet').scrollTop")
    t0 = time.time(); p.evaluate("document.querySelector('#sheet [data-om=\"1\"]').click()"); p.wait_for_timeout(250)
    y1 = p.evaluate("document.getElementById('sheet').scrollTop")
    opp = p.evaluate("document.querySelectorAll('#sheet .fc .pts.opp').length")
    res('T14 sheet toggle keeps scroll', abs(y0 - y1) <= 2 and opp > 0, (y0, y1, opp))
    on_btn = p.evaluate("document.querySelector('#sheet .axtog.om button.on').dataset.om")
    res('T14 sheet toggle state', on_btn == '1', on_btn)
    p.evaluate("document.querySelector('#sheet [data-om=\"0\"]').click()"); p.wait_for_timeout(200)
    shot(p, 'T14-sheet')
    p.evaluate("closeSheet()"); p.wait_for_timeout(400)
    # LG-24 / TP-12: percentile bars one purple scale
    p.evaluate("openSheet(D.ro.find(r=>/Haaland/.test(r.Player)))"); p.wait_for_timeout(400)
    bars = p.evaluate("()=>[...document.querySelectorAll('#sheet .statgrid.lg .bar i')].map(i=>i.style.background.toLowerCase())")
    bad = [b for b in bars if b in ('rgb(25, 210, 122)', 'rgb(245, 185, 66)', 'rgb(229, 72, 77)')]
    res('LG-24 percentile bars purple', bars and not bad, bars)
    shot(p, 'LG24-haaland')
    p.evaluate("closeSheet()"); p.wait_for_timeout(400)
    # MD-02: derby score order matches the column order
    p.evaluate("location.hash='gw'"); p.wait_for_timeout(300)
    p.get_by_role('button', name='Derbies').click(); p.wait_for_timeout(400)
    md2 = p.evaluate("""()=>{const out=[];document.querySelectorAll('.dcard').forEach(c=>{const l=c.querySelector('.ds.l b').textContent.trim(),r=c.querySelector('.ds.r b').textContent.trim();
      const dm=c.querySelector('.dm').textContent;const m=/Last · GW(\\d+) · (\\d+)–(\\d+)/.exec(dm);if(!m)return;
      const f=D.fx.find(x=>num(x.GW)===+m[1]&&((x.Home===l&&x.Away===r)||(x.Home===r&&x.Away===l)));
      const lp=f.Home===l?num(f['Home pts']):num(f['Away pts']);out.push({k:c.querySelector('.dk').textContent.trim(),l,r,shown:+m[2],leftScored:lp,ok:+m[2]===lp});});return out}""")
    res('MD-02 last result reads left-to-right', md2 and all(x['ok'] for x in md2), [x for x in md2 if not x['ok']][:3])
    tw = p.evaluate("""()=>{const out=[];document.querySelectorAll('.dcard.live').forEach(c=>{const l=c.querySelector('.ds.l b').textContent.trim();const dm=c.querySelector('.dm').textContent;
      const m=/This week · (\\S+) ([\\d.]+) – ([\\d.]+) (\\S+)/.exec(dm);if(!m)return;out.push({l,first:m[1],ok:m[1]===FIRSTOF(l)});});return out}""")
    res('MD-02 this-week line reads left-to-right', tw and all(x['ok'] for x in tw), tw)
    # MD-22: series pill does not break inside the brackets
    md22 = p.evaluate("""()=>[...document.querySelectorAll('.dcard .dsr b')].filter(b=>/\\(/.test(b.textContent)).map(b=>{const t=b.textContent;
      const r=document.createRange();const i=t.indexOf('(');const n=b.childNodes;let node=null,off=0;for(const x of n){if(x.nodeType===3&&x.textContent.includes('('))node=x;}
      const sp=b.querySelector('span');const rect=sp?sp.getBoundingClientRect():null;const lines=sp?Math.round(rect.height/parseFloat(getComputedStyle(sp).lineHeight)):null;
      return {t,bracketLines:lines,hasSpan:!!sp}})""")
    res('MD-22 bracket part stays on one line', md22 and all(x['hasSpan'] and x['bracketLines'] == 1 for x in md22), md22)
    shot(p, 'MD22-derbies')
    # MD-15: derby card Enter opens the matchup
    p.evaluate("document.querySelector('.dcard[data-mi]').focus()")
    p.keyboard.press('Enter'); p.wait_for_timeout(400)
    res('MD-15 Enter on derby card opens matchup', p.evaluate('location.hash').startswith('#gw/'), p.evaluate('location.hash'))
    p.evaluate("GWTAB='week'")
    # MD-06: Esc and back close the matchup graphic
    p.evaluate("location.hash='gw/0'"); p.wait_for_timeout(500)
    p.evaluate("document.querySelector('[data-mx]').click()"); p.wait_for_timeout(600)
    res('MD-06 graphic opened', p.evaluate("!!document.getElementById('lgfx')"))
    p.keyboard.press('Escape'); p.wait_for_timeout(300)
    res('MD-06 Esc closes graphic', p.evaluate("!document.getElementById('lgfx')"))
    res('MD-06 Esc keeps the matchup page', p.evaluate('location.hash') == '#gw/0', p.evaluate('location.hash'))
    p.evaluate("document.querySelector('[data-mx]').click()"); p.wait_for_timeout(600)
    p.go_back(); p.wait_for_timeout(500)
    res('MD-06 back closes graphic', p.evaluate("!document.getElementById('lgfx')"))
    res('MD-06 back keeps the matchup page', p.evaluate('location.hash') == '#gw/0', p.evaluate('location.hash'))
    # MD-12: the final scene says Projected, never Predicted
    p.evaluate("const g=document.getElementById('lgfx');if(g)g.remove();location.hash='gw/0'"); p.wait_for_timeout(500)
    p.evaluate("document.querySelector('[data-mx]').click()"); p.wait_for_timeout(500)
    p.evaluate("document.querySelector('#lgfx .mxbody').click()"); p.wait_for_timeout(400)
    txt = p.evaluate("()=>{const g=document.getElementById('lgfx');return g?g.textContent:''}")
    res('MD-12 no "Predicted" in the graphic', 'Predicted' not in txt and 'PREDICTED' not in txt)
    vs = p.evaluate("()=>{const v=document.querySelector('#lgfx .vsbug');return v?v.textContent.trim():''}")
    res('MD-12 vsbug one word', vs.count('Projected') == 1 and 'Predicted' not in vs, vs)
    shot(p, 'MD12-final')
    p.keyboard.press('Escape'); p.wait_for_timeout(300)
    p.evaluate("document.getElementById('lgfx')&&document.getElementById('lgfx').remove()")
    # MD-07: busy refresh is not gold
    busy = p.evaluate("""()=>{const b=document.getElementById('hrefresh');b.classList.add('busy');const cs=getComputedStyle(b);const r={bg:cs.backgroundColor,bd:cs.borderColor,c:cs.color};b.classList.remove('busy');return r}""")
    res('MD-07 busy state not gold', '255, 210, 63' not in busy['bg'] and '255, 210, 63' not in busy['bd'], busy)
    # T1: My team "Watch the lineup" closes on Esc and on back, staying on My team
    p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers');location.hash='team'"); p.wait_for_timeout(600)
    p.evaluate("document.querySelector('[data-watch]').click()"); p.wait_for_timeout(500)
    res('T1 lineup opened', p.evaluate("!!document.getElementById('lgfx')"))
    p.keyboard.press('Escape'); p.wait_for_timeout(300)
    res('T1 Esc closes lineup', p.evaluate("!document.getElementById('lgfx')"))
    p.evaluate("document.querySelector('[data-watch]').click()"); p.wait_for_timeout(500)
    p.go_back(); p.wait_for_timeout(500)
    res('T1 back closes lineup', p.evaluate("!document.getElementById('lgfx')"))
    res('T1 back stays on My team', p.evaluate('location.hash') == '#team', p.evaluate('location.hash'))
    p.evaluate("const g=document.getElementById('lgfx');if(g)g.remove();location.hash='team'"); p.wait_for_timeout(500)
    # T14 page: toggle keeps scroll
    p.evaluate("window.scrollTo(0,600)"); p.wait_for_timeout(150)
    y0 = p.evaluate('scrollY')
    p.evaluate("document.querySelector('#teampage [data-om=\"1\"]').click()"); p.wait_for_timeout(250)
    y1 = p.evaluate('scrollY'); opp = p.evaluate("document.querySelectorAll('#teampage .fc .pts.opp').length")
    res('T14 page toggle keeps scroll', abs(y0 - y1) <= 2 and opp > 0, (y0, y1, opp))
    tg = p.evaluate("()=>{const t=document.querySelector('#teampage .teamtag2 span');return t?t.textContent:''}")
    res('T14 page teamtag stays tidy', tg and 'Cold Palmers' not in tg and 'projected' not in tg, tg)
    p.evaluate("document.querySelector('#teampage [data-om=\"0\"]').click()"); p.wait_for_timeout(200)
    # T12: signed-in picker
    p.evaluate("localStorage.setItem('emt-auth',JSON.stringify({team:'Cold Palmers',token:'x'}));localStorage.removeItem('emt-myteam');renderTeam()"); p.wait_for_timeout(400)
    lbl = p.evaluate("()=>{const b=document.querySelector('#teambody [data-claim]');return b?b.textContent.trim():null}")
    note = p.evaluate("()=>{const n=document.querySelector('#teambody .claimnote');return n?n.textContent.trim():null}")
    p.evaluate("document.querySelector('#teambody [data-claim]').click()"); p.wait_for_timeout(400)
    title = p.evaluate("()=>{const h=document.querySelector('#sheet h3');return h?h.textContent.trim():''}")
    res('T12 picker button matches what opens', (lbl == 'Edit team' and title == 'Edit team') or (lbl == 'Claim your team' and title != 'Edit team'), (lbl, title, note))
    res('T12 picker says you are signed in', note and 'Cold Palmers' in note, note)
    shot(p, 'T12-picker')
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    p.evaluate("localStorage.removeItem('emt-auth')")
    # T9: PIN masked
    p.evaluate("openClaim()"); p.wait_for_timeout(300)
    pin = p.evaluate("()=>{const i=document.getElementById('au-pin');return i?{type:i.type,im:i.getAttribute('inputmode'),sec:getComputedStyle(i).webkitTextSecurity}:null}")
    res('T9 PIN masked, numeric', pin and pin['im'] == 'numeric' and (pin['type'] == 'password' or pin['sec'] == 'disc'), pin)
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    # MD-18: no show/gwN.json fetch when no preview exists for the gameweek
    shows = [u for u in app.requests if '/show/gw' in u]
    res('MD-18 no show/gw6.json request', not shows, shows)
    errs = [e for e in app.errors if 'faces/' not in e]
    res('console clean (390 run)', not errs, errs[:5])

# ---------------- #23 refresh fallthrough ----------------
with App(width=390, height=844, api=lambda req: {'ok': False, 'error': 'unknown action'}) as app:
    p = app.open('v12.html')
    n0 = len([u for u in app.requests if 'gviz' in u])
    p.evaluate("document.getElementById('hrefresh').click()"); p.wait_for_timeout(2500)
    n1 = len([u for u in app.requests if 'gviz' in u])
    toast = p.evaluate("document.getElementById('ptr').textContent")
    res('#23 unhelpful reply re-reads the sheet', n1 > n0, (n0, n1, toast))
    res('#23 toast says last update', 'last update' in toast, toast)

# ---------------- MD-05 deadline flip ----------------
with App(width=390, height=844, now='2026-10-10T09:59:52Z') as app:
    p = app.open('v12.html')
    pill0 = p.evaluate("document.getElementById('gwpill').textContent")
    p.wait_for_timeout(11000)
    pill1 = p.evaluate("document.getElementById('gwpill').textContent")
    live = p.evaluate("document.getElementById('gwpill').classList.contains('live')")
    hdr = p.evaluate("()=>{const h=[...document.querySelectorAll('#gwbody h2.v10')].map(x=>x.textContent.trim());return h.slice(0,2)}")
    res('MD-05 pill never reads 0m', '0m' not in pill0, pill0)
    res('MD-05 header flips at the deadline', 'LIVE' in pill1 and live, (pill0, pill1, hdr))
    shot(p, 'MD05-after')

# ---------------- 320 checks ----------------
with App(width=320, height=640) as app:
    p = app.open('v12.html')
    p.evaluate("openSheet(D.ro.find(r=>/Rice/.test(r.Player)))"); p.wait_for_timeout(500)
    tp9 = p.evaluate("()=>{const w=document.querySelector('#sheet .hist .hwrap'),t=w&&w.querySelector('table');if(!t)return null;return {ww:w.clientWidth,tw:t.scrollWidth,ov:t.scrollWidth-w.clientWidth}}")
    res('TP-9 season table fits at 320', tp9 and tp9['ov'] <= 0, tp9)
    shot(p, 'TP9-rice-320')
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    p.evaluate("openSheet(plrPseudo(D.plr.find(r=>/Gro/.test(r.Player)&&r.Club==='BHA')))"); p.wait_for_timeout(500)
    tp18 = p.evaluate("""()=>{const m=document.querySelector('#sheet .fxblk .fxmain');if(!m)return null;const [h,c,a]=[...m.children].map(x=>x.getBoundingClientRect());
      const tr=el=>{const r=document.createRange();r.selectNodeContents(el);return r.getBoundingClientRect()};
      const hb=tr(m.querySelector('.fxs.h b')),ab=tr(m.querySelector('.fxs.a b'));const ko=m.querySelector('.ko');const kr=ko?tr(ko):c;
      return {gapL:Math.round(kr.left-hb.right),gapR:Math.round(ab.left-kr.right),h:m.querySelector('.fxs.h b').textContent,a:m.querySelector('.fxs.a b').textContent,koLines:Math.round(kr.height/parseFloat(getComputedStyle(ko).lineHeight))}}""")
    res('TP-18 club names clear the kickoff', tp18 and tp18['gapL'] >= 6 and tp18['gapR'] >= 6, tp18)
    shot(p, 'TP18-gross-320')
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    errs = [e for e in app.errors if 'faces/' not in e]
    res('console clean (320 run)', not errs, errs[:5])

# ---------------- LG-28 desktop rail ----------------
with App(width=1280, height=800) as app:
    p = app.open('v12.html')
    rail = p.evaluate("""()=>{const bs=[...document.querySelectorAll('nav [data-v]')];const xs=bs.map(b=>Math.round(b.querySelector('svg').getBoundingClientRect().left));
      const lx=bs.map(b=>Math.round(b.querySelector('span:not(.bar)').getBoundingClientRect().left));
      const top=document.querySelector('.top').getBoundingClientRect();const nav=document.getElementById('nav');
      const el=document.elementFromPoint(20,Math.round(top.height/2));
      return {iconX:xs,labelX:lx,topLeft:Math.round(top.left),under:el?el.className||el.tagName:null,navBg:getComputedStyle(nav).backgroundColor}}""")
    p.get_by_role('button', name='Table').last.click(); p.wait_for_timeout(300)
    rail2 = p.evaluate("()=>[...document.querySelectorAll('nav [data-v]')].map(b=>Math.round(b.querySelector('span:not(.bar)').getBoundingClientRect().left))")
    res('LG-28 icons in one column', len(set(rail['iconX'])) == 1, rail['iconX'])
    res('LG-28 labels in one column, no shift when active', len(set(rail['labelX'])) == 1 and rail['labelX'] == rail2, (rail['labelX'], rail2))
    res('LG-28 header spans the rail corner', rail['topLeft'] == 0, rail)
    shot(p, 'LG28-desktop')
    errs = [e for e in app.errors if 'faces/' not in e]
    res('console clean (1280 run)', not errs, errs[:5])

print('\n== %s: %d pass / %d fail ==' % (TAG, sum(1 for v in R.values() if v[0]), sum(1 for v in R.values() if not v[0])))
json.dump({k: v for k, v in R.items()}, open(f'/home/claude/harness/fix-a/{TAG}.json', 'w'), indent=1, default=str)
