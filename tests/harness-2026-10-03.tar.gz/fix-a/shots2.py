import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    p.get_by_role('button', name='Derbies').click(); p.wait_for_timeout(400)
    el=p.locator('.dcard', has_text='ROONEY TOONS').first
    el.screenshot(path='shots/after-MD22-rooney.png')
    p.locator('.dcard', has_text='CLÁSICO').first.screenshot(path='shots/after-MD02-clasico.png')
    p.evaluate("location.hash='table'"); p.wait_for_timeout(300)
    p.evaluate("document.getElementById('hfaq').click()"); p.wait_for_timeout(400)
    p.screenshot(path='shots/after-TP16-faqtop.png')
    p.evaluate("location.hash='gw/0'"); p.wait_for_timeout(500)
    p.evaluate("document.querySelector('[data-mx]').click()"); p.wait_for_timeout(500)
    p.evaluate("document.querySelector('#lgfx .mxbody').click()"); p.wait_for_timeout(600)
    p.screenshot(path='shots/after-MD12-final2.png')
    p.keyboard.press('Escape'); p.wait_for_timeout(300)
    # busy state
    p.evaluate("document.getElementById('hrefresh').classList.add('busy')"); p.wait_for_timeout(100)
    p.locator('.top').screenshot(path='shots/after-MD07-busy.png')
    p.evaluate("document.getElementById('hrefresh').classList.remove('busy')")
    print(app.errors)
