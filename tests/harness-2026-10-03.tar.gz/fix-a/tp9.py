import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
for w in (320,390):
  with App(width=w,height=640) as app:
    p=app.open('v12.html')
    for q in ["/Rice/.test(r.Player)","/Haaland/.test(r.Player)","/Raya/.test(r.Player)"]:
        p.evaluate("openSheet(D.ro.find(r=>%s))"%q); p.wait_for_timeout(400)
        print(w, p.evaluate("""()=>{const w=document.querySelector('#sheet .hist .hwrap'),t=w&&w.querySelector('table');if(!t)return null;
          const tds=[...t.querySelectorAll('tbody tr:first-child td')].map(x=>Math.round(x.getBoundingClientRect().width));
          return {ww:w.clientWidth,tw:t.scrollWidth,tds,opp:t.querySelector('td.opp').textContent.trim().slice(0,30)}}"""))
        p.evaluate("closeSheet()"); p.wait_for_timeout(250)
    if w==320: p.evaluate("openSheet(D.ro.find(r=>/Rice/.test(r.Player)))"); p.wait_for_timeout(400); p.evaluate("document.getElementById('sheet').scrollTop=99999"); p.wait_for_timeout(300); p.screenshot(path='/home/claude/harness/fix-a/shots/tp9-320-probe.png')
