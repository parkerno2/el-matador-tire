import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=320,height=640) as app:
    p=app.open('v12.html')
    for q in ["r.Club==='BHA'&&/Gro/.test(r.Player)","r.Club==='BOU'","r.Club==='NFO'","r.Club==='SUN'"]:
        p.evaluate("const q=D.plr.find(r=>%s);openSheet(plrPseudo(q))"%q); p.wait_for_timeout(400)
        print(p.evaluate("""()=>{const m=document.querySelector('#sheet .fxblk .fxmain');if(!m)return null;
      const tr=el=>{const r=document.createRange();r.selectNodeContents(el);return r.getBoundingClientRect()};
      const hb=tr(m.querySelector('.fxs.h b')),ab=tr(m.querySelector('.fxs.a b'));const ko=m.querySelector('.ko');const kr=ko?tr(ko):null;
      return {gapL:Math.round(kr.left-hb.right),gapR:Math.round(ab.left-kr.right),h:m.querySelector('.fxs.h b').textContent,a:m.querySelector('.fxs.a b').textContent,koW:Math.round(kr.width),hw:Math.round(hb.width)}}"""))
        p.evaluate("closeSheet()"); p.wait_for_timeout(300)
