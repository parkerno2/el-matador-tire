import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=1280,height=800) as app:
    bad=[]
    p=app.ctx.new_page(); p.on('response',lambda r: r.status>=400 and bad.append((r.status,r.url.split('/')[-1])))
    p.goto('https://parkerno2.github.io/el-matador-tire/v12.html',wait_until='load'); p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0"); p.wait_for_timeout(600)
    p.evaluate("document.getElementById('hfaq').click()"); p.wait_for_timeout(400)
    p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers');location.hash='team'"); p.wait_for_timeout(600)
    print(sorted(set(bad)))
