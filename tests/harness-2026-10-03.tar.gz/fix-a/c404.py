import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=390,height=844) as app:
    bad=[]
    p=app.ctx.new_page(); p.on('response',lambda r: r.status>=400 and bad.append((r.status,r.url)))
    p.goto('https://parkerno2.github.io/el-matador-tire/v12.html',wait_until='load'); p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0"); p.wait_for_timeout(600)
    p.evaluate("location.hash='table'"); p.wait_for_timeout(300)
    p.evaluate("openProfile('Cold Palmers')"); p.wait_for_timeout(600)
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers');location.hash='team'"); p.wait_for_timeout(600)
    print(bad)
