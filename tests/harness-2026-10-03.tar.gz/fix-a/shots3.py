import sys; sys.path.insert(0,'/home/claude/harness')
from harness import App
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    p.evaluate("openSheet(D.ro.find(r=>/Rice/.test(r.Player)))"); p.wait_for_timeout(500)
    p.evaluate("document.getElementById('sheet').scrollTop=430"); p.wait_for_timeout(300)
    p.screenshot(path='shots/after-LG24-rice-bars.png')
    print(p.evaluate("[...document.querySelectorAll('#sheet .statgrid.lg .bar i')].map(i=>i.style.width+' '+i.style.background)"))
    p.evaluate("closeSheet()"); p.wait_for_timeout(300)
    p.evaluate("localStorage.setItem('emt-myteam','Cold Palmers');location.hash='team'"); p.wait_for_timeout(600)
    el=p.locator('#teampage .card.fixt').first; el.scroll_into_view_if_needed(); p.wait_for_timeout(200); el.screenshot(path='shots/after-T2-T4-grid.png')
