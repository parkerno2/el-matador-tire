"""Phone-size test harness for the El Matador Tire app.

Serves the repo's built pages from disk and answers every external request locally:
  gviz JSONP  -> tabs/<Tab>.json (from the Drive xlsx export of the real sheet)
  faces       -> emt/faces/<code>.png (committed), PL photos -> generated placeholder
  badges/flags-> generated placeholders; Google Fonts -> fontsource files from npm
  Apps Script -> stubbed JSON
Usage (python):  from harness import App;  with App() as app: page = app.open('index.html'); ...
"""
import json, re, pathlib, io, urllib.parse, time, os
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(os.environ.get('EMT_ROOT', '/home/claude/emt'))
H = pathlib.Path('/home/claude/harness')
TABS = H / 'tabs'
FONTS = H / 'fonts'
BASE = 'https://parkerno2.github.io/el-matador-tire/'

def _png(w, h, rgb, silhouette=False):
    from PIL import Image, ImageDraw
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0) if silhouette else rgb + (255,))
    if silhouette:
        d = ImageDraw.Draw(im)
        d.ellipse((w * .3, h * .12, w * .7, h * .5), fill=rgb + (255,))
        d.rounded_rectangle((w * .12, h * .55, w * .88, h * 1.1), radius=int(w * .25), fill=rgb + (255,))
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()

PLACE = {}
def placeholder(kind):
    if kind not in PLACE:
        PLACE[kind] = {'photo': lambda: _png(220, 280, (120, 110, 140), True),
                       'badge': lambda: _png(50, 50, (90, 45, 142)),
                       'flag': lambda: _png(40, 30, (200, 200, 210)),
                       'pix': lambda: _png(1, 1, (0, 0, 0), True)}[kind]()
    return PLACE[kind]

FONT_PKG = {'Archivo': 'archivo', 'Archivo Black': 'archivo-black', 'Manrope': 'manrope',
            'Saira Condensed': 'saira-condensed', 'Barlow Condensed': 'barlow-condensed'}

def font_css(url):
    q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    out = []
    for fam in q.get('family', []):
        name, _, spec = fam.partition(':')
        weights = re.findall(r'\d{3}', spec) or ['400']
        pkg = FONT_PKG.get(name)
        if not pkg: continue
        d = next(FONTS.glob(f'fontsource-{pkg}-*/package/files'), None)
        if not d: continue
        for w in weights:
            for sub in ('latin', 'latin-ext'):
                f = d / f'{pkg}-{sub}-{w}-normal.woff2'
                if f.exists():
                    out.append("@font-face{font-family:'%s';font-style:normal;font-weight:%s;font-display:swap;"
                               "src:url(https://fonts.gstatic.com/local/%s) format('woff2');}" % (name, w, f.relative_to(FONTS)))
    return '\n'.join(out)

class App:
    def __init__(self, width=390, height=844, now=None, tabs=TABS, api=None, block_sw=True):
        self.width, self.height, self.now, self.tabs, self.api, self.block_sw = width, height, now, pathlib.Path(tabs), api, block_sw
        self.errors, self.console, self.requests = [], [], []

    def __enter__(self):
        self.pw = sync_playwright().start()
        self.browser = self.pw.chromium.launch(args=['--disable-web-security'])
        self.ctx = self.browser.new_context(viewport={'width': self.width, 'height': self.height}, device_scale_factor=2,
                                            is_mobile=self.width < 700, has_touch=self.width < 700,
                                            service_workers='block' if self.block_sw else 'allow',
                                            user_agent=('Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 '
                                                        '(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1') if self.width < 700 else None)
        if self.now:
            # freeze the app's clock: Date.now / new Date() start at `now` (ISO) and advance in real time
            self.ctx.add_init_script("""(()=>{const off=Date.parse(%s)-Date.now();const _D=Date;
              class FD extends _D{constructor(...a){if(a.length)super(...a);else super(_D.now()+off)}static now(){return _D.now()+off}}
              FD.UTC=_D.UTC;FD.parse=_D.parse;window.Date=FD;})();""" % json.dumps(self.now))
        self.ctx.route('**/*', self._route)
        return self

    def __exit__(self, *a):
        self.ctx.close(); self.browser.close(); self.pw.stop()

    def _tab(self, name):
        f = self.tabs / (name + '.json')
        if not f.exists():
            f = self.tabs / 'Grades.json'   # real gviz serves the first sheet for an unknown tab
        return f.read_text()

    def _route(self, route):
        req = route.request; url = req.url
        self.requests.append(url)
        u = urllib.parse.urlparse(url)
        try:
            if 'docs.google.com' in u.netloc and '/gviz/tq' in u.path:
                q = urllib.parse.parse_qs(u.query)
                tqx = q.get('tqx', [''])[0]
                cb = re.search(r'responseHandler:([\w$]+)', tqx)
                cb = cb.group(1) if cb else 'google.visualization.Query.setResponse'
                return route.fulfill(status=200, content_type='application/javascript; charset=utf-8',
                                     body='/*O_o*/\n%s(%s);' % (cb, self._tab(q.get('sheet', ['Grades'])[0])))
            if u.netloc == 'parkerno2.github.io' and u.path.startswith('/el-matador-tire/'):
                rel = u.path[len('/el-matador-tire/'):] or 'index.html'
                f = ROOT / rel
                if f.is_file():
                    return route.fulfill(path=str(f))
                if rel.startswith('faces/'):
                    return route.fulfill(status=404, body='')
                return route.fulfill(status=404, body='not found')
            if 'fonts.googleapis.com' in u.netloc:
                return route.fulfill(status=200, content_type='text/css', body=font_css(url))
            if 'fonts.gstatic.com' in u.netloc and u.path.startswith('/local/'):
                return route.fulfill(path=str(FONTS / u.path[len('/local/'):]), content_type='font/woff2')
            if 'resources.premierleague.com' in u.netloc:
                if '/photos/' in u.path:
                    return route.fulfill(status=200, content_type='image/png', body=placeholder('photo'))
                return route.fulfill(status=200, content_type='image/png', body=placeholder('badge'))
            if 'flagcdn.com' in u.netloc:
                return route.fulfill(status=200, content_type='image/png', body=placeholder('flag'))
            if 'google.com' in u.netloc and 'favicons' in u.path:
                return route.fulfill(status=200, content_type='image/png', body=placeholder('badge'))
            if 'script.google.com' in u.netloc or 'script.googleusercontent.com' in u.netloc:
                body = self.api(req) if self.api else {'ok': True, 'ran': False, 'busy': False, 'ageSec': 120}
                return route.fulfill(status=200, content_type='application/json', body=json.dumps(body),
                                     headers={'Access-Control-Allow-Origin': '*'})
            if u.scheme == 'data' or u.scheme == 'blob':
                return route.continue_()
            return route.fulfill(status=404, body='')
        except Exception as e:
            self.errors.append('route ' + url + ' ' + repr(e))
            return route.fulfill(status=500, body='')

    def open(self, page='index.html', hash='', wait_ready=True):
        p = self.ctx.new_page()
        p.on('pageerror', lambda e: self.errors.append('pageerror: ' + str(e)))
        p.on('console', lambda m: self.console.append((m.type, m.text)) or (m.type == 'error' and self.errors.append('console: ' + m.text)))
        p.goto(BASE + page + (('#' + hash) if hash else ''), wait_until='load')
        if wait_ready:
            # data loaded = the loading state is gone and Matchday has content
            p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0", timeout=20000)
            p.wait_for_timeout(600)
        return p

if __name__ == '__main__':
    import sys
    page = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
    with App() as app:
        p = app.open(page)
        p.screenshot(path=str(H / 'shots' / 'smoke.png'))
        print('errors:', app.errors[:20])
        print('title:', p.title())
