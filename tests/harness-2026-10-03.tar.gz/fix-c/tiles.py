from h import *
import json,sys
w=int(sys.argv[1])
with App(width=w,height=700) as app:
    p=app.open('v12.html'); tab(p,'ana')
    r=p.evaluate("""()=>{const t=document.querySelector('#anabody .mgrid .mt');const tr=t.getBoundingClientRect();const row=t.querySelector('.mtrow');
      return {tile:[Math.round(tr.left),Math.round(tr.right),getComputedStyle(t).paddingLeft],row:[Math.round(row.getBoundingClientRect().width),row.scrollWidth,getComputedStyle(row).gap],
        spans:[...row.children].map(s=>{const r=s.getBoundingClientRect();return [Math.round(r.left),Math.round(r.right),s.scrollWidth,getComputedStyle(s.querySelector('b')).fontSize]})}}""")
    print(json.dumps(r))
    p.evaluate("()=>document.querySelector('#anabody .mgrid').scrollIntoView()"); p.wait_for_timeout(200)
    p.screenshot(path=SH+'after/tiles-%d.png'%w)
