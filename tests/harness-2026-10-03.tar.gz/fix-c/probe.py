"""Probe every owned finding; prints JSON of measurements. Usage: python3 probe.py <tag> [group ...]"""
from h import *
import json, sys
tag = sys.argv[1]
groups = sys.argv[2:] or ['players', 'table', 'lab', 'faq', 'gw', 'team', 'misc']
R = {}
def shot(p, name): p.screenshot(path=SH + tag + '/' + name + '.png')

def box(p, sel):
    return p.evaluate("""s=>[...document.querySelectorAll(s)].filter(e=>e.offsetParent!==null||getComputedStyle(e).position==='fixed').map(e=>{const r=e.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height),(e.textContent||'').trim().slice(0,18)]})""", sel)

def search(p, q):
    p.fill('#pfind', ''); p.type('#pfind', q, delay=10); p.wait_for_timeout(150)
    return p.evaluate("()=>[...document.querySelectorAll('#pres .prw')].map(r=>r.querySelector('.pw b').textContent+' | '+r.querySelector('.pw em').textContent)")

if 'players' in groups:
    with App(width=390, height=844) as app:
        p = app.open('v12.html'); tab(p, 'xis')
        r = {}
        for q in ['Haaland', 'Cherki', 'Mainoo', 'Groß']:
            rows = search(p, q)
            r['row_' + q] = rows[0] if rows else None
            p.locator('#pres .prw').first.click(); p.wait_for_timeout(300)
            r['sheet_' + q] = p.evaluate("()=>{const c=[...document.querySelectorAll('#sheet .chip')].find(c=>/^OVR/.test(c.textContent));return c?c.textContent:null}")
            p.keyboard.press('Escape'); p.wait_for_timeout(300)
        for q in ['Saka', 'Eze', 'Raya', 'van dijk', 'gross', 'joao', 'João', 'morgan gibbs white', 'Pal', 'Rice', 'odegaard', 'zzzzqq', 'vandijk', 'Isak', 'Bruno']:
            rows = search(p, q)
            r['q_' + q] = [x.split(' | ')[0] for x in rows[:5]]
        # free agents (clear search)
        p.fill('#pfind', ''); p.dispatch_event('#pfind', 'input'); p.wait_for_timeout(200)
        r['fa_rows'] = p.evaluate("()=>[...document.querySelectorAll('.fahead~.prw')].slice(0,3).map(r=>r.querySelector('.pw b').textContent+' | '+r.querySelector('.pw em').textContent)")
        p.locator('.fahead~.prw').first.click(); p.wait_for_timeout(300)
        r['fa_sheet0'] = p.evaluate("()=>{const c=[...document.querySelectorAll('#sheet .chip')].find(c=>/^OVR/.test(c.textContent));return c?c.textContent:null}")
        p.keyboard.press('Escape'); p.wait_for_timeout(300)
        # TP-4 caret
        p.fill('#pfind', ''); p.click('#pfind'); p.keyboard.type('Rce', delay=30)
        p.evaluate("()=>{const i=document.getElementById('pfind');i.setSelectionRange(1,1)}")
        p.keyboard.type('i', delay=30); p.keyboard.type('x', delay=30); p.wait_for_timeout(100)
        r['caret_value'] = p.evaluate("()=>document.getElementById('pfind').value")
        r['caret_focus'] = p.evaluate("()=>document.activeElement&&document.activeElement.id")
        p.fill('#pfind', ''); p.dispatch_event('#pfind', 'input'); p.wait_for_timeout(150)
        r['fatog'] = box(p, '.fatog button')
        shot(p, 'players-390')
        r['errors'] = app.errors
        R['players'] = r

if 'table' in groups:
    for w, hh in [(390, 844), (320, 640)]:
        with App(width=w, height=hh) as app:
            p = app.open('v12.html'); tab(p, 'table')
            r = {}
            r['trow'] = p.evaluate("()=>[...document.querySelectorAll('.trow:not(.thead)')].map(t=>{const n=t.querySelector('.nm2');return [Math.round(n.getBoundingClientRect().width),Math.round(t.getBoundingClientRect().height)]})")
            shot(p, 'table-%d' % w)
            p.evaluate("()=>{const d=[...document.querySelectorAll('#tablebody details')].find(d=>/MOTM history/.test(d.textContent));d.open=true;d.scrollIntoView()}")
            p.wait_for_timeout(200)
            r['motm'] = p.evaluate("()=>[...document.querySelectorAll('.mrow')].map(m=>{const n=m.querySelector('.nm4');return n?[n.textContent,n.scrollWidth>n.clientWidth+1, Math.round(n.getBoundingClientRect().width)]:null})")
            shot(p, 'motm-%d' % w)
            r['money_col'] = p.evaluate("()=>[...document.querySelectorAll('.money')].map(e=>getComputedStyle(e).color)")
            r['tagwon'] = p.evaluate("()=>[...document.querySelectorAll('.tag.won')].map(e=>getComputedStyle(e).backgroundColor)")
            r['dial'] = p.evaluate("()=>{const d=document.querySelector('.dial');return d?[d.style.background.slice(0,60),getComputedStyle(d.querySelector('b')).color,getComputedStyle(d.parentElement.querySelector('span[style]')).color]:null}")
            r['records'] = p.evaluate("()=>[...document.querySelectorAll('.minirecs .lb')].map(e=>e.textContent)")
            r['errors'] = app.errors
            R['table%d' % w] = r

if 'lab' in groups:
    for w, hh in [(390, 844), (320, 640)]:
        with App(width=w, height=hh) as app:
            p = app.open('v12.html'); tab(p, 'ana')
            r = {}
            r['tap'] = {k: box(p, s) for k, s in [('fatog', '.lucks ~ * .fatog button, .fahead .fatog button'), ('labview', '.labview'), ('labmet', '.labmet'), ('labseg', '.labseg button'), ('labclear', '.labclear')]}
            r['labmets_overflow'] = p.evaluate("()=>{const m=document.querySelector('.labmets');return [m.scrollWidth,m.clientWidth]}")
            r['tiles'] = p.evaluate("()=>[...document.querySelectorAll('#anabody .mgrid .mt')].map(t=>{const n=t.querySelector('.mtn');const b=t.querySelectorAll('.mtrow b')[2];return [n.textContent,n.scrollWidth>n.clientWidth+1,b?Math.round(b.getBoundingClientRect().height):0]})")
            r['barlabels'] = p.evaluate("()=>[...document.querySelectorAll('#labviz .lbl2')].map(n=>[n.firstChild.textContent,n.scrollWidth>n.clientWidth+1])")
            # luck index
            def lucks():
                return p.evaluate("()=>[...document.querySelectorAll('.lucks .lrow2')].map(r=>{const m=r.querySelector('.lmid');return [m.textContent,Math.round(m.getBoundingClientRect().width),m.scrollWidth>m.clientWidth+1]})")
            r['luck_perf'] = lucks()
            p.locator('[data-lm="sched"]').click(); p.wait_for_timeout(200)
            r['luck_sched'] = lucks()
            p.evaluate("()=>document.querySelector('.lucks').scrollIntoView()"); shot(p, 'luck-sched-%d' % w)
            p.locator('[data-lm="perf"]').click(); p.wait_for_timeout(200)
            r['luck_index_colors'] = p.evaluate("()=>[...document.querySelectorAll('.lucks .lrow2')].map(r=>[r.dataset.prof,r.querySelector('.ld').textContent,getComputedStyle(r.querySelector('.ld')).color])")
            p.evaluate("()=>window.scrollTo(0,0)")
            # race default (no selection)
            p.locator('.labview[data-v="race"]').click(); p.wait_for_timeout(200)
            def chart():
                return p.evaluate("""()=>{const s=document.querySelector('#labviz svg');if(!s)return null;const wr=s.parentElement;const vb=s.viewBox.baseVal;const sc=s.getBoundingClientRect().width/vb.width;
                  const txt=[...s.querySelectorAll('text')].map(t=>({t:t.textContent,fs:+(t.getAttribute('font-size')||0)*sc,fill:t.getAttribute('fill'),b:t.getBoundingClientRect()}));
                  const ov=[];const lab=txt.filter(x=>isNaN(+x.t)&&!/^GW\\d+$/.test(x.t));
                  for(let i=0;i<lab.length;i++)for(let j=i+1;j<lab.length;j++){const a=lab[i].b,b=lab[j].b;if(a.left<b.right&&b.left<a.right&&a.top<b.bottom&&b.top<a.bottom)ov.push(lab[i].t+'/'+lab[j].t)}
                  const sb=s.getBoundingClientRect();const out=lab.filter(x=>x.b.right>sb.right+1||x.b.left<sb.left-1).map(x=>x.t);
                  return {lines:s.querySelectorAll('polyline').length,svgW:Math.round(sb.width),wrapW:wr.clientWidth,wrapScroll:wr.scrollWidth,labels:lab.map(x=>x.t),overlaps:ov,outside:out,
                    axis:txt.filter(x=>!isNaN(+x.t)&&x.t!=='').map(x=>x.t),minFs:Math.min(...txt.map(x=>x.fs)).toFixed(1),fills:[...new Set(txt.map(x=>x.fill))],
                    foot:(document.querySelector('#labviz .labfoot')||{}).textContent||''}}""")
            r['race_none'] = chart(); shot(p, 'race-none-%d' % w)
            # LG-12/13: select crests
            crests = p.locator('.labmono[data-t]')
            p.locator('.labview[data-v="bars"]').click(); p.wait_for_timeout(150)
            crests.nth(0).click(); p.wait_for_timeout(150)
            r['after1crest'] = p.evaluate("()=>[LAB.view,LAB.sel.length,document.querySelectorAll('#labviz .lbrow').length]")
            for i in range(1, 5):
                crests.nth(i).click(); p.wait_for_timeout(120)
            r['after5crests'] = p.evaluate("()=>[LAB.sel.slice(),LAB.view]")
            p.evaluate("()=>labSet({sel:LAB.sel.slice(0,3),view:'trend',metric:'pts'})"); p.wait_for_timeout(150)
            r['trend3'] = chart(); shot(p, 'trend3-%d' % w)
            # one manager race (Cold Palmers)
            p.evaluate("()=>labSet({sel:['Cold Palmers'],view:'race',metric:'pts'})"); p.wait_for_timeout(150)
            r['race_palmers'] = chart()
            r['race_palmers_vals'] = p.evaluate("()=>[...document.querySelectorAll('#labviz svg text')].map(t=>t.textContent).filter(t=>/^\\d/.test(t)).slice(-12)")
            shot(p, 'race-palmers-%d' % w)
            p.evaluate("()=>labSet({sel:['Cold Palmers'],view:'trend',metric:'luck'})"); p.wait_for_timeout(150)
            r['luck_trend_foot'] = chart()['foot']
            # LG-03: bar tap from luck
            p.evaluate("()=>labSet({sel:[],view:'bars',metric:'luck'})"); p.wait_for_timeout(150)
            r['luck_bar_colors'] = p.evaluate("()=>[...document.querySelectorAll('#labviz .lbrow')].map(r=>[r.dataset.lab,r.querySelector('.lbv').textContent,getComputedStyle(r.querySelector('.lbtrack i')).backgroundColor])")
            r['luck_bar_foot'] = p.evaluate("()=>document.querySelector('#labviz .labfoot').textContent")
            p.locator('#labviz .lbrow').first.click(); p.wait_for_timeout(150)
            r['bartap_from_luck'] = p.evaluate("()=>[LAB.metric,LAB.view,LAB.sel.slice()]")
            # League scope
            p.locator('.labseg button[data-s="league"]').click(); p.wait_for_timeout(150)
            r['wins'] = chart(); shot(p, 'wins-%d' % w)
            p.evaluate("()=>labSet({metric:'spread'})"); p.wait_for_timeout(150)
            r['spread'] = p.evaluate("()=>{const s=document.querySelector('#labviz svg');const wr=s.parentElement;return {texts:[...s.querySelectorAll('text')].map(t=>t.textContent),svgW:Math.round(s.getBoundingClientRect().width),wrapW:wr.clientWidth,wrapScroll:wr.scrollWidth,titles:s.querySelectorAll('title').length}}")
            shot(p, 'spread-%d' % w)
            r['segtext'] = p.evaluate("()=>[...document.querySelectorAll('.labseg button')].map(b=>b.textContent)")
            p.locator('.labseg button[data-s="mgr"]').click(); p.wait_for_timeout(150)
            crests.nth(0).click(); p.wait_for_timeout(100)
            r['alltext'] = p.evaluate("()=>(document.querySelector('.labclear')||{}).textContent")
            r['errors'] = app.errors
            R['lab%d' % w] = r

if 'faq' in groups:
    with App(width=390, height=844) as app:
        p = app.open('v12.html', hash='faq')
        r = {}
        r['back'] = p.evaluate("()=>{const b=document.querySelector('#v-faq .backbtn, #faqback');return b?[b.textContent,b.getBoundingClientRect().height]:null}")
        r['heading'] = p.evaluate("()=>{const v=document.getElementById('v-faq');const h=[...v.querySelectorAll('h1,h2')].filter(x=>x.offsetParent);return h.length?h[0].textContent:null}")
        r['cardpts'] = p.evaluate("()=>[...document.querySelectorAll('#faqbody .gallery .fc .pts')].map(x=>x.textContent)")
        r['pot_col'] = p.evaluate("()=>[...document.querySelectorAll('.pot b')].map(e=>getComputedStyle(e).color)")
        shot(p, 'faq-top')
        if r['back']:
            p.locator('#faqback').click(); p.wait_for_timeout(300)
            r['after_back_hash'] = p.evaluate("()=>location.hash")
        # in-app: table -> faq -> back
        p.goto(p.url.split('#')[0] + '#table'); p.wait_for_timeout(800)
        p.evaluate("()=>{location.hash='faq'}"); p.wait_for_timeout(300)
        if p.locator('#faqback').count():
            p.locator('#faqback').click(); p.wait_for_timeout(300)
        r['inapp_back_hash'] = p.evaluate("()=>location.hash")
        r['errors'] = app.errors
        R['faq'] = r

if 'gw' in groups:
    for w, hh in [(390, 844), (320, 640)]:
        with App(width=w, height=hh) as app:
            p = app.open('v12.html')
            r = {}
            # MD-03/04
            p.evaluate("()=>window.scrollTo(0,380)"); p.wait_for_timeout(300)
            r['hl0'] = p.evaluate("()=>history.length")
            p.evaluate("()=>{const c=[...document.querySelectorAll('#gwbody .mcard[data-mi]')].find(c=>c.getBoundingClientRect().top>60);c.click()}")
            p.wait_for_timeout(400)
            r['in_match'] = p.evaluate("()=>[location.hash,scrollY]")
            p.locator('#gwback').click(); p.wait_for_timeout(500)
            r['after_back'] = p.evaluate("()=>[location.hash,Math.round(scrollY),history.length]")
            p.go_back(); p.wait_for_timeout(500)
            r['after_sys_back'] = p.evaluate("()=>[location.href.split('/').pop(),history.length]")
            # derbies accordion
            p.goto('https://parkerno2.github.io/el-matador-tire/v12.html#gw'); p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0", timeout=20000); p.wait_for_timeout(800)
            p.locator('[data-gwtab="derbies"]').click(); p.wait_for_timeout(200)
            p.evaluate("()=>{const d=document.querySelector('details.dun');d.open=true}")
            p.evaluate("()=>window.scrollTo(0,200)"); p.wait_for_timeout(300)
            c = p.locator('.dcard[data-mi]').first
            c.click(); p.wait_for_timeout(400)
            p.locator('#gwback').click(); p.wait_for_timeout(500)
            r['derby_back'] = p.evaluate("()=>[location.hash,Math.round(scrollY),!!(document.querySelector('details.dun')||{}).open]")
            p.locator('[data-gwtab="week"]').click(); p.wait_for_timeout(200)
            # PL strip
            p.evaluate("()=>{const b=document.getElementById('plall');b.click()}"); p.wait_for_timeout(300)
            r['pl_rows'] = p.evaluate("""()=>[...document.querySelectorAll('.plrow.tap')].slice(0,4).map(r=>{const m=r.querySelector('.mid2');const c=r.querySelector('.cnt');
                return [m.textContent,Math.round(m.getBoundingClientRect().height),c?(c.parentElement.className+':'+c.textContent):null]})""")
            r['pl_trunc'] = p.evaluate("()=>[...document.querySelectorAll('.plx.on .plp .pn')].filter(n=>n.scrollWidth>n.clientWidth+1).map(n=>n.textContent).slice(0,12)")
            r['pl_total'] = p.evaluate("()=>document.querySelectorAll('.plx.on .plp .pn').length")
            p.evaluate("()=>document.querySelector('.plhead').scrollIntoView()"); p.wait_for_timeout(200)
            shot(p, 'pl-%d' % w)
            # MD-21 articles
            p.evaluate("()=>window.scrollTo(0,0)")
            p.evaluate("()=>{const a=document.getElementById('allart');a&&a.click()}"); p.wait_for_timeout(400)
            r['art_open'] = p.evaluate("()=>sheet.classList.contains('on')&&!!sheet.querySelector('.artl')")
            if r['art_open']:
                p.locator('#sheet .artl a').first.click(); p.wait_for_load_state('load'); p.wait_for_timeout(800)
                r['art_url'] = p.url.split('/')[-1]
                p.go_back(); p.wait_for_load_state('load')
                try:
                    p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0", timeout=15000)
                except Exception as e:
                    r['art_wait'] = str(e)[:80]
                p.wait_for_timeout(900)
                r['art_back'] = p.evaluate("()=>[location.hash,sheet.classList.contains('on'),!!sheet.querySelector('.artl'),JSON.stringify(history.state)]")
                if r['art_back'][1]:
                    p.keyboard.press('Escape'); p.wait_for_timeout(400)
                    r['art_close'] = p.evaluate("()=>[location.hash,sheet.classList.contains('on'),JSON.stringify(history.state)]")
            r['errors'] = app.errors
            R['gw%d' % w] = r

if 'team' in groups:
    for w, hh in [(390, 844), (320, 640)]:
        with App(width=w, height=hh) as app:
            p = app.open('v12.html'); tab(p, 'team')
            r = {}
            r['picker'] = p.evaluate("()=>[...document.querySelectorAll('#teambody .mgrid .mt')].map(b=>{const n=b.querySelector('.mtn');return [n.textContent,n.scrollWidth>n.clientWidth+1]})")
            shot(p, 'picker-%d' % w)
            p.locator('[data-claim]').first.click(); p.wait_for_timeout(400)
            r['claim_order'] = p.evaluate("()=>[...document.querySelectorAll('.au-grid .au-tm b')].map(b=>b.textContent)")
            p.keyboard.press('Escape'); p.wait_for_timeout(300)
            p.locator('#teambody [data-pick]').first.click(); p.wait_for_timeout(400)
            r['swteam'] = box(p, '#swteam')
            r['errors'] = app.errors
            R['team%d' % w] = r

if 'misc' in groups:
    with App(width=390, height=844) as app:
        p = app.open('v12.html')
        r = {}
        # LG-30 scroll restore
        tab(p, 'table'); p.evaluate("()=>window.scrollTo(0,600)"); p.wait_for_timeout(300)
        tab(p, 'xis'); p.wait_for_timeout(200)
        p.go_back(); p.wait_for_timeout(500)
        r['table_back_y'] = p.evaluate("()=>[location.hash,Math.round(scrollY)]")
        tab(p, 'ana'); p.evaluate("()=>window.scrollTo(0,500)"); p.wait_for_timeout(300)
        tab(p, 'table'); p.wait_for_timeout(300)
        r['table_nav_y'] = p.evaluate("()=>[location.hash,Math.round(scrollY)]")
        tab(p, 'ana'); p.wait_for_timeout(300)
        r['ana_nav_y'] = p.evaluate("()=>[location.hash,Math.round(scrollY)]")
        tab(p, 'ana'); p.wait_for_timeout(900)
        r['ana_retap_y'] = p.evaluate("()=>[location.hash,Math.round(scrollY)]")
        # LG-33 faces
        p.goto(p.url.split('#')[0] + '#table'); p.wait_for_timeout(1500)
        n0 = len([u for u in app.requests if '/faces/575476' in u])
        for i in range(3):
            p.evaluate("()=>openProfile('Cold Palmers')"); p.wait_for_timeout(700)
            p.keyboard.press('Escape'); p.wait_for_timeout(400)
        r['face_reqs_575476'] = len([u for u in app.requests if '/faces/575476' in u]) - n0
        # #17 next fixture
        r['nextfx'] = p.evaluate("""()=>{const f=D.cf.find(x=>num(x.GW)===D.gw);const club=f.Home;const keep=[f.Started,f.Finished];f.Started=true;f.Finished=false;
            const a=nextFixture(club);f.Started=keep[0];f.Finished=keep[1];return [club,f.Away,a]}""")
        # #14
        p.goto(p.url.split('#')[0] + '#xis/UNKNOWN'); p.wait_for_timeout(1500)
        r['xis_unknown'] = p.evaluate("()=>[location.hash,document.querySelector('#xisbody').textContent.slice(0,40)]")
        r['errors'] = app.errors
        R['misc'] = r

out = json.dumps(R, indent=1, ensure_ascii=False)
open('/home/claude/harness/fix-c/probe-%s.json' % tag, 'w').write(out)
print(out)
