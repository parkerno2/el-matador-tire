from h import *
import sys
tag=sys.argv[1]
for w,hh in [(390,844),(320,640)]:
  with App(width=w,height=hh) as app:
    p=app.open('v12.html')
    for t in ['gw','team','table','xis','ana']:
        tab(p,t); p.screenshot(path=SH+tag+'/%s-%d.png'%(t,w), full_page=True)
    print(w, app.errors)
