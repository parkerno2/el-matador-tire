#!/bin/bash
set -e
cd /home/claude/wt-c
python3 - <<'PY'
import re
s=open('index-PREVIEW.html').read()
blocks=re.findall(r'<script>(.*?)</script>',s,re.S)
for i,b in enumerate(blocks):
    open('/home/claude/harness/fix-c/inline%d.js'%i,'w').write(b)
print(len(blocks),'inline scripts')
PY
for f in /home/claude/harness/fix-c/inline*.js; do node --check "$f" && echo "ok $f"; done
python3 fplgg/tools/v12/build_v12.py index-PREVIEW.html | tail -1
