from h import *
import json
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    # synthetic double gameweek: ARS play a second GW6 fixture (finished), first fixture still to come
    r=p.evaluate("""()=>{const f=D.cf.find(x=>num(x.GW)===D.gw&&x.Home==='ARS');
      const g={...f,Home:'WOL',Away:'ARS','Kickoff (UTC)':'2026-10-09T18:00:00Z',Started:true,Finished:true,'Home goals':0,'Away goals':2};
      D.cf=D.cf.concat([g]);const raya=D.ro.find(x=>x.Player==='Raya');raya['GW pts']=9;
      PLALL=true;renderGW();
      const rows=[...document.querySelectorAll('.plrow.tap')].filter(r=>/ARS/.test(r.textContent));
      return rows.map(r=>{const x=r.nextElementSibling;const ry=[...x.querySelectorAll('.plp')].find(q=>/Raya/.test(q.textContent));
        return [r.querySelector('.mid2').textContent, ry?ry.textContent:null, ry?ry.querySelector('.pv').className:null]})}""")
    print(json.dumps(r,ensure_ascii=False))
    print(app.errors)
