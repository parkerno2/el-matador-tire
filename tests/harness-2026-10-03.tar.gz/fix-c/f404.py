from h import *
import collections
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    bad=[]
    p.on('response', lambda r: bad.append(r.url.split('/')[-1]) if r.status==404 else None)
    tab(p,'team'); p.locator('#teambody [data-pick]').nth(4).click(); p.wait_for_timeout(800)
    print(p.evaluate("()=>myTeam()"), collections.Counter(bad))
    for i in range(3):
        p.evaluate("()=>openProfile('Cold Palmers')"); p.wait_for_timeout(600); p.keyboard.press('Escape'); p.wait_for_timeout(300)
    print(collections.Counter(bad))
