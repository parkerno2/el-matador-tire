from h import *
for w,hh in [(390,844),(320,640)]:
  with App(width=w,height=hh) as app:
    p=app.open('v12.html')
    p.evaluate("()=>document.getElementById('plall').click()"); p.wait_for_timeout(300)
    p.evaluate("()=>{const r=[...document.querySelectorAll('.plrow.tap')][5];r.scrollIntoView()}"); p.wait_for_timeout(200)
    p.screenshot(path=SH+'after/plx-%d.png'%w)
    tab(p,'table')
    p.evaluate("()=>{const d=[...document.querySelectorAll('#tablebody details')].find(d=>/MOTM history/.test(d.textContent));d.open=true;d.scrollIntoView()}"); p.wait_for_timeout(200)
    p.screenshot(path=SH+'after/motm2-%d.png'%w)
    tab(p,'ana'); p.evaluate("()=>document.querySelector('.lucks').scrollIntoView()"); p.wait_for_timeout(200)
    p.screenshot(path=SH+'after/luck2-%d.png'%w)
    print(w,[e for e in app.errors if 'Failed to load' not in e])
