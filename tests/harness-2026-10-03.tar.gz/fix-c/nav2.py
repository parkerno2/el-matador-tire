from h import *
import json
R={}
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    p.evaluate("()=>window.scrollTo(0,400)"); p.wait_for_timeout(300)
    tab(p,'team'); p.locator('#teambody [data-pick]').first.click(); p.wait_for_timeout(500)
    row=p.locator('.lkSched .lkr.lkfut').nth(2); row.scroll_into_view_if_needed(); p.wait_for_timeout(200)
    y0=p.evaluate("()=>Math.round(scrollY)")
    row.click(); p.wait_for_timeout(500)
    R['gogw']=p.evaluate("()=>[location.hash,Math.round(scrollY),(document.querySelector('.fbx-now')||{}).textContent||'']")
    p.go_back(); p.wait_for_timeout(500)
    R['back_team']=[y0,p.evaluate("()=>[location.hash,Math.round(scrollY)]")]
    # next card -> matchup -> ‹ Matchday (not opened from the list: replace, top)
    p.evaluate("()=>window.scrollTo(0,0)"); p.wait_for_timeout(200)
    p.locator('.lkNext').first.click(); p.wait_for_timeout(500)
    R['match_from_team']=p.evaluate("()=>[location.hash,history.state&&history.state.emtFrom]")
    hl=p.evaluate("()=>history.length")
    p.locator('#gwback').click(); p.wait_for_timeout(500)
    R['back_to_list']=p.evaluate("()=>[location.hash,Math.round(scrollY),history.length]")+[hl]
    p.go_back(); p.wait_for_timeout(500)
    R['then_back']=p.evaluate("()=>location.hash")
    R['errors']=[e for e in app.errors if 'Failed to load' not in e]
print(json.dumps(R))
