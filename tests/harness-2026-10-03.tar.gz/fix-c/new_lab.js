/* Lab charts draw in a 320-unit viewBox that scales with the card, so nothing hides behind a sideways scroll at
   320 px; type is sized for that scale and axis text is 6:1 on white. Axis steps are 1-2-5 'nice' for the data,
   end labels are short team names pushed apart so they never stack, and a live point wears a green ring. */
const LABAX='#5E566B';
const labShort=t=>(typeof SHORTOF!=='undefined'&&SHORTOF[t])||t;
const labInk=c=>{const n=parseInt(String(c).slice(1),16);if(String(c).length!==7||isNaN(n))return c; /* team colour darkened for text on white */
  return '#'+[n>>16,(n>>8)&255,n&255].map(v=>Math.round(v*.72).toString(16).padStart(2,'0')).join('')};
function labStep(range,n,ints){const raw=range/(n||4);if(!(raw>0))return 1;const e=Math.pow(10,Math.floor(Math.log10(raw))),f=raw/e;
  let st=(f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*e;if(ints&&st%1)st=Math.floor(st)||1;return st}
function svgLine(series,opts){
  opts=opts||{};
  series=series.filter(s=>s.vals.length);
  const gws=[...new Set(series.flatMap(s=>s.vals.map(v=>v.gw)))].sort((a,b)=>a-b);
  if(!gws.length)return'<p class="state">Draws itself once the data lands.</p>';
  const W=320,H=opts.h||200,PL=30,PT=16,PB=24,PR=opts.endLabels?66:18;
  const allv=series.flatMap(s=>s.vals.map(v=>v.v));
  let mx=Math.max(...allv,1),mn=Math.min(...allv,0);
  const st=labStep(mx-mn,4,allv.every(v=>Number.isInteger(v)));
  mx=Math.ceil(mx/st-1e-9)*st;mn=mn<0?Math.floor(mn/st+1e-9)*st:0;if(mx<=mn)mx=mn+st;
  const px=g=>{const i=gws.indexOf(g);return gws.length<2?PL+(W-PL-PR)/2:PL+i*((W-PL-PR)/(gws.length-1))};
  const py=v=>H-PB-((v-mn)/(mx-mn))*(H-PT-PB);
  const fv=v=>String(Math.round(v*10)/10);
  let out='';
  for(let k=0,v=mn;v<=mx+1e-9&&k<12;k++,v=mn+k*st){const zero=mn<0&&Math.abs(v)<1e-9;
    out+='<line x1="'+PL+'" y1="'+py(v)+'" x2="'+(W-PR)+'" y2="'+py(v)+'" stroke="'+(zero?'#D9CFE2':'#EEE8F2')+'"'+(zero?'':' stroke-dasharray="3 4"')+'/>'
     +'<text x="'+(PL-5)+'" y="'+(py(v)+3.5)+'" font-size="10.5" text-anchor="end" fill="'+LABAX+'">'+fv(v)+'</text>';}
  const step=Math.max(1,Math.ceil(gws.length/7));
  gws.forEach((g,i)=>{if(i%step)return;
    out+='<text x="'+px(g)+'" y="'+(H-7)+'" font-size="10.5" font-weight="700" text-anchor="middle" fill="'+LABAX+'">GW'+g+'</text>';});
  const thin=series.length>4,labs=[];
  series.forEach((s,si)=>{
    const solid=s.vals.filter(v=>!v.hollow);
    if(solid.length>1)out+='<polyline points="'+solid.map(v=>px(v.gw)+','+py(v.v)).join(' ')+'" fill="none" stroke="'+s.color+'" stroke-width="'+(thin?1.8:2.4)+'"'+(s.dash?' stroke-dasharray="5 4" opacity=".85"':'')+(thin&&!s.top?' opacity=".4"':'')+' stroke-linecap="round" stroke-linejoin="round"/>';
    if(!thin||s.top)s.vals.forEach(v=>{
      out+='<circle cx="'+px(v.gw)+'" cy="'+py(v.v)+'" r="'+(v.hollow?3:thin?2.6:3.4)+'" fill="'+(v.hollow?'#F4F1F6':s.color)+'"'+(v.hollow?' stroke="'+s.color+'"':'')+'/>'
       +(v.live?'<circle cx="'+px(v.gw)+'" cy="'+py(v.v)+'" r="6.2" fill="none" stroke="#0E8A5F" stroke-width="1.4"/>':'');
      /* first series labels above its dots, second below — no collisions when lines cross */
      if(series.length<=2&&!v.hollow)out+='<text x="'+px(v.gw)+'" y="'+(py(v.v)+(si===0?-8:16))+'" font-size="10.5" font-weight="700" text-anchor="middle" fill="'+labInk(s.color)+'">'+fv(v.v)+'</text>';
    });
    if(opts.endLabels&&solid.length&&(!thin||s.top)){const l=solid[solid.length-1];labs.push({x:px(l.gw),y:py(l.v),t:s.name,c:s.color});}
  });
  if(labs.length){ /* one column right of the last point; labels pushed apart (12 units) and kept inside the plot */
    const gap=12,lo=PT-4,hi=H-PB;
    labs.sort((a,b)=>a.y-b.y||String(a.t).localeCompare(String(b.t)));labs.forEach(l=>{l.ly=Math.min(hi,Math.max(lo,l.y))});
    for(let i=1;i<labs.length;i++)labs[i].ly=Math.max(labs[i].ly,labs[i-1].ly+gap);
    if(labs[labs.length-1].ly>hi){labs[labs.length-1].ly=hi;for(let i=labs.length-2;i>=0;i--)labs[i].ly=Math.min(labs[i].ly,labs[i+1].ly-gap);}
    labs.forEach(l=>{const lx=l.x+8;
      if(Math.abs(l.ly-l.y)>2)out+='<polyline points="'+(l.x+4)+','+l.y+' '+(lx-2)+','+l.ly+'" fill="none" stroke="'+l.c+'" stroke-width="1" opacity=".6"/>';
      out+='<text x="'+lx+'" y="'+(l.ly+4)+'" font-size="11.5" font-weight="700" fill="'+labInk(l.c)+'">'+esc(l.t)+'</text>';});
  }
  return '<div class="labsvg"><svg viewBox="0 0 '+W+' '+H+'" width="100%" style="display:block;width:100%;height:auto;max-width:480px;margin:0 auto" role="img">'+out+'</svg></div>';
}
