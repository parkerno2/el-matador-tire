from h import *
import json,sys
w=int(sys.argv[1]) if len(sys.argv)>1 else 320
with App(width=w,height=700) as app:
    p=app.open('v12.html')
    r=p.evaluate("""()=>{const row=document.querySelector('.plrow.tap');return [...row.children].map(c=>[c.className||c.tagName,Math.round(c.getBoundingClientRect().width),getComputedStyle(c).fontSize,getComputedStyle(c).fontFamily.slice(0,20),c.scrollWidth]).concat([[ 'row',row.clientWidth,getComputedStyle(row).gap]])}""")
    print(json.dumps(r))
    p.evaluate("()=>document.querySelector('.plhead').scrollIntoView()"); p.wait_for_timeout(200)
    p.screenshot(path=SH+'after/plhead-%d.png'%w)
