from h import *
for w in [390,320]:
  with App(width=w,height=700) as app:
    p=app.open('v12.html'); tab(p,'ana')
    el=p.locator('.lucks').first; el.scroll_into_view_if_needed()
    p.evaluate("()=>window.scrollBy(0,-80)"); p.wait_for_timeout(200)
    b=p.locator('.fahead').last.bounding_box()
    p.screenshot(path=SH+'after/luckhdr-%d.png'%w, clip={'x':0,'y':max(0,b['y']-10),'width':w,'height':80})
    p.locator('[data-lm="sched"]').click(); p.wait_for_timeout(200)
    b=p.locator('.fahead').last.bounding_box()
    p.screenshot(path=SH+'after/luckhdr2-%d.png'%w, clip={'x':0,'y':max(0,b['y']-10),'width':w,'height':80})
