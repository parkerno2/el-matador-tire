function labChart(){
  const S=LAB,agg=luckAgg();
  const foot=t2=>'<div class="labfoot">'+t2+'</div>';
  if(S.scope==='mgr'){
    const teams=S.sel.length?S.sel:anaOrder();
    const serOf=t=>{
      const ms=mgrSeries(t),a=(agg[t]||{gws:{}}).gws;
      switch(S.metric){
        case'pts':return ms.map(m=>({gw:m.gw,v:m.pts,live:m.live}));
        case'pa':return ms.map(m=>({gw:m.gw,v:m.pa,live:m.live}));
        case'margin':return ms.map(m=>({gw:m.gw,v:m.margin,live:m.live}));
        case'vsx':return Object.keys(a).map(g=>({gw:num(g),v:a[g].act})).sort((x,y)=>x.gw-y.gw);
        case'luck':return Object.keys(a).map(g=>({gw:num(g),v:a[g].act-a[g].x})).sort((x,y)=>x.gw-y.gw);
        case'bench':{const b=benchByGw(t);return Object.keys(b).map(g=>({gw:num(g),v:b[g]})).sort((x,y)=>x.gw-y.gw);}
      }return[];
    };
    if(S.view==='bars'){
      const perGw=S.metric==='pts'||S.metric==='pa';
      /* luck reads like the Luck index below it: green = running hot, red = deserved more */
      const lc=v=>v>=0?'var(--good)':'var(--bad)';
      const rows=teams.map(t=>{
        const vals=serOf(t),sum=vals.reduce((s2,v)=>s2+v.v,0);
        const v=perGw&&vals.length?sum/vals.length:sum;
        return{label:labShort(t),team:t,v,tap:t,
          barColor:S.metric==='luck'?lc(v):S.metric==='bench'?'var(--bad)':TEAMS[t].col,
          vColor:S.metric==='luck'?lc(v):'',
          sub:perGw?'avg / GW':''};
      }).sort((a2,b2)=>b2.v-a2.v);
      return rankBars(rows,{fmt:v=>((S.metric==='luck'||S.metric==='margin')&&v>0?'+':'')+(Math.round(v*10)/10)})
        +foot(S.metric==='luck'?'Actual − expected, bonus excluded both sides. Green = running hot, red = deserved more.':S.metric==='bench'?'Points scored by benched players.':S.metric==='margin'?'Season sum of winning and losing margins. Positive means you won by more than you lost by.':'Tap a bar to focus that manager.');
    }
    /* every picked manager, and all eight in the race when nobody is picked */
    const series=teams.map(t=>({name:labShort(t),color:TEAMS[t].col,vals:S.view==='race'?cumulate(serOf(t)):serOf(t),top:true}));
    const one=S.metric==='pts'&&teams.length===1;
    if(one){
      /* one manager's actual vs expected: both lines without bonus, the same basis as the Luck index and the profile chart */
      const a=(agg[teams[0]]||{gws:{}}).gws,live={};mgrSeries(teams[0]).forEach(m=>{live[m.gw]=m.live});
      const av=Object.keys(a).map(g=>({gw:num(g),v:a[g].act,live:!!live[num(g)]})).sort((x,y)=>x.gw-y.gw);
      const xv=Object.keys(a).map(g=>({gw:num(g),v:a[g].x})).sort((x,y)=>x.gw-y.gw);
      series[0].color='#17121D';series[0].vals=S.view==='race'?cumulate(av):av;
      series.push({name:'expected',color:'#5B1A66',dash:true,vals:S.view==='race'?cumulate(xv):xv,top:true});
    }
    const anyLive=series.some(s=>s.vals.some(v=>v.live));
    return svgLine(series,{endLabels:series.length>1||S.view==='race'})
      +foot(one?'<span style="display:inline-block;width:14px;border-top:2.5px solid #17121D;vertical-align:middle;margin-right:3px"></span>actual · <span style="display:inline-block;width:14px;border-top:2.5px dashed #5B1A66;vertical-align:middle;margin-right:3px"></span>expected (xP). Bonus is left out of both, as in the Luck index.'+(anyLive?' Ringed dot = live.':'')
        :(S.view==='race'?'Cumulative season totals.':'Per-gameweek.')+(anyLive?' Ringed dot = live.':''));
  }
  if(S.scope==='league'){
    if(S.metric==='wins'){
      const series=anaOrder().map(t=>({name:labShort(t),color:TEAMS[t].col,top:true,
        vals:cumulate(mgrSeries(t).filter(m=>!m.live).map(m=>({gw:m.gw,v:m.pts>m.pa?1:0})))}));
      return svgLine(series,{endLabels:true,h:210})+foot('Cumulative wins, one line per manager. Draws move nobody.');
    }
    const gws=Object.keys(D.gwsByGw).map(Number).sort((a2,b2)=>a2-b2);
    const rows=gws.map(g=>{
      const pts=anaOrder().map(t=>{const m=mgrSeries(t).find(x=>x.gw===g);return m?{t,v:m.pts}:null}).filter(Boolean);
      return{g,pts};
    }).filter(r=>r.pts.length);
    if(!rows.length)return'<p class="state">Draws itself once scores land.</p>';
    /* a score axis, the week's lowest and highest labelled, every dot named on hover, and a colour key */
    const vals=rows.flatMap(r=>r.pts.map(p2=>p2.v));
    const st=labStep(Math.max(...vals)-Math.min(...vals),4,true);
    const lo=Math.floor(Math.min(...vals)/st)*st,hi=Math.max(lo+st,Math.ceil(Math.max(...vals)/st)*st);
    const W=320,X0=58,X1=W-26,rh=30,top=16,H=top+rows.length*rh+12;
    const sx=v=>X0+((v-lo)/(hi-lo))*(X1-X0);
    let out='';
    for(let k=0,v=lo;v<=hi+1e-9&&k<12;k++,v=lo+k*st)out+='<line x1="'+sx(v)+'" y1="'+(top-8)+'" x2="'+sx(v)+'" y2="'+(H-22)+'" stroke="#EEE8F2" stroke-dasharray="3 4"/>'
      +'<text x="'+sx(v)+'" y="'+(H-7)+'" font-size="10.5" text-anchor="middle" fill="'+LABAX+'">'+v+'</text>';
    rows.forEach((r,i)=>{
      const y=top+i*rh;
      const xs=r.pts.map(p2=>sx(p2.v));
      const lo2=r.pts.reduce((a2,b2)=>b2.v<a2.v?b2:a2),hi2=r.pts.reduce((a2,b2)=>b2.v>a2.v?b2:a2);
      out+='<text x="2" y="'+(y+4)+'" font-size="10.5" font-weight="700" fill="'+LABAX+'">GW'+r.g+'</text>'
       +'<line x1="'+Math.min(...xs)+'" y1="'+y+'" x2="'+Math.max(...xs)+'" y2="'+y+'" stroke="#D9CFE2" stroke-width="2"/>'
       +r.pts.map((p2,j)=>'<circle cx="'+xs[j]+'" cy="'+y+'" r="5" fill="'+TEAMS[p2.t].col+'" stroke="#fff" stroke-width="1"><title>'+esc(labShort(p2.t))+' · '+p2.v+'</title></circle>').join('')
       +'<text x="'+(sx(lo2.v)-8)+'" y="'+(y+4)+'" font-size="10.5" font-weight="700" text-anchor="end" fill="'+labInk(TEAMS[lo2.t].col)+'">'+lo2.v+'</text>'
       +'<text x="'+(sx(hi2.v)+8)+'" y="'+(y+4)+'" font-size="10.5" font-weight="700" fill="'+labInk(TEAMS[hi2.t].col)+'">'+hi2.v+'</text>';
    });
    return '<div class="labsvg"><svg viewBox="0 0 '+W+' '+H+'" width="100%" style="display:block;width:100%;height:auto;max-width:480px;margin:0 auto" role="img">'+out+'</svg></div>'
      +'<div class="labkey">'+anaOrder().map(t=>'<span><i style="background:'+TEAMS[t].col+'"></i>'+esc(labShort(t))+'</span>').join('')+'</div>'
      +foot('Every manager’s score, one row per gameweek; the lowest and highest are labelled.');
  }
