from h import *
import json
R={}
with App(width=390,height=844) as app:
    p=app.open('v12.html')
    # article return keeps the Matchday scroll
    p.evaluate("()=>window.scrollTo(0,300)"); p.wait_for_timeout(300)
    a=p.locator('#gwbody a.lkrow[href$=".html"]').first
    y0=p.evaluate("()=>Math.round(scrollY)")
    a.click(); p.wait_for_load_state('load'); p.wait_for_timeout(500)
    R['art_page']=p.url.split('/')[-1]
    p.go_back(); p.wait_for_load_state('load')
    p.wait_for_function("() => typeof D !== 'undefined' && D.ro && D.ro.length > 0", timeout=20000); p.wait_for_timeout(1200)
    R['art_return_scroll']=[y0,p.evaluate("()=>Math.round(scrollY)"),p.evaluate("()=>sheet.classList.contains('on')")]
    # manager sheet -> player -> back x2, scroll kept
    tab(p,'table'); p.evaluate("()=>window.scrollTo(0,200)"); p.wait_for_timeout(300)
    p.locator('.trow[data-prof]').nth(1).click(); p.wait_for_timeout(500)
    p.evaluate("()=>{sheet.scrollTop=700}"); p.wait_for_timeout(200)
    p.locator('#sheet .fc').first.click(); p.wait_for_timeout(500)
    R['player_open']=p.evaluate("()=>!!document.querySelector('#sheet .sh-left')")
    p.go_back(); p.wait_for_timeout(500)
    R['back1']=p.evaluate("()=>[sheet.classList.contains('on'),sheet.dataset.team||'',Math.round(sheet.scrollTop)]")
    p.go_back(); p.wait_for_timeout(500)
    R['back2']=p.evaluate("()=>[sheet.classList.contains('on'),location.hash,Math.round(scrollY)]")
    # my team page -> player -> Esc keeps page scroll
    tab(p,'team'); p.locator('#teambody [data-pick]').first.click(); p.wait_for_timeout(500)
    p.evaluate("()=>window.scrollTo(0,648)"); p.wait_for_timeout(300)
    p.locator('#teambody .fc').nth(3).click(); p.wait_for_timeout(400)
    p.keyboard.press('Escape'); p.wait_for_timeout(400)
    R['team_esc']=p.evaluate("()=>[sheet.classList.contains('on'),location.hash,Math.round(scrollY)]")
    p.locator('#teambody .fc').nth(3).click(); p.wait_for_timeout(400)
    p.go_back(); p.wait_for_timeout(400)
    R['team_back']=p.evaluate("()=>[sheet.classList.contains('on'),location.hash,Math.round(scrollY)]")
    # 10 navigations, 10 back, 10 forward
    seq=['gw','team','table','xis','ana','table','gw','ana','xis','table']
    for t in seq: tab(p,t)
    hs=[]
    for i in range(9): p.go_back(); p.wait_for_timeout(250); hs.append(p.evaluate("()=>[location.hash,document.body.dataset.view,!!document.querySelector('#sheet.on')]"))
    R['backs']=hs
    fs=[]
    for i in range(9): p.go_forward(); p.wait_for_timeout(250); fs.append(p.evaluate("()=>[location.hash,document.body.dataset.view]"))
    R['fwds']=fs
    # re-tap Players while searching keeps the query
    tab(p,'xis'); p.fill('#pfind','Pal'); p.dispatch_event('#pfind','input'); p.wait_for_timeout(200)
    p.evaluate("()=>window.scrollTo(0,300)"); p.wait_for_timeout(200)
    tab(p,'xis'); p.wait_for_timeout(800)
    R['retap_xis']=p.evaluate("()=>[Math.round(scrollY),document.getElementById('pfind').value,document.querySelectorAll('#pres .prw').length]")
    R['errors']=[e for e in app.errors if 'Failed to load' not in e]
print(json.dumps(R,indent=0))
