import os, sys
os.environ.setdefault('EMT_ROOT', '/home/claude/wt-c')
sys.path.insert(0, '/home/claude/harness')
import harness
harness.ROOT = __import__('pathlib').Path(os.environ['EMT_ROOT'])
from harness import App
SH = '/home/claude/harness/fix-c/shots/'
def tab(p, name):
    p.locator('#nav [data-v="%s"]' % name).click(); p.wait_for_timeout(250)
