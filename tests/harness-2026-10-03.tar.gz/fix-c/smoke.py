from h import *
import json, sys
tag = sys.argv[1]
out = {}
for w, hh in [(390, 844), (320, 640)]:
    with App(width=w, height=hh) as app:
        p = app.open('v12.html')
        res = {}
        def ov(name):
            v = p.evaluate("()=>[document.documentElement.scrollWidth,innerWidth]")
            res[name] = v
        for t in ['gw', 'team', 'table', 'xis', 'ana']:
            tab(p, t); p.wait_for_timeout(200); ov(t)
            p.screenshot(path=SH + tag + '/smoke-%s-%d.png' % (t, w), full_page=True)
        # team page (pick a team)
        tab(p, 'team'); p.locator('#teambody [data-pick]').nth(4).click(); p.wait_for_timeout(500); ov('team-page')
        p.screenshot(path=SH + tag + '/smoke-teampage-%d.png' % w, full_page=True)
        # player sheet via search
        tab(p, 'xis'); p.fill('#pfind', 'Saka'); p.dispatch_event('#pfind', 'input'); p.wait_for_timeout(200)
        p.locator('#pres .prw').first.click(); p.wait_for_timeout(500)
        p.screenshot(path=SH + tag + '/smoke-player-%d.png' % w); ov('player-sheet')
        p.keyboard.press('Escape'); p.wait_for_timeout(300)
        # team sheet from the table
        tab(p, 'table'); p.locator('.trow[data-prof]').nth(2).click(); p.wait_for_timeout(500)
        p.screenshot(path=SH + tag + '/smoke-teamsheet-%d.png' % w); ov('team-sheet')
        p.keyboard.press('Escape'); p.wait_for_timeout(300)
        # matchup
        tab(p, 'gw'); p.locator('#gwbody .mcard[data-mi]').first.click(); p.wait_for_timeout(500); ov('matchup')
        p.screenshot(path=SH + tag + '/smoke-matchup-%d.png' % w, full_page=True)
        p.locator('#gwback').click(); p.wait_for_timeout(400)
        # faq
        p.evaluate("()=>{location.hash='faq'}"); p.wait_for_timeout(300); ov('faq')
        p.screenshot(path=SH + tag + '/smoke-faq-%d.png' % w)
        p.locator('#faqback').click() if p.locator('#faqback').count() else None
        p.wait_for_timeout(300)
        res['after_faq_back'] = p.evaluate("()=>location.hash")
        res['errors'] = [e for e in app.errors if 'Failed to load resource' not in e]
        res['n404'] = len([e for e in app.errors if 'Failed to load resource' in e])
        out[w] = res
print(json.dumps(out, indent=1))
