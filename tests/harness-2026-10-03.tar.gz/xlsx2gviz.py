import openpyxl, json, sys, datetime, re, pathlib
src = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/sheet.xlsx'
out = pathlib.Path('/home/claude/harness/tabs'); out.mkdir(exist_ok=True)
wb = openpyxl.load_workbook(src, data_only=True)
def colid(i):
    s = ''
    i += 1
    while i: i, r = divmod(i - 1, 26); s = chr(65 + r) + s
    return s
def fmtnum(v):
    if isinstance(v, bool): return 'TRUE' if v else 'FALSE'
    if float(v).is_integer(): return str(int(v))
    return ('%.10g' % v)
for ws in wb.worksheets:
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    while rows and all(v is None for v in rows[-1]): rows.pop()
    if not rows: continue
    hdr = rows[0]
    ncol = len(hdr)
    while ncol and hdr[ncol - 1] is None and all((len(r) < ncol or r[ncol - 1] is None) for r in rows): ncol -= 1
    cols = []
    for i in range(ncol):
        vals = [r[i] for r in rows[1:] if i < len(r) and r[i] is not None]
        t = 'string'
        if vals and all(isinstance(v, bool) for v in vals): t = 'boolean'
        elif vals and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in vals): t = 'number'
        cols.append({'id': colid(i), 'label': '' if hdr[i] is None else str(hdr[i]), 'type': t})
    grow = []
    for r in rows[1:]:
        c = []
        for i in range(ncol):
            v = r[i] if i < len(r) else None
            if v is None: c.append(None)
            elif isinstance(v, bool): c.append({'v': v, 'f': 'TRUE' if v else 'FALSE'})
            elif isinstance(v, (int, float)): c.append({'v': v, 'f': fmtnum(v)})
            elif isinstance(v, datetime.datetime): c.append({'v': v.isoformat(), 'f': v.isoformat()})
            else: c.append({'v': str(v)})
        grow.append({'c': c})
    j = {'version': '0.6', 'reqId': '0', 'status': 'ok', 'sig': '0', 'table': {'cols': cols, 'rows': grow, 'parsedNumHeaders': 1}}
    (out / (ws.title + '.json')).write_text(json.dumps(j, ensure_ascii=False))
    print(ws.title, len(grow), 'rows', ncol, 'cols')
